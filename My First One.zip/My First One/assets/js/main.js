(function ($) {
    "use strict";




// magnific-popup-active
$('.image-popup').magnificPopup({
    type:'image',
    gallery: {
      enabled: true
    }
});
  



})(jQuery);   