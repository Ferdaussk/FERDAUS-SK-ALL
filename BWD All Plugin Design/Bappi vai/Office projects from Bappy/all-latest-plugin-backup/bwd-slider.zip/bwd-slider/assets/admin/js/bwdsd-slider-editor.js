// (function ($) {
//     "use strict";
//     $(document).ready(function(){
//         // alert('ok')
    
//     })
// })

// alert('ok')
// console.log('loaded');
// setTimeout(() => {
    
// let input = document.querySelector('input:hidden[value="bwdsd_slider_per_view_hidden"]')
// console.log(input);

// }, 3000);