//   // search 1 //

//   const serTog = document.querySelector('.bwdsb-search-wrapper')
//     const close = document.querySelector('.bwdsb-close')

//     serTog.addEventListener('click', function (evt){
//             evt.preventDefault();
//             serTog.classList.add('active');
//         },
//         true
//     )


//     close.addEventListener('click', function (){
//         serTog.classList.remove('active');
//         }
//     ,true)







//   // search 2 //

// const clikIcon = document.querySelector('.bwdsb-click-icon');
// const addIcon = document.querySelector('.bwdsb-search-popup-wrap');
// const closeIcon = document.querySelector('.bwdsb-search-close');

//     clikIcon.addEventListener('click', function (evt){
//         evt.preventDefault();
//         addIcon.classList.add('active-icon');
//     },
//     true
//     )

//     closeIcon.addEventListener('click', function (){
//         addIcon.classList.remove('active-icon');
//         }
//     ,true)





//   // search 3 //

// const clikIcons = document.querySelector('.bwdsb-search-box-3 .bwdsb-click-icon');
// const addIcons = document.querySelector('.bwdsb-search-popup-wrap-box');
// const closeIconB = document.querySelector('.bwdsb-search-popup-wrap-box .bwdsb-search-close');



//     clikIcons.addEventListener('click', function (evt){
//         evt.preventDefault();
//         addIcons.classList.add('active-icons');
//         },
//         true
//     )

//     closeIconB.addEventListener('click', function (){
//         addIcons.classList.remove('active-icons');
//         },
//         true
//     )



    

//   // search 4 //

// const clikIc = document.querySelector('.bwdsb-search-box-4 .bwdsb-click-icon');
// const addIc = document.querySelector('.bwdsb-search-box-4 .bwdsb-search-popup-wrap-box');
// const closeIc = document.querySelector('.bwdsb-search-box-4 .bwdsb-search-popup-wrap-box .bwdsb-search-close');


// clikIc.addEventListener('click', function (evt){
//         evt.preventDefault();
//         addIc.classList.add('active-icons');
//         },
//         true
//     )

//     closeIc.addEventListener('click', function (){
//         addIc.classList.remove('active-icons');
//         },
//         true
//     )



// // search 5 //

// const clikIcr = document.querySelector('.bwdsb-search-box-5 .bwdsb-click-icon');
// const addIcr = document.querySelector('.bwdsb-search-box-5 .bwdsb-search-popup-wrap-box');
// const closeIcr = document.querySelector('.bwdsb-search-box-5 .bwdsb-search-popup-wrap-box .bwdsb-search-close');
// const serFor = document.querySelector('.bwdsb-search-box-5 .bwdsb-search-form');


// clikIcr.addEventListener('click', function (evt){
//         evt.preventDefault();
//         addIcr.classList.add('active-icons');
//         serFor.classList.add('active-icons');
//         },
//         true
//     )

//     closeIcr.addEventListener('click', function (){
//         addIcr.classList.remove('active-icons');
//         serFor.classList.remove('active-icons');
//         },
//         true
//     )



