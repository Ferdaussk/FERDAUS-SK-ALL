<?php
namespace bwdpbProgressBar\PageSettings;

use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\PageBase;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Page_Settings {
	const PANEL_TAB = 'new-tab';
	public function __construct() {
		add_action( 'elementor/init', [ $this, 'bwdpb_progressBar_add_panel_tab' ] );
		add_action( 'elementor/documents/register_controls', [ $this, 'bwdpb_progressBar_register_document_controls' ] );
	}

	public function bwdpb_progressBar_add_panel_tab() {
		Controls_Manager::add_tab( self::PANEL_TAB, esc_html__( 'New ProgressBar', 'bwdpb-progressBar' ) );
	}

	public function bwdpb_progressBar_register_document_controls( $document ) {
		if ( ! $document instanceof PageBase || ! $document::get_property( 'has_elements' ) ) {
			return;
		}
		$document->start_controls_section(
			'bwdpb_progressBar_new_section',
			[
				'label' => esc_html__( 'Settings', 'bwdpb-progressBar' ),
				'tab' => self::PANEL_TAB,
			]
		);
		$document->add_control(
			'bwdpb_progressBar_text',
			[
				'label' => esc_html__( 'Title', 'bwdpb-progressBar' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Title', 'bwdpb-progressBar' ),
			]
		);

		$document->end_controls_section();
	}
}
