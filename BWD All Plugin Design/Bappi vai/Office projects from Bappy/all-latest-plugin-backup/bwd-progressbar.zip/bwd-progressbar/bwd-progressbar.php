<?php
/**
 * Plugin Name: Progress Bar
 * Description: Progress bar is an Elementor plugin that contains 30+ unique attractive ready-made designs. More designs will come very soon stay tuned.
 * Plugin URI: https://wppluginzone.com/progress-bar-addon-for-elementor/
 * Version:     1.0
 * Author:      Best WP Developer
 * Author URI:  https://wppluginzone.com/
 * Text Domain: bwdpb-progressBar
 * Elementor tested up to: 3.0.0
 * Elementor Pro tested up to: 3.7.3
 */

 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
require_once ( plugin_dir_path(__FILE__) ) . '/includes/requries-check.php';
final class FinalBWDPBProgressBar{ 

	const VERSION = '1.0';
	const MINIMUM_ELEMENTOR_VERSION = '3.0.0';
	const MINIMUM_PHP_VERSION = '7.0';

	public function __construct() {
		// Load translation
		add_action( 'bwdpb_init', array( $this, 'bwdpb_loaded_textdomain' ) );

		// bwdpb_init Plugin
		add_action( 'plugins_loaded', array( $this, 'bwdpb_init' ) );
	}

	public function bwdpb_loaded_textdomain() {
		load_plugin_textdomain( 'bwdpb-progressBar' );
	}

	public function bwdpb_init() {
		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			// For tgm plugin activation
			add_action( 'admin_notices','bwdpb_progressbar_register_required_plugins');
			return;
		}
		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', array( $this, 'bwdpb_admin_notice_minimum_elementor_version' ) );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', array( $this, 'bwdpb_admin_notice_minimum_php_version' ) );
			return;
		}

		// Once we get here, We have passed all validation checks so we can safely include our plugin
		require_once( 'bwdpb_plugin_boots.php' );
	}


	public function bwdpb_admin_notice_minimum_elementor_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bwdpb-progressBar' ),
			'<strong>' . esc_html__( 'BWD Progressbar', 'bwdpb-progressBar' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'bwdpb-progressBar' ) . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>' . esc_html__('%1$s', 'bwdpb-progressBar') . '</p></div>', $message );
	}

	public function bwdpb_admin_notice_minimum_php_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bwdpb-progressBar' ),
			'<strong>' . esc_html__( 'BWD Progressbar', 'bwdpb-progressBar' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'bwdpb-progressBar' ) . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>' . esc_html__('%1$s', 'bwdpb-progressBar') . '</p></div>', $message );
	}
}

// Instantiate bwdpb-progressBar.
new FinalBWDPBProgressBar();
remove_action( 'shutdown', 'wp_ob_end_flush_all', 1 );