<?php
namespace Creativecontentswitcher\PageSettings;

use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\PageBase;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Page_Settings {

	const PANEL_TAB = 'new-tab';

	public function __construct() {
		add_action( 'elementor/init', [ $this, 'bwdcs_content_switcher_add_panel_tab' ] );
		add_action( 'elementor/documents/register_controls', [ $this, 'bwdcs_content_switcher_register_document_controls' ] );
	}

	public function bwdcs_content_switcher_add_panel_tab() {
		Controls_Manager::add_tab( self::PANEL_TAB, esc_html__( 'New Content Switcher', 'bwdcs-content-switcher' ) );
	}

	public function bwdcs_content_switcher_register_document_controls( $document ) {
		if ( ! $document instanceof PageBase || ! $document::get_property( 'has_elements' ) ) {
			return;
		}

		$document->start_controls_section(
			'bwdcs_content_switcher_new_section',
			[
				'label' => esc_html__( 'Settings', 'bwdcs-content-switcher' ),
				'tab' => self::PANEL_TAB,
			]
		);

		$document->add_control(
			'bwdcs_content_switcher_text',
			[
				'label' => esc_html__( 'Title', 'bwdcs-content-switcher' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Title', 'bwdcs-content-switcher' ),
			]
		);

		$document->end_controls_section();
	}
}
