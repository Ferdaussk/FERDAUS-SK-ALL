

<?php 
echo ' <div class="bwdcs-content-switcher bwdcs-content-sw-4">
<div class="bwdcs-content-switcher bwdcs-switcher-btn"></div>
</div>';
