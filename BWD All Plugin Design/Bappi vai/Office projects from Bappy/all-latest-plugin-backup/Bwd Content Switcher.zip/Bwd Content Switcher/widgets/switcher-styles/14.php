<?php 
echo ' <div class="bwdcs-content-switcher bwdcs-content-sw-14">
<div class="bwdcs-content-switcher bwdcs-switcher-btn"></div>
</div>';


