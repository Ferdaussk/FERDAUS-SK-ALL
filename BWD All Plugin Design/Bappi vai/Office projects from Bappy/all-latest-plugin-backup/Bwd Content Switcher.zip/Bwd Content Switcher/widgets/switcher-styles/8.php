<?php 
echo ' <div class="bwdcs-content-switcher bwdcs-content-sw-8">
<div class="bwdcs-content-switcher bwdcs-switcher-btn"></div>
</div>';


