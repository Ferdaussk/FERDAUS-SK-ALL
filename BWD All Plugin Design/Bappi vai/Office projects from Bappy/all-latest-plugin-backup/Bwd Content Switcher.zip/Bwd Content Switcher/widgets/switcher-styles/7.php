<?php 
echo ' <div class="bwdcs-content-switcher bwdcs-content-sw-7">
<div class="bwdcs-content-switcher bwdcs-switcher-btn"></div>
</div>';


