<?php 
echo ' <div class="bwdcs-content-switcher bwdcs-content-sw-6">
<div class="bwdcs-content-switcher bwdcs-switcher-btn"></div>
</div>';


