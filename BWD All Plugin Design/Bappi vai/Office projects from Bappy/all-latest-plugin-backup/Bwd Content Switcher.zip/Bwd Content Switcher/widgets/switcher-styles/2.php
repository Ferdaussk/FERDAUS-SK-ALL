

<?php 
echo ' <div class="bwdcs-content-switcher bwdcs-content-sw-2">
<div class="bwdcs-content-switcher bwdcs-switcher-btn"></div>
</div>';


