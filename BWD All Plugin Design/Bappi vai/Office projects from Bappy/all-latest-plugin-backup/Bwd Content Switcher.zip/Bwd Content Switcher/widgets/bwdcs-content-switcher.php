<?php
namespace Creativecontentswitcher\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class BWDCSContentSwitcher extends \Elementor\Widget_Base {


	public function get_name() {
		return 'bwdcs-content-switcher';
	}

	public function get_title() {
		return esc_html__( 'BWD Content Switcher', 'bwdcs-content-switcher' );
	}

	public function get_icon() {
		return 'eicon-kit-parts bwdcs-content-switcher-icon';
	}

	public function get_categories() {
		return [ 'bwdcs-content-switcher-category' ];
	}

    public function get_keywords() {
		return [ 'content', 'switcher', 'content switcher', 'content-switcher' ];
	}

	public function get_script_depends() {
		return [ 'bwdcs-content-switcher-category' ];
	}

    public function select_elementor_page( $type ) {
		$args  = [
			'bwdcs_tax_query'      => [
				[
					'taxonomy' => 'elementor_library_type',
					'field'    => 'slug',
					'terms'    => $type,
				],
			],
			'post_type'      => 'elementor_library',
			'posts_per_page' => -1,
		];
		$query = new \WP_Query( $args );
		$posts = $query->posts;
		foreach ( $posts as $post ) {
			$items[ $post->ID ] = $post->post_title;
		}
		if ( empty( $items ) ) {
			$items = [];
		}
		return $items;
	}
	protected function register_controls() {

		$this->start_controls_section(
			'bwdcs_content_switcher_choose_style',
		    [
		        'label' => esc_html__('Choose Style','bwdcs-content-switcher'),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
		   
		    ]
		);
		$this->add_control(
			'bwdcs_content_switcher_style',
			[
				'label' => esc_html__( 'Choose Style', 'bwdcs-content-switcher' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'bwdcs-content-switcher' ),
					'style2' => esc_html__( 'Style 2', 'bwdcs-content-switcher' ),
					'style3' => esc_html__( 'Style 3', 'bwdcs-content-switcher' ),
					'style4' => esc_html__( 'Style 4', 'bwdcs-content-switcher' ),
				],
			]
		);
        $this->end_controls_section();

        // Switcher Tab
        $this->start_controls_section(
			'bwdcs_switcher_tab_style',
		    [
		        'label' => esc_html__('Switcher Tab','bwdcs-content-switcher'),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
		   
		    ]
		);

        $this->add_control(
			'bwdcs_switcher_tab_btn_style',
			[
				'label' => esc_html__( 'Switcher Style', 'bwdcs-content-switcher' ),
				'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '12',
				'options' => [
					'1'  => esc_html__('Style 1', 'bwdcs-content-switcher' ),
					'2' => esc_html__( 'Style 2', 'bwdcs-content-switcher' ),
					'3' => esc_html__( 'Style 3', 'bwdcs-content-switcher' ),
					'4' => esc_html__( 'Style 4', 'bwdcs-content-switcher' ),
					'5' => esc_html__( 'Style 5', 'bwdcs-content-switcher' ),
					'6' => esc_html__( 'Style 6', 'bwdcs-content-switcher' ),
					'7' => esc_html__( 'Style 7', 'bwdcs-content-switcher' ),
					'8' => esc_html__( 'Style 8', 'bwdcs-content-switcher' ),
					'9' => esc_html__( 'Style 9', 'bwdcs-content-switcher' ),
					'10' => esc_html__( 'Style 10', 'bwdcs-content-switcher' ),
					'11' => esc_html__( 'Style 11', 'bwdcs-content-switcher' ),
					'12' => esc_html__( 'Style 12', 'bwdcs-content-switcher' ),
					'13' => esc_html__( 'Style 13', 'bwdcs-content-switcher' ),
					'14' => esc_html__( 'Style 14', 'bwdcs-content-switcher' ),
					'15' => esc_html__( 'Style 15', 'bwdcs-content-switcher' ),
				],
			]
		);

        $this->add_control(
			'bwdcs_switcher_primary_tab', [
				'label' => esc_html__( 'Title', 'bwdcs-content-switcher' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic' => [
					'active' => true,
				],
				'default' => esc_html__( 'Primary', 'bwdcs-content-switcher' ),
			]
		);

        $this->add_control(
			'bwdcs_switcher_secondary_tab', [
				'label' => esc_html__( 'Title', 'bwdcs-content-switcher' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic' => [
					'active' => true,
				],
				'default' => esc_html__( 'Secondary', 'bwdcs-content-switcher' ),
			]
		);

        $this->end_controls_section();

        // Switcher Primary Content
        $this->start_controls_section(
			'bwdcs_switcher_primary_content_style',
		    [
		        'label' => esc_html__('Primary Content','bwdcs-content-switcher'),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
		   
		    ]
		);
        // Control add start
		$this->add_control(
			'bwdcs_primary_content_type',
			[
				'label'   => __( 'Type', 'bwdcs-content-switcher' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'bwdcs_switcher_primary_repeater_list',
				'options' => [
					'bwdcs_switcher_primary_repeater_list' => __( 'Plain/ HTML Text', 'bwdcs-content-switcher' ),
					'bwdcs_saved_primary_section' => __( 'Saved Section', 'bwdcs-content-switcher' ),
				],
			]
		);
		$saved_primary_sections = ['0' => __( 'Choose Section', 'bwdcs-content-switcher' )];
		$saved_primary_sections = $saved_primary_sections + $this->select_elementor_page( 'section' );

		$this->add_control(
			'bwdcs_primary_saved_section',
			[
				'label'     => __( 'Sections', 'bwdcs-content-switcher' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $saved_primary_sections,
				'default'   => '0',
				'condition' => [
					'bwdcs_primary_content_type' => 'bwdcs_saved_primary_section',
				],
			]
		);

		// Control add end

       
        $repeater_primary = new \Elementor\Repeater();

		$repeater_primary->add_control(
			'bwdcs_switcher_media_type',
			[
				'label' => esc_html__( 'Media Type', 'bwdcs-content-switcher' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'bwdcs_switcher_icon' => [
						'title' => esc_html__( 'Icon', 'bwdcs-content-switcher' ),
						'icon' => 'eicon-apps',
					],
					'bwdcs_switcher_image' => [
						'title' => esc_html__( 'Image', 'bwdcs-content-switcher' ),
						'icon' => 'eicon-image-hotspot',
					],
				],
				'default' => 'bwdcs_switcher_image',
			]
		);

		$repeater_primary->add_control(
			'bwdcs_switcher_icon',
			[
				'label' => esc_html__( 'Icon', 'bwdcs-content-switcher' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-tv',
					'library' => 'fa-solid',
				],
				'condition' => [
					'bwdcs_switcher_media_type' => 'bwdcs_switcher_icon'
				]
			]
		);
        $repeater_primary->add_control(
			'bwdcs_switcher_image',
			[
				'label' => esc_html__( 'Image', 'bwdcs-content-switcher' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'dynamic' => [
                    'active' => true,
                ],
				'default' => [
					'url' => plugin_dir_url(__DIR__) .'/assets/public/img/switcher-img-1.jpg',
				],
				'condition' => [
					'bwdcs_switcher_media_type' => 'bwdcs_switcher_image'
				]
			]
		);
        $repeater_primary->add_control(
			'bwdcs_switcher_content_title', [
				'label' => esc_html__( 'Name', 'bwdcs-content-switcher' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'WILLIAMSON' , 'bwdcs-content-switcher' ),
				'label_block' => true,
                'dynamic' => [
					'active' => true,
				],
			]
		);
        $repeater_primary->add_control(
			'bwdcs_switcher_content_desc', [
                'label' => esc_html__( 'Description', 'bwdcs-content-switcher' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'Web Developer', 'bwdcs-content-switcher' ),
			]
		);
        $this->add_control(
			'bwdcs_switcher_primary_repeater_list',
			[
				'label' => esc_html__( 'Primary Content', 'bwdcs-content-switcher' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater_primary->get_controls(),
				'default' => [
					
					[
						'bwdcs_switcher_image'=>[
							'url' => plugins_url('../assets/public/img/switcher-img-1.jpg', __FILE__),
						],
						'bwdcs_switcher_content_title' => esc_html__( 'WILLIAMSON', 'bwdcs-content-switcher' ),

						'bwdcs_switcher_content_desc' => esc_html__( 'Web Developer', 'bwdcs-content-switcher' ),
					],
					[
						'bwdcs_switcher_image'=>[
							'url' => plugins_url('../assets/public/img/switcher-img-2.jpg', __FILE__),
						],
						'bwdcs_switcher_content_title' => esc_html__( 'John Doe', 'bwdcs-content-switcher' ),

                        'bwdcs_switcher_content_desc' => esc_html__( 'Front End Developer', 'bwdcs-content-switcher' ),
					],
                    [
						'bwdcs_switcher_image'=>[
							'url' => plugins_url('../assets/public/img/switcher-img-3.jpg', __FILE__),
						],
						'bwdcs_switcher_content_title' => esc_html__( 'STEVE THOMAS', 'bwdcs-content-switcher' ),

                        'bwdcs_switcher_content_desc' => esc_html__( 'Php Developer', 'bwdcs-content-switcher' ),
					],
				],
				'title_field' => '{{{ bwdcs_switcher_content_title }}}',
			]
		);
        $this->end_controls_section();

        // Switcher Secondary Content
        $this->start_controls_section(
			'bwdcs_switcher_secondary_content_style',
		    [
		        'label' => esc_html__('Secondary Content','bwdcs-content-switcher'),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
		   
		    ]
		);
        // Control add start
		$this->add_control(
			'bwdcs_secondary_content_type',
			[
				'label'   => __( 'Type', 'bwdcs-content-switcher' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'bwdcs_switcher_secondary_repeater_list',
				'options' => [
					'bwdcs_switcher_secondary_repeater_list' => __( 'Plain/ HTML Text', 'bwdcs-content-switcher' ),
					'saved_secondary_section' => __( 'Saved Section', 'bwdcs-content-switcher' ),
				],
				
			]
		);
		$saved_secondary_sections = ['0' => __( 'Choose Section', 'bwdcs-content-switcher' )];
		$saved_secondary_sections = $saved_secondary_sections + $this->select_elementor_page( 'section' );

		$this->add_control(
			'bwdcs_secondary_saved_section',
			[
				'label'     => __( 'Sections', 'bwdcs-content-switcher' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => $saved_secondary_sections,
				'default'   => '0',
				'condition' => [
					'bwdcs_secondary_content_type' => 'saved_secondary_section',
				],
			]
		);

		// Control add end

       
        $repeater_secondary = new \Elementor\Repeater();

		$repeater_secondary->add_control(
			'bwdcs_switcher_icon',
			[
				'label' => esc_html__( 'Icon', 'bwdcs-content-switcher' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-tv',
					'library' => 'fa-solid',
				],
			]
		);
        $repeater_secondary->add_control(
			'bwdcs_switcher_image',
			[
				'label' => esc_html__( 'Image', 'bwdcs-content-switcher' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'dynamic' => [
                    'active' => true,
                ],
				'default' => [
					'url' => plugin_dir_url(__DIR__) .'assets/public/img/switcher-img-1.jpg',
				],
			]
		);
        $repeater_primary->add_control(
			'bwdcs_switcher_secondary_title', [
				'label' => esc_html__( 'Name', 'bwdcs-content-switcher' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'WILLIAMSON' , 'bwdcs-content-switcher' ),
				'label_block' => true,
                'dynamic' => [
					'active' => true,
				],
			]
		);
        $repeater_primary->add_control(
			'bwdcs_switcher_secondary_desc', [
                'label' => esc_html__( 'Description', 'bwdcs-content-switcher' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'Web Developer', 'bwdcs-content-switcher' ),
			]
		);
        $this->add_control(
			'bwdcs_switcher_secondary_repeater_list',
			[
				'label' => esc_html__( 'Secondary Content', 'bwdcs-content-switcher' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater_primary->get_controls(),
				'default' => [
					
					[
						'bwdcs_switcher_secondary_title' => esc_html__( 'WILLIAMSON', 'bwdcs-content-switcher' ),

						'bwdcs_switcher_secondary_desc' => esc_html__( 'Web Developer', 'bwdcs-content-switcher' ),
					],
					[
						'bwdcs_switcher_secondary_title' => esc_html__( 'John Doe', 'bwdcs-content-switcher' ),

                        'bwdcs_switcher_secondary_desc' => esc_html__( 'Front End Developer', 'bwdcs-content-switcher' ),
					],
                    [
						'bwdcs_switcher_secondary_title' => esc_html__( 'STEVE THOMAS', 'bwdcs-content-switcher' ),

                        'bwdcs_switcher_secondary_desc' => esc_html__( 'Php Developer', 'bwdcs-content-switcher' ),
					],
				],
				'title_field' => '{{{ bwdcs_switcher_secondary_title }}}',
			]
		);
        $this->end_controls_section();

		// Switcher Style
        $this->start_controls_section(
			'bwdcs_switcher_control_style',
		    [
		        'label' => esc_html__('Switcher Control','bwdcs-content-switcher'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		   
		    ]
		);
        $this->end_controls_section();
        
        
    }

    protected function render() {

        $settings = $this->get_settings_for_display();
        $bwdcs_switcher_primary_tab = $settings['bwdcs_switcher_primary_tab'];
        $bwdcs_switcher_secondary_tab = $settings['bwdcs_switcher_secondary_tab'];
		$switcher_tab =  $settings['bwdcs_switcher_tab_btn_style'];
		$primary = $settings['bwdcs_switcher_primary_repeater_list'];


        if ('style1' === $settings['bwdcs_content_switcher_style']) {
			?>
				<div class="bwdcs-content-switcher-1-area bwdcs-content-switcher-common">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
								<div class="bwdcs-switcher-content-tab text-center ">
									<div class="bwdcs-content-title">
										<?php echo esc_html ( $bwdcs_switcher_primary_tab); ?>
									</div>
									<div class="bwdcs-content-switcher">
										<?php 
										require('switcher-styles/'. $switcher_tab .'.php');
										?>
									</div> 
									<div class="bwdcs-content-title">
										<?php echo esc_html ( $bwdcs_switcher_secondary_tab); ?>
									</div>
								</div>
                            </div>
                            <div class="bwdcs-switcher-content-area">
                                <div class="col-lg-12">
                                    <div class="bwdcs-switcher-content-item row">
										<?php if('bwdcs_saved_primary_section' === $settings['bwdcs_primary_content_type']){
											echo bwdcs_my_plugin()->frontend->get_builder_content_for_display( $settings['bwdcs_primary_saved_section'] ); 
										}elseif('bwdcs_switcher_primary_repeater_list' === $settings['bwdcs_primary_content_type']){ ?>
											<?php   
												if( $primary ) {
													foreach( $primary as $item ) { ?>
													<div class="col-lg-4 col-sm-6">
														<div class="bwdcs-switcher-content-box">
															<?php
																if(!empty($item['bwdcs_switcher_icon']['value'])){
															?>		
																<i class="<?php echo $item['bwdcs_switcher_icon']['value'];?>"></i>
															<?php 
																}elseif(!empty($item['bwdcs_switcher_image']['url'])){
															?>
															<div class="bwdcs-switcher-img">
																<img src="<?php echo esc_url($item['bwdcs_switcher_image']['url']); ?>" alt="">
															</div>
															<?php 	
																}
															?>
															<div class="bwdcs-switcher-content">
																<div class="bwdcs-switcher-name">
																	<?php echo esc_html($item['bwdcs_switcher_content_title']); ?>
																</div>
																<div class="bwdcs-switcher-post">
																	<?php echo esc_html($item['bwdcs_switcher_content_desc']); ?>
																</div>
															</div>
														</div>
													</div>
													<?php
												}
												}
											?>
										
										<?php } ?>
                                	</div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="bwdcs-switcher-content-wrraper row">
										<?php if('saved_secondary_section' === $settings['bwdcs_secondary_content_type']){
											echo bwdcs_my_plugin()->frontend->get_builder_content_for_display( $settings['bwdcs_secondary_saved_section'] ); 
										}elseif('bwdcs_switcher_secondary_repeater_list' === $settings['bwdcs_secondary_content_type']){ ?>
											<?php   
												if( $settings['bwdcs_switcher_secondary_repeater_list'] ) {
													foreach( $settings['bwdcs_switcher_secondary_repeater_list'] as $item ) { ?>
													<div class="col-lg-4 col-sm-6">
														<div class="bwdcs-switcher-content-box">
															<?php
																if(!empty($item['bwdcs_switcher_icon']['value'])){
															?>		
																<i class="<?php echo $item['bwdcs_switcher_icon']['value'];?>"></i>
															<?php 
																}elseif(!empty($item['bwdcs_switcher_image']['url'])){
															?>
															<div class="bwdcs-switcher-img">
																<img src="<?php echo esc_url($item['bwdcs_switcher_image']['url']); ?>" alt="">
															</div>
															<?php 	
																}
															?>
															<div class="bwdcs-switcher-content">
																<div class="bwdcs-switcher-name">
																	<?php echo esc_html($item['bwdcs_switcher_secondary_title']); ?>
																</div>
																<div class="bwdcs-switcher-post">
																	<?php echo esc_html($item['bwdcs_switcher_secondary_desc']); ?>
																</div>
															</div>
														</div>
													</div>
													<?php
												}
												}
											?>
										<?php } ?> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			<?php
		}elseif ('style2' === $settings['bwdcs_content_switcher_style']) {
			?>
				<div class="bwdcs-content-switcher-2-area bwdcs-content-switcher-common">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
								<div class="bwdcs-switcher-content-tab">
									<div class="bwdcs-content-title">
										<?php echo esc_html ( $bwdcs_switcher_primary_tab); ?>
									</div>
									<div class="bwdcs-content-switcher">
										<?php 
										require('switcher-styles/'. $switcher_tab .'.php');
										?>
									</div> 
									<div class="bwdcs-content-title">
										<?php echo esc_html ( $bwdcs_switcher_secondary_tab); ?>
									</div>
								</div>
                            </div>
                            <div class="bwdcs-switcher-content-area">
                                <div class="col-lg-12">
                                    <div class="bwdcs-switcher-content-item row">
										<?php if('bwdcs_saved_primary_section' === $settings['bwdcs_primary_content_type']){
											echo bwdcs_my_plugin()->frontend->get_builder_content_for_display( $settings['bwdcs_primary_saved_section'] ); 
										}elseif('bwdcs_switcher_primary_repeater_list' === $settings['bwdcs_primary_content_type']){ ?>
											<?php   
												if( $settings['bwdcs_switcher_primary_repeater_list'] ) {
													foreach( $settings['bwdcs_switcher_primary_repeater_list'] as $item ) { ?>
													<div class="col-lg-4 col-sm-6">
														<div class="bwdcs-switcher-content-box">
															<?php
																if(!empty($item['bwdcs_switcher_icon']['value'])){
															?>		
																<i class="<?php echo $item['bwdcs_switcher_icon']['value'];?>"></i>
															<?php 
																}elseif(!empty($item['bwdcs_switcher_image']['url'])){
															?>
															<div class="bwdcs-switcher-img">
																<img src="<?php echo esc_url($item['bwdcs_switcher_image']['url']); ?>" alt="">
															</div>
															<?php 	
																}
															?>
															<div class="bwdcs-switcher-content">
																<div class="bwdcs-switcher-name">
																	<?php echo esc_html($item['bwdcs_switcher_content_title']); ?>
																</div>
																<div class="bwdcs-switcher-post">
																	<?php echo esc_html($item['bwdcs_switcher_content_desc']); ?>
																</div>
															</div>
														</div>
													</div>
													<?php
												}
												}
											?>
										
										<?php } ?>
                                	</div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="bwdcs-switcher-content-wrraper row">
										<?php if('saved_secondary_section' === $settings['bwdcs_secondary_content_type']){
											echo bwdcs_my_plugin()->frontend->get_builder_content_for_display( $settings['bwdcs_secondary_saved_section'] ); 
										}elseif('bwdcs_switcher_secondary_repeater_list' === $settings['bwdcs_secondary_content_type']){ ?>
											<?php   
												if( $settings['bwdcs_switcher_secondary_repeater_list'] ) {
													foreach( $settings['bwdcs_switcher_secondary_repeater_list'] as $item ) { ?>
													<div class="col-lg-4 col-sm-6">
														<div class="bwdcs-switcher-content-box">
															<?php
																if(!empty($item['bwdcs_switcher_icon']['value'])){
															?>		
																<i class="<?php echo $item['bwdcs_switcher_icon']['value'];?>"></i>
															<?php 
																}elseif(!empty($item['bwdcs_switcher_image']['url'])){
															?>
															<div class="bwdcs-switcher-img">
																<img src="<?php echo esc_url($item['bwdcs_switcher_image']['url']); ?>" alt="">
															</div>
															<?php 	
																}
															?>
															<div class="bwdcs-switcher-content">
																<div class="bwdcs-switcher-name">
																	<?php echo esc_html($item['bwdcs_switcher_secondary_title']); ?>
																</div>
																<div class="bwdcs-switcher-post">
																	<?php echo esc_html($item['bwdcs_switcher_secondary_desc']); ?>
																</div>
															</div>
														</div>
													</div>
													<?php
												}
												}
											?>
										<?php } ?> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			<?php
		}elseif ('style3' === $settings['bwdcs_content_switcher_style']) {
			?>
				<div class="bwdcs-content-switcher-3-area bwdcs-content-switcher-common">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
								<div class="bwdcs-switcher-content-tab">
									<div class="bwdcs-content-title">
										<?php echo esc_html ( $bwdcs_switcher_primary_tab); ?>
									</div>
									<div class="bwdcs-content-switcher">
										<?php 
										require('switcher-styles/'. $switcher_tab .'.php');
										?>
									</div> 
									<div class="bwdcs-content-title">
										<?php echo esc_html ( $bwdcs_switcher_secondary_tab); ?>
									</div>
								</div>
                            </div>
                            <div class="bwdcs-switcher-content-area">
                                <div class="col-lg-12">
                                    <div class="bwdcs-switcher-content-item row">
										<?php if('bwdcs_saved_primary_section' === $settings['bwdcs_primary_content_type']){
											echo bwdcs_my_plugin()->frontend->get_builder_content_for_display( $settings['bwdcs_primary_saved_section'] ); 
										}elseif('bwdcs_switcher_primary_repeater_list' === $settings['bwdcs_primary_content_type']){ ?>
											<?php   
												if( $settings['bwdcs_switcher_primary_repeater_list'] ) {
													foreach( $settings['bwdcs_switcher_primary_repeater_list'] as $item ) { ?>
													<div class="col-lg-4 col-sm-6">
														<div class="bwdcs-switcher-content-box">
															<?php
																if(!empty($item['bwdcs_switcher_icon']['value'])){
															?>		
																<i class="<?php echo $item['bwdcs_switcher_icon']['value'];?>"></i>
															<?php 
																}elseif(!empty($item['bwdcs_switcher_image']['url'])){
															?>
															<div class="bwdcs-switcher-img">
																<img src="<?php echo esc_url($item['bwdcs_switcher_image']['url']); ?>" alt="">
															</div>
															<?php 	
																}
															?>
															<div class="bwdcs-switcher-content">
																<div class="bwdcs-switcher-name">
																	<?php echo esc_html($item['bwdcs_switcher_content_title']); ?>
																</div>
																<div class="bwdcs-switcher-post">
																	<?php echo esc_html($item['bwdcs_switcher_content_desc']); ?>
																</div>
															</div>
														</div>
													</div>
													<?php
												}
												}
											?>
										
										<?php } ?>
                                	</div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="bwdcs-switcher-content-wrraper row">
										<?php if('saved_secondary_section' === $settings['bwdcs_secondary_content_type']){
											echo bwdcs_my_plugin()->frontend->get_builder_content_for_display( $settings['bwdcs_secondary_saved_section'] ); 
										}elseif('bwdcs_switcher_secondary_repeater_list' === $settings['bwdcs_secondary_content_type']){ ?>
											<?php   
												if( $settings['bwdcs_switcher_secondary_repeater_list'] ) {
													foreach( $settings['bwdcs_switcher_secondary_repeater_list'] as $item ) { ?>
													<div class="col-lg-4 col-sm-6">
														<div class="bwdcs-switcher-content-box">
															<?php
																if(!empty($item['bwdcs_switcher_icon']['value'])){
															?>		
																<i class="<?php echo $item['bwdcs_switcher_icon']['value'];?>"></i>
															<?php 
																}elseif(!empty($item['bwdcs_switcher_image']['url'])){
															?>
															<div class="bwdcs-switcher-img">
																<img src="<?php echo esc_url($item['bwdcs_switcher_image']['url']); ?>" alt="">
															</div>
															<?php 	
																}
															?>
															<div class="bwdcs-switcher-content">
																<div class="bwdcs-switcher-name">
																	<?php echo esc_html($item['bwdcs_switcher_secondary_title']); ?>
																</div>
																<div class="bwdcs-switcher-post">
																	<?php echo esc_html($item['bwdcs_switcher_secondary_desc']); ?>
																</div>
															</div>
														</div>
													</div>
													<?php
												}
												}
											?>
										<?php } ?> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			<?php
		}elseif ('style4' === $settings['bwdcs_content_switcher_style']) {
			?>
				<div class="bwdcs-content-switcher-4-area bwdcs-content-switcher-common">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
								<div class="bwdcs-switcher-content-tab">
									<div class="bwdcs-content-title">
										<?php echo esc_html ( $bwdcs_switcher_primary_tab); ?>
									</div>
									<div class="bwdcs-content-switcher">
										<?php 
										require('switcher-styles/'. $switcher_tab .'.php');
										?>
									</div> 
									<div class="bwdcs-content-title">
										<?php echo esc_html ( $bwdcs_switcher_secondary_tab); ?>
									</div>
								</div>
                            </div>
                            <div class="bwdcs-switcher-content-area">
                                <div class="col-lg-12">
                                    <div class="bwdcs-switcher-content-item row">
										<?php if('bwdcs_saved_primary_section' === $settings['bwdcs_primary_content_type']){
											echo bwdcs_my_plugin()->frontend->get_builder_content_for_display( $settings['bwdcs_primary_saved_section'] ); 
										}elseif('bwdcs_switcher_primary_repeater_list' === $settings['bwdcs_primary_content_type']){ ?>
											<?php   
												if( $settings['bwdcs_switcher_primary_repeater_list'] ) {
													foreach( $settings['bwdcs_switcher_primary_repeater_list'] as $item ) { ?>
													<div class="col-lg-4 col-sm-6">
														<div class="bwdcs-switcher-content-box">
															<?php
																if(!empty($item['bwdcs_switcher_icon']['value'])){
															?>	
															<div class="bwdcs-switcher-icon">	
																<i class="<?php echo $item['bwdcs_switcher_icon']['value'];?>"></i>
															</div>	
															<?php 
																}elseif(!empty($item['bwdcs_switcher_image']['url'])){
															?>
															<div class="bwdcs-switcher-img">
																<img src="<?php echo esc_url($item['bwdcs_switcher_image']['url']); ?>" alt="">
															</div>
															<?php 	
																}
															?>
															<div class="bwdcs-switcher-content">
																<div class="bwdcs-switcher-name">
																	<?php echo esc_html($item['bwdcs_switcher_content_title']); ?>
																</div>
																<div class="bwdcs-switcher-post">
																	<?php echo esc_html($item['bwdcs_switcher_content_desc']); ?>
																</div>
															</div>
														</div>
													</div>
													<?php
												}
												}
											?>
										
										<?php } ?>
                                	</div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="bwdcs-switcher-content-wrraper row">
										<?php if('saved_secondary_section' === $settings['bwdcs_secondary_content_type']){
											echo bwdcs_my_plugin()->frontend->get_builder_content_for_display( $settings['bwdcs_secondary_saved_section'] ); 
										}elseif('bwdcs_switcher_secondary_repeater_list' === $settings['bwdcs_secondary_content_type']){ ?>
											<?php   
												if( $settings['bwdcs_switcher_secondary_repeater_list'] ) {
													foreach( $settings['bwdcs_switcher_secondary_repeater_list'] as $item ) { ?>
													<div class="col-lg-4 col-sm-6">
														<div class="bwdcs-switcher-content-box">
															<?php
																if(!empty($item['bwdcs_switcher_icon']['value'])){
															?>	
															<div class="bwdcs-switcher-icon">	
																<i class="<?php echo $item['bwdcs_switcher_icon']['value'];?>"></i>
															</div>	
															<?php 
																}elseif(!empty($item['bwdcs_switcher_image']['url'])){
															?>
															<div class="bwdcs-switcher-img">
																<img src="<?php echo esc_url($item['bwdcs_switcher_image']['url']); ?>" alt="">
															</div>
															<?php 	
																}
															?>
															<div class="bwdcs-switcher-content">
																<div class="bwdcs-switcher-name">
																	<?php echo esc_html($item['bwdcs_switcher_secondary_title']); ?>
																</div>
																<div class="bwdcs-switcher-post">
																	<?php echo esc_html($item['bwdcs_switcher_secondary_desc']); ?>
																</div>
															</div>
														</div>
													</div>
													<?php
												}
												}
											?>
										<?php } ?> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			<?php
		}
		
    }
}