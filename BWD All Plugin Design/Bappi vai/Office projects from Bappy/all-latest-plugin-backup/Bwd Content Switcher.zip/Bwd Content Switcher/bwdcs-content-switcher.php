<?php
/**
 * Plugin Name: BWD Content Switcher
 * Description: BWD content switcher with eye-cathing style. 10+ preset design
 * Plugin URI:  https://bestwpdeveloper.com/plugins/elementor/bwdcs-content-switcher/
 * Version:     1.0
 * Author:      Best WP Developer
 * Author URI:  https://bestwpdeveloper.com/
 * Text Domain: bwdcs-content-switcher
 * Elementor tested up to: 3.0.0
 * Elementor Pro tested up to: 3.7.3
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
require_once ( plugin_dir_path(__FILE__) ) . '/includes/requires-check.php';
function bwdcs_my_plugin() {
	return \Elementor\Plugin::instance();
}
final class FinalbwdcsContentSwitcher{

	const VERSION = '1.0';

	const MINIMUM_ELEMENTOR_VERSION = '3.0.0';

	const MINIMUM_PHP_VERSION = '7.0';

	public function __construct() {
		// Load translation
		add_action( 'bwdcs_init', array( $this, 'bwdcs_loaded_textdomain' ) );
		// bwdcs_init Plugin
		add_action( 'plugins_loaded', array( $this, 'bwdcs_init' ) );
	}

	public function bwdcs_loaded_textdomain() {
		load_plugin_textdomain( 'bwdcs-content-switcher' );
	}

	public function bwdcs_init() {
		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			// Elementor  activation check
			add_action( 'admin_notices', 'bwdcs_content_switcher_register_required_plugins');
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', array( $this, 'bwdcs_admin_notice_minimum_elementor_version' ) );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', array( $this, 'bwdcs_admin_notice_minimum_php_version' ) );
			return;
		}

		// Once we get here, We have passed all validation checks so we can safely include our plugin
		require_once( 'bwdcs-boots.php' );
	}


	public function bwdcs_admin_notice_minimum_elementor_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bwdcs-content-switcher' ),
			'<strong>' . esc_html__( 'BWD Content Switcher', 'bwdcs-content-switcher' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'bwdcs-content-switcher' ) . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>' . esc_html__('%1$s', 'bwdcs-content-switcher') . '</p></div>', $message );
	}

	public function bwdcs_admin_notice_minimum_php_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bwdcs-content-switcher' ),
			'<strong>' . esc_html__( 'BWD Content Switcher', 'bwdcs-content-switcher' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'bwdcs-content-switcher' ) . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>' . esc_html__('%1$s', 'bwdcs-content-switcher') . '</p></div>', $message );
	}
}

// Instantiate bwdcs-content-switcher.
new FinalbwdcsContentSwitcher();
remove_action( 'shutdown', 'wp_ob_end_flush_all', 1 );