"use strict";

(() => {
  function image_swap(imgWraper) {
    const allImg = imgWraper.querySelectorAll("img");

    allImg.forEach((img) => {
      img.addEventListener("click", (event) => {
        allImg.forEach((singleImg) => {
          singleImg.classList.toggle("active");
          event.preventDefault();
        });
      });
    });
  }

  // common js for work with elementor edit mode=================================================
  // all TL player
  const TLPlayer = () => {
    let allTLCommon = document.querySelectorAll(".bwdisw-swap-click-img");
    allTLCommon.forEach((TLItem) => {
      image_swap(TLItem);
    });
  };

  // rendering element observer
  let ElemRenderObserver = (getEditMode) => {
    // elementor render observing
    const observer = new MutationObserver((mutations) => {
      mutations.map((record) => {
        if (record.addedNodes.length) {
          record.addedNodes.forEach((singleItem) => {
            if (singleItem.nodeName == "DIV") {
              if (singleItem.querySelector(".bwdisw-swap-click-img")) {
                let observedItem = singleItem.querySelector(
                  ".bwdisw-swap-click-img"
                );
                image_swap(observedItem);
              }
            }
          });
        }
      });
    });
    observer.observe(getEditMode, {
      subtree: true,
      childList: true,
    });
  };
  // elementor Edit Mode Active or not checker
  (() => {
    let EditModeIntervalId;
    if (
      document.querySelector(".elementor-edit-area") ||
      document.querySelector(".bwdisw-swap-click-img")
    ) {
      TLPlayer();
    } else {
      EditModeIntervalId = setInterval(() => {
        let ElementorEditArea =
          document.querySelector(".elementor-edit-area") ||
          document.querySelector(".page");
        if (ElementorEditArea) {
          clearInterval(EditModeIntervalId);
          //if active Edit mode Then Call The Function ===============
          ElemRenderObserver(ElementorEditArea);
        }
      }, 300);
    }
  })();
})();
