<?php
namespace Creativeimageswap\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class bwdiswimageSwap extends \Elementor\Widget_Base {


	public function get_name() {
		return 'BWDISImageSwap';
	}

	public function get_title() {
		return esc_html__( 'Bwd Image Swap', 'bwdisw-image-swap' );
	}

	public function get_icon() {
		return 'eicon-image-bold bwdisw-image-swap';
	}

	public function get_categories() {
		return [ 'bwdisw-image-swap-category' ];
	}

	public function get_keywords() {
		return [ 'image', 'swap', 'hover', 'effect', 'bwd' ];
	}

	public function get_script_depends() {
		return [ 'bwdisw-image-swap-category' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'bwdisw_image_swap_style',
		    [
		        'label' => esc_html__('Choose Style','bwdisw-image-swap'),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
		   
		    ]
		);
		$this->add_control(
			'bwdisw_image_swap_style_layout',
			[
				'label' => esc_html__( 'Choose Style', 'bwdisw-image-swap' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'bwdisw-image-swap' ),
					'style2' => esc_html__( 'Style 2', 'bwdisw-image-swap' ),
					'style3' => esc_html__( 'Style 3', 'bwdisw-image-swap' ),
					'style4' => esc_html__( 'Style 4', 'bwdisw-image-swap' ),
					'style5' => esc_html__( 'Style 5', 'bwdisw-image-swap' ),
					'style6' => esc_html__( 'Style 6', 'bwdisw-image-swap' ),
					'style7' => esc_html__( 'Style 7', 'bwdisw-image-swap' ),
					'style8' => esc_html__( 'Style 8', 'bwdisw-image-swap' ),
					'style9' => esc_html__( 'Style 9', 'bwdisw-image-swap' ),
					'style10' => esc_html__( 'Style 10', 'bwdisw-image-swap' ),
					'style11' => esc_html__( 'Style 11', 'bwdisw-image-swap' ),
					'style12' => esc_html__( 'Style 12', 'bwdisw-image-swap' ),
					'style13' => esc_html__( 'Style 13', 'bwdisw-image-swap' ),
					'style14' => esc_html__( 'Style 14', 'bwdisw-image-swap' ),
					'style15' => esc_html__( 'Style 15', 'bwdisw-image-swap' ),
					'style16' => esc_html__( 'Style 16', 'bwdisw-image-swap' ),
					'style17' => esc_html__( 'Style 17', 'bwdisw-image-swap' ),
					'style18' => esc_html__( 'Style 18', 'bwdisw-image-swap' ),
					'style19' => esc_html__( 'Style 19', 'bwdisw-image-swap' ),
					'style20' => esc_html__( 'Style 20', 'bwdisw-image-swap' ),
					'style21' => esc_html__( 'Style 21', 'bwdisw-image-swap' ),
					'style22' => esc_html__( 'Style 22', 'bwdisw-image-swap' ),
					'style23' => esc_html__( 'Style 23', 'bwdisw-image-swap' ),
					'style24' => esc_html__( 'Style 24', 'bwdisw-image-swap' ),
					'style25' => esc_html__( 'Style 25', 'bwdisw-image-swap' ),
					'style26' => esc_html__( 'Style 26', 'bwdisw-image-swap' ),
					'style27' => esc_html__( 'Style 27', 'bwdisw-image-swap' ),
					'style28' => esc_html__( 'Style 28', 'bwdisw-image-swap' ),
					'style29' => esc_html__( 'Style 29', 'bwdisw-image-swap' ),
					'style30' => esc_html__( 'Style 30', 'bwdisw-image-swap' ),
					'style31' => esc_html__( 'Style 31', 'bwdisw-image-swap' ),
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'bwdisw_image_swap_section',
			[
				'label' => esc_html__( 'Image Swap', 'bwdisw-image-swap' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
			
		);
		//  image
		$this->add_control(
			'bwdisw_swap_fornt_image',
			[
				'label' => esc_html__( 'Front Image', 'bwdisw-image-swap' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => plugin_dir_url(__DIR__) .'assets/public/img/img2.jpg',
				],
			]
		);
		$this->add_control(
			'bwdisw_swap_back_image',
			[
				'label' => esc_html__( 'Back Image', 'bwdisw-image-swap' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => plugin_dir_url(__DIR__) .'assets/public/img/img1.jpg',
				],
			]
		);
		$this->add_control(
			'bwdisw_image_swap_link',
			[
				'label' => esc_html__( 'Image Link', 'bwdisw-image-swap' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'Write image link here', 
				'bwdisw-image-swap' ),
				'default' => [
					'url' => '#',
				],
				'dynamic' => [
					'active' => true,
				],
				
			]
		);
		$this->end_controls_section();

		// skill style tab
		$this->start_controls_section(
			'bwdisw_image_swap',
			[
				'label' => esc_html__( 'Image Style', 'bwdisw-image-swap' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'bwdisw_image_swap_overlay_show',
			[
				'label' => esc_html__( 'Show Overlay', 'bwdisw-image-swap' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'bwdisw-image-swap' ),
				'label_off' => esc_html__( 'Hide', 'bwdisw-image-swap' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'bwdisw_image_swap_bg_color',
			[
				'label' => esc_html__( 'Overlay Color', 'bwdisw-image-swap' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bwdisw-swap-img-area::before' => 'background-color: {{VALUE}} !important',
				],
				'condition' => [
					'bwdisw_image_swap_overlay_show' => 'yes',
				],
				
			]
		);
		$this->add_responsive_control(
			'bwdisw_image_swap_area_size',
			[
				'label' => esc_html__( 'Image Area Size', 'bwdisw-image-swap' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ '%' ],
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				
				'selectors' => [
					'{{WRAPPER}} .bwdisw-swap-img-area,
					{{WRAPPER}} .bwdisw-image-swap-common' => 'width: {{SIZE}}%; height: {{SIZE}}%;',
				],
			]
		);
		$this->add_responsive_control(
			'bwdisw_swap_image_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'bwdisw-image-swap' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .bwdisw-swap-img-area' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => esc_html__( 'Border', 'bwdisw-image-swap' ),
				'selector' => '{{WRAPPER}} .bwdisw-swap-img-area',
			]
		);
		
		$this->end_controls_section();


		
    }

	protected function render() {
		$settings = $this->get_settings_for_display();
		$bwdisw_swap_fornt_image = $settings['bwdisw_swap_fornt_image']['url'];
		$bwdisw_swap_back_image = $settings['bwdisw_swap_back_image']['url'];
		$is_overlay_show = $settings['bwdisw_image_swap_overlay_show'];

		if($is_overlay_show === 'yes'){
			$overlay_show = 'bwdisw-overlay-active';
		}else{
			$overlay_show = '';
		}

		if ( ! empty( $settings['bwdisw_image_swap_link']['url'] ) ) {
			$this->add_link_attributes( 'bwdisw_image_swap_link', $settings['bwdisw_image_swap_link'] );
		}
		
		if ('style1' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-1-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style2' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-2-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style3' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-3-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style4' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-4-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style5' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-5-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style6' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-6-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style7' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-7-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style8' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-8-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style9' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-9-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style10' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-10-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style11' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-11-area bwdisw-image-swap-common">
					<a href="<?php echo esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style12' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-12-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style13' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-13-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style14' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-14-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style15' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-15-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style16' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-16-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style17' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-17-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style18' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-18-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style19' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-19-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style20' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-20-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style21' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-21-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style22' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-22-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style23' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-23-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style24' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-24-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style25' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-25-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style26' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-26-area bwdisw-image-swap-common">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style27' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-27-area bwdisw-image-swap-common bwdisw-swap-click-img">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area  <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style28' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-28-area bwdisw-image-swap-common bwdisw-swap-click-img">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area  <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style29' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-29-area bwdisw-image-swap-common bwdisw-swap-click-img">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area  <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style30' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-30-area bwdisw-image-swap-common bwdisw-swap-click-img">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area  <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}elseif ('style31' === $settings['bwdisw_image_swap_style_layout']) {
			?>	
				<div class="bwdisw-image-swap-31-area bwdisw-image-swap-common bwdisw-swap-click-img">
					<a href="<?php echo  esc_url( $settings['bwdisw_image_swap_link']['url'] );?>">
						<div class="bwdisw-swap-img-area  <?php echo esc_attr($overlay_show);?>">
							<img src="<?php echo esc_attr($bwdisw_swap_fornt_image); ?>" alt="" class="bwdisw-img-1">
							<img src="<?php echo esc_attr($bwdisw_swap_back_image); ?>" alt="" class="bwdisw-img-2">
						</div>
					</a>
				</div>
			<?php
		}
	}
}



