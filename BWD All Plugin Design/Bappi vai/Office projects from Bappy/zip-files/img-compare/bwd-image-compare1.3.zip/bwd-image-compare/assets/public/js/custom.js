function inputImgCompare(compareItem) {
  let afterImg = compareItem.querySelector(".bwdic-compare-img .bwdic-after");
  let sliderBar = compareItem.querySelector(
    ".bwdic-slider-bar .bwdic-drag-line"
  );
  let compareInp = compareItem.querySelector(
    ".bwdic-slider-bar .bwdic-range-inp"
  );
  compareInp.addEventListener("input", (e) => {
    afterImg.style.width = e.target.value + "%";
    sliderBar.style.left = e.target.value + "%";
  });
}

function hoverImgCompare(compItem, dir) {
  let imgArea = compItem.querySelector(".bwdic-compare-img-wrapper");
  let afterImg = compItem.querySelector(".bwdic-compare-img .bwdic-after");
  let sliderBar = compItem.querySelector(".bwdic-slider-bar .bwdic-drag-line");
  let beforeText = compItem.querySelector(".bwdic-text-before");
  let afterText = compItem.querySelector(".bwdic-text-after");

  imgArea.addEventListener("mousemove", (e) => {
    let eventX = e.clientX;
    let eventY = e.clientY;

    let imgLeft = imgArea.getBoundingClientRect().left;
    let imgTop = imgArea.getBoundingClientRect().top;

    let hoverAreaX = eventX - imgLeft;
    let hoverAreaY = eventY - imgTop;

    if (eventX >= imgLeft && eventX <= imgLeft + imgArea.offsetWidth) {
      if (dir === "x") {
        afterImg.style.width = hoverAreaX + "px";
        sliderBar.style.left = hoverAreaX + "px";

         // before after text fade in out
        let beforeTextLeft = beforeText.getBoundingClientRect().left;
        let afterTextLeft = afterText.getBoundingClientRect().left;
        if (beforeTextLeft + beforeText.offsetWidth > eventX) {
          beforeText.classList.add("active");
        } else if (afterTextLeft < eventX) {
          afterText.classList.add("active");
        } else {
          afterText.classList.remove("active");
          beforeText.classList.remove("active");
        }
      } else if (
        dir === "y" &&
        eventY >= imgTop &&
        eventY <= imgTop + imgArea.clientHeight
      ) {
        afterImg.style.height = hoverAreaY + "px";
        sliderBar.style.top = hoverAreaY + "px";

        // before after text fade in out
        let beforeTextTop = beforeText.getBoundingClientRect().top;
        let afterTextTop = afterText.getBoundingClientRect().top;
        if (afterTextTop < eventY) {
          afterText.classList.add("active");
        } else if (beforeTextTop + beforeText.offsetHeight > eventY) {
          beforeText.classList.add("active");
        } else {
          afterText.classList.remove("active");
          beforeText.classList.remove("active");
        }
      }
    }
  });
}

// all Img Compare player
const AllImgComparePlayer = () => {
  let allCounterCommon = document.querySelectorAll(".bwdic-compare-item");
  for (item of allCounterCommon) {
    if (item.classList.contains("bwdic-compare-item-5")) {
      hoverImgCompare(item, "x");
    } else if (item.classList.contains("bwdic-compare-item-6")) {
      hoverImgCompare(item, "y");
    } else {
      inputImgCompare(item);
    }
  }

  // elementor render observing
  function renderObserving() {
    let elementorElem = document.querySelectorAll(".elementor-element");
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((record) => {
        if (record.addedNodes.length) {
          for (let i = 0; i < record.addedNodes.length; i++) {
            if (
              record.addedNodes[i].nodeName === "DIV" &&
              record.addedNodes[i].className === "elementor-widget-container"
            ) {
              let changedImgCompare = record.addedNodes[i].querySelector(
                ".bwdic-compare-item"
              );
              if (
                changedImgCompare.classList.contains("bwdic-compare-item-5")
              ) {
                hoverImgCompare(changedImgCompare, "x");
              } else if (
                changedImgCompare.classList.contains("bwdic-compare-item-6")
              ) {
                hoverImgCompare(changedImgCompare, "y");
              } else {
                inputImgCompare(changedImgCompare);
              }
            }
          }
        }
      });
    });

    for (let elemItem of elementorElem) {
      observer.observe(elemItem, {
        subtree: true,
        childList: true,
      });
    }
  }
  renderObserving();
};

// window resize to call========================
(function () {
  window.addEventListener("resize", () => {
    AllImgComparePlayer();
  });
})();

// is imgCompare loaded or not
(function () {
  let intervalId;
  if (document.querySelector(".bwdic-compare-item")) {
    AllImgComparePlayer();
  } else {
    intervalId = setInterval(() => {
      let imgCompareCommon = document.querySelector(".bwdic-compare-item");
      if (imgCompareCommon) {
        clearInterval(intervalId);
        // play loaded imgCompare================
        AllImgComparePlayer();
      }
    }, 200);
  }
})();


