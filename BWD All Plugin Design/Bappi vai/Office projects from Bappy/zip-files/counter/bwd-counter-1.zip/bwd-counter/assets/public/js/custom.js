//counter //counter inner function
let counter = (counterUp, countTime) => {
  let counterValues = [];
  for (let item of counterUp) {
    counterValues.push(Number(item.innerText));
  }

  let counterSetting = {
    exactTime: countTime / 4,
    timeCount: 1,
    interValId: "",
  };

  for (let i = 0; i < counterValues.length; i++) {
    let countNumWithTime = counterValues[i] / counterSetting.exactTime;

    let count = countNumWithTime;
    function counterManagement() {
      counterSetting.interValId = setTimeout(() => {
        counterUp[i].innerHTML = Math.ceil(count);
        count = count + countNumWithTime;
        counterSetting.timeCount++;
        counterManagement();
        if (count > counterValues[i]) {
          clearTimeout(counterSetting.interValId);
        }
      }, 1);
    }
    counterManagement();
  }
};

//counter wrapper
function scrollToPlay(counterNum, counterVal, duration) {
  let exactPositionToPlay = () => {
    let windowHeight = window.innerHeight / 3;
    let counterTopDsc = counterNum.getBoundingClientRect().top;

    if (windowHeight > counterTopDsc) {
      counter(counterVal, duration);
      document.removeEventListener("scroll", exactPositionToPlay);
    }
  };

  document.addEventListener("scroll", exactPositionToPlay);
}

let CounterChecker = (counterItem, time) => {
  let intervalId;
  if (document.querySelector(counterItem)) {
    return;
  } else {
    intervalId = setInterval(() => {
      let counter = document.querySelector(counterItem);
      if (counter) {
        clearInterval(intervalId);

        // play counter================
        let counterNum = counter.querySelectorAll(".bwdc-counter-value");
        scrollToPlay(counter, counterNum, time);
      }
    }, 100);
  }
};

// counter 1
CounterChecker(".bwdc-counter-1", 1000);
// counter 2
CounterChecker(".bwdc-counter-2", 1000);
// counter 3
CounterChecker(".bwdc-counter-3", 1000);
// counter 4
CounterChecker(".bwdc-counter-4", 1000);
// counter 5
CounterChecker(".bwdc-counter-5", 1000);
// counter 6
CounterChecker(".bwdc-counter-6", 1000);
// counter 7
CounterChecker(".bwdc-counter-7", 1000);
// counter 8
CounterChecker(".bwdc-counter-8", 1000);
// counter 9
CounterChecker(".bwdc-counter-9", 1000);
// counter 10
CounterChecker(".bwdc-counter-10", 1000);
// counter 11
CounterChecker(".bwdc-counter-11", 1000);
// counter 12
CounterChecker(".bwdc-counter-12", 1000);
// counter 13
CounterChecker(".bwdc-counter-13", 1000);
// counter 14
CounterChecker(".bwdc-counter-14", 1000);
// counter 15
CounterChecker(".bwdc-counter-15", 1000);
// counter 16
CounterChecker(".bwdc-counter-16", 1000);
// counter 17
CounterChecker(".bwdc-counter-17", 1000);
// counter 18
CounterChecker(".bwdc-counter-18", 1000);
// counter 19
CounterChecker(".bwdc-counter-19", 1000);
// counter 20
CounterChecker(".bwdc-counter-20", 1000);
// counter 21
CounterChecker(".bwdc-counter-21", 1000);
// counter 22
CounterChecker(".bwdc-counter-22", 1000);
// counter 23
CounterChecker(".bwdc-counter-23", 1000);
// counter 24
CounterChecker(".bwdc-counter-24", 1000);
// counter 25
CounterChecker(".bwdc-counter-25", 1000);
// counter 26
CounterChecker(".bwdc-counter-26", 1000);
// counter 27
CounterChecker(".bwdc-counter-27", 1000);
// counter 28
CounterChecker(".bwdc-counter-28", 1000);
// counter 29
CounterChecker(".bwdc-counter-29", 1000);
// counter 30
CounterChecker(".bwdc-counter-30", 1000);
// counter 31
CounterChecker(".bwdc-counter-31", 1000);
