"use strict";

// timeUnitRendering
function timeUnitRendering(unitWrapper, unitVal) {
  unitWrapper.innerHTML = unitVal;
}

// count down main function
let countDownMain = (unitContainer) => {
  let expiredDate = unitContainer.querySelector(".bwdcd-expired-time").value;
  // time unites wrapper
  let dayWrap = unitContainer.querySelector(".bwdcd-day");
  let hourWrap = unitContainer.querySelector(".bwdcd-hour");
  let minWrap = unitContainer.querySelector(".bwdcd-min");
  let secWrap = unitContainer.querySelector(".bwdcd-sec");

  let x = setInterval(function () {
    let now = new Date().getTime() / 1000;
    let distance = expiredDate - now;

    var days = Math.floor(distance / (60 * 60 * 24));
    var hours = Math.floor((distance % (60 * 60 * 24)) / (60 * 60));
    var minutes = Math.floor((distance % (60 * 60)) / 60);
    var seconds = Math.floor(distance % 60);

    if (seconds < 10) {
      seconds = "0" + seconds;
    }
    if (minutes < 10) {
      minutes = "0" + minutes;
    }
    if (hours < 10) {
      hours = "0" + hours;
    }
    if (days < 10) {
      days = "0" + days;
    }
    timeUnitRendering(dayWrap, days);
    timeUnitRendering(hourWrap, hours);
    timeUnitRendering(minWrap, minutes);
    timeUnitRendering(secWrap, seconds);
  }, 1000);
};

// all countDown player
const countDownPlayer = () => {
  let allcountDownCommon = document.querySelectorAll(
    ".bwdcd-count-down-common"
  );
  for (let item of allcountDownCommon) {
    countDownMain(item);
  }

  // elementor render observing
  let elementorElem = document.querySelector(".elementor-element");
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((record) => {
      if (record.addedNodes.length) {
        for (let i = 0; i < record.addedNodes.length; i++) {
          if (
            record.addedNodes[i].nodeName === "DIV" &&
            record.addedNodes[i].className === "elementor-widget-container"
          ) {
            let changedcountDown = record.addedNodes[i].querySelector(
              ".bwdcd-count-down-common"
            );
            countDownMain(changedcountDown);
          }
        }
      }
    });
  });
  observer.observe(elementorElem, {
    subtree: true,
    childList: true,
  });
};

// is countDown active or not
let countDownChecker = () => {
  let intervalId;
  if (document.querySelector(".bwdcd-count-down-common")) {
    countDownPlayer();
  } else {
    intervalId = setInterval(() => {
      let countDownCommon = document.querySelector(".bwdcd-count-down-common");
      if (countDownCommon) {
        clearInterval(intervalId);
        // play countDown===============
        countDownPlayer();
      }
    }, 300);
  }
};
countDownChecker();
