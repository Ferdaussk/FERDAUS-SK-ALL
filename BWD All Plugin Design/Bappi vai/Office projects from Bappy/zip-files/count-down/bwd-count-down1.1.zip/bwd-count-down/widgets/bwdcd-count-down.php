<?php
namespace bwdcdCountDown\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class bwdcdCountDownWidget extends Widget_Base {

	public function get_name() {
		return esc_html__( 'BWDCD Count down', 'bwdcd-count-down' );
	}
	public function get_title() {
		return esc_html__( 'BWD Count Down', 'bwdcd-count-down' );
	}
	public function get_icon() {
		return 'eicon-countdown bwdcd-count-down';
	}
	public function get_categories() {
		return [ 'bwdcd-count-down-category' ];
	}
	public function get_script_depends() {
		return [ 'bwdcd-count-down-category' ];
	}
	public function get_keywords() {
		return [ 'count-down', 'bwd count-down', 'count', 'number' ];
	}
	protected function register_controls() {
     // countdown layout control section start
		$this->start_controls_section(
			'bwdcd_count_down_layout_section',
			[
				'label' => esc_html__( 'Count Down Layout', 'bwdcd-count-down' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'bwdcd_count_down_choose',
			[
				'label' => esc_html__( 'Choose Styles', 'bwdcd-count-down' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1' => esc_html__( 'Style 1', 'bwdcd-count-down' ),
					'style2' => esc_html__( 'Style 2', 'bwdcd-count-down' ),
					'style3' => esc_html__( 'Style 3', 'bwdcd-count-down' ),
					'style4' => esc_html__( 'Style 4', 'bwdcd-count-down' ),
					'style5' => esc_html__( 'Style 5', 'bwdcd-count-down' ),
					'style6' => esc_html__( 'Style 6', 'bwdcd-count-down' ),
					'style7' => esc_html__( 'Style 7', 'bwdcd-count-down' ),
					'style8' => esc_html__( 'Style 8', 'bwdcd-count-down' ),
					'style9' => esc_html__( 'Style 9', 'bwdcd-count-down' ),
					'style10' => esc_html__( 'Style 10', 'bwdcd-count-down' ),
					'style11' => esc_html__( 'Style 11', 'bwdcd-count-down' ),
					'style12' => esc_html__( 'Style 12', 'bwdcd-count-down' ),
					'style13' => esc_html__( 'Style 13', 'bwdcd-count-down' ),
					'style14' => esc_html__( 'Style 14', 'bwdcd-count-down' ),
					'style15' => esc_html__( 'Style 15', 'bwdcd-count-down' ),
					'style16' => esc_html__( 'Style 16', 'bwdcd-count-down' ),
				],
			]
		);
		$this->end_controls_section();
		// count down content section ========================
		$this->start_controls_section(
			'bwdcd_count_down_content_section',
			[
				'label' => esc_html__( 'Content', 'bwdcd-count-down' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		// expired date
		$this->add_control(
			'expired_date',
			[
				'label' => esc_html__( 'Expired Date', 'bwdcd-count-down' ),
				'type' => \Elementor\Controls_Manager::DATE_TIME,
				'default'=> ('2023-01-01 11:15'),
			]
		);
		// number controls
		$this->add_control(
			'bwdcd_count_down_number_style',
			[
				'label' => esc_html__( 'Number', 'bwdcd-count-down'),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		// number typo 
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwdcd_count_down_num_typography',
				'selector' => '{{WRAPPER}} .bwdcd-count-down-item .bwdcd-count-down-num',
			]
		);
		// number text color
		$this->add_control(
			'bwdcd_count_down_num_color',
			[
				'label' => esc_html__( 'Text Color', 'bwdcd-count-down' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bwdcd-count-down-item .bwdcd-count-down-num' => 'color: {{VALUE}}',
					'{{WRAPPER}} .bwdcd-count-down-color-common' => 'color: {{VALUE}}',
					'{{WRAPPER}} .bwdcd-shape-common' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .bwdcd-shape-common::before,
					{{WRAPPER}} .bwdcd-shape-common::after' => 'background-color: {{VALUE}}'
				],
			]
		);
		// number bg color
		$this->add_control(
			'bwdcd_count_down_num_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'bwdcd-count-down' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bwdcd-wrapper-common' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .bwdcd-count-down-item .bwdcd-count-down-num,
					{{WRAPPER}} .bwdcd-count-down-num-common::before,
					{{WRAPPER}} .bwdcd-count-down-num-common::after' => 'background-color: {{VALUE}}',
				],
			]
		);
		// title controls
		$this->add_control(
			'bwdcd_count_down_title_style',
			[
				'label' => esc_html__( 'Title', 'bwdcd-count-down'),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		// title typo  
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwdcd_count_down_title_typography',
				'selector' => '{{WRAPPER}} .bwdcd-count-down-item .bwdcd-count-down-title',
			]
		);
		// title text color
		$this->add_control(
			'bwdcd_count_down_title_color',
			[
				'label' => esc_html__( 'Text Color', 'bwdcd-count-down' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bwdcd-count-down-item .bwdcd-count-down-title' => 'color: {{VALUE}}',
				],
			]
		);
		// title bg color
		$this->add_control(
			'bwdcd_count_down_title_bg_color',
			[
				'label' => esc_html__( 'BG Color', 'bwdcd-count-down' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bwdcd-count-down-num-common::after' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .bwdcd-count-down-item-common' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .bwdcd-count-down-item .bwdcd-count-down-title' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_section();
		// count down style section ========================
		$this->start_controls_section(
			'bwdcd_count_down_style_section',
			[
				'label' => esc_html__( 'Style', 'bwdcd-count-down'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		// number box styles
		$this->add_control(
			'bwdcd_count_down_num_box_styles',
			[
				'label' => esc_html__( 'Number Box', 'bwdcd-count-down' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);
		$this->add_responsive_control(
			'bwdcd_count_down_num_box_width',
			[
				'label' => esc_html__( 'Width', 'bwdcd-count-down'),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%'],
				'range' => [
					'px' => [
						'min' => 70,
						'max' => 150,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 110,
				],
				'selectors' => [
					'{{WRAPPER}} .bwdcd-count-down-common .bwdcd-count-down-item' => 'flex-basis: {{SIZE}}{{UNIT}};',
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
			]
		);
		// padding
		$this->add_responsive_control(
			'bwdcd_count_down_num_box_padding',
			[
				'label' => esc_html__( 'Padding', 'bwdcd-count-down'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .bwdcd-count-down-common .bwdcd-count-down-item .bwdcd-count-down-num,
					{{WRAPPER}} .bwdcd-count-down-common .bwdcd-item-padding' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
			]
		);
		// section styles
		$this->add_control(
			'bwdcd_count_down_section_styles',
			[
				'label' => esc_html__( 'Count Down Section', 'bwdcd-count-down' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		// margin
		$this->add_responsive_control(
			'bwdcd_count_down_section_margin',
			[
				'label' => esc_html__( 'Margin', 'bwdcd-count-down'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .bwdcd-count-down-common' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
			]
		);
		// padding
		$this->add_responsive_control(
			'bwdcd_count_down_section_padding',
			[
				'label' => esc_html__( 'Padding', 'bwdcd-count-down'),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .bwdcd-count-down-common' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
			]
		);
		$this->end_controls_section();
	}
	protected function render() {
		$settings =$this->get_settings();
		$provided_date = strtotime( $settings['expired_date']);

		//================== count down rendering start here=====================
		if($settings['bwdcd_count_down_choose']=== 'style1'){
				?>
			<!-- count down 1 start -->
			<div class="bwdcd-count-down-1 bwdcd-count-down-common">
				<input class="bwdcd-expired-time" type="text" hidden value="<?php echo $provided_date ;?>">
				<div class="bwdcd-count-down-item">
					<div class="bwdcd-count-down-title">days</div>
					<div class="bwdcd-count-down-num bwdcd-day bwdcd-shape-common">100</div>
				</div>
				<div class="bwdcd-count-down-item">
					<div class="bwdcd-count-down-title">Hours</div>
					<div class="bwdcd-count-down-num bwdcd-hour bwdcd-shape-common">20</div>
				</div>
				<div class="bwdcd-count-down-item">
					<div class="bwdcd-count-down-title">Minutes</div>
					<div class="bwdcd-count-down-num bwdcd-min bwdcd-shape-common">55</div>
				</div>
				<div class="bwdcd-count-down-item">
					<div class="bwdcd-count-down-title">Seconds</div>
					<div class="bwdcd-count-down-num bwdcd-sec bwdcd-shape-common">22</div>
				</div>
			</div>
			<!-- count down 1 end -->
			<!-- ============================================= -->
				<?php
		}else if($settings['bwdcd_count_down_choose']=== 'style2'){
				?>
			<!-- count down 2 start -->
			<div class="bwdcd-count-down-2 bwdcd-count-down-common">
			<input class="bwdcd-expired-time" type="text" hidden value="<?php echo $provided_date ;?>">
				<div class="bwdcd-count-down-item">
					<div class="bwdcd-count-down-num bwdcd-day bwdcd-count-down-num-common">100</div>
					<div class="bwdcd-count-down-title">days</div>
				</div>

				<div class="bwdcd-count-down-item">
					<div class="bwdcd-count-down-num bwdcd-hour bwdcd-count-down-num-common">20</div>
					<div class="bwdcd-count-down-title">Hours</div>
				</div>

				<div class="bwdcd-count-down-item">
					<div class="bwdcd-count-down-num bwdcd-min bwdcd-count-down-num-common">55</div>
					<div class="bwdcd-count-down-title">Minutes</div>
				</div>

				<div class="bwdcd-count-down-item">
					<div class="bwdcd-count-down-num bwdcd-sec bwdcd-count-down-num-common">22</div>
					<div class="bwdcd-count-down-title">Seconds</div>
				</div>
			</div>
			<!-- count down 2 end -->
			<!-- ============================================= -->
				<?php
		}else if($settings['bwdcd_count_down_choose']=== 'style3'){
			?>
			<!-- count down 3 start -->
				<div class="bwdcd-count-down-3 bwdcd-count-down-common">
				<input class="bwdcd-expired-time" type="text" hidden value="<?php echo $provided_date ;?>">
					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-day">100</div>
						<div class="bwdcd-count-down-title">days</div>
					</div>

					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-hour">20</div>
						<div class="bwdcd-count-down-title">Hours</div>
					</div>

					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-min">55</div>
						<div class="bwdcd-count-down-title">Minutes</div>
					</div>

					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-sec">22</div>
						<div class="bwdcd-count-down-title">Seconds</div>
					</div>
				</div>
			<!-- count down 3 end -->
			<!-- ============================================= -->
			<?php
		}else if($settings['bwdcd_count_down_choose']=== 'style4'){
			?>
			<!-- count down 4 start -->
				<div class="bwdcd-count-down-4 bwdcd-count-down-common">
				<input class="bwdcd-expired-time" type="text" hidden value="<?php echo $provided_date ;?>">
					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-shape-common bwdcd-day">100</div>
						<div class="bwdcd-count-down-title">days</div>
					</div>

					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-shape-common bwdcd-hour">20</div>
						<div class="bwdcd-count-down-title">Hours</div>
					</div>

					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-shape-common bwdcd-min">55</div>
						<div class="bwdcd-count-down-title">Minutes</div>
					</div>

					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-shape-common bwdcd-sec">22</div>
						<div class="bwdcd-count-down-title">Seconds</div>
					</div>
				</div>
			<!-- count down 4 end -->
			<!-- ============================================= -->
			<?php
		}else if($settings['bwdcd_count_down_choose']=== 'style5'){
			?>
			<!-- count down 5 start -->
				<div class="bwdcd-count-down-5 bwdcd-count-down-common">
				<input class="bwdcd-expired-time" type="text" hidden value="<?php echo $provided_date ;?>">
					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-day">100</div>
						<div class="bwdcd-count-down-title">days</div>
					</div>

					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-hour">20</div>
						<div class="bwdcd-count-down-title">Hours</div>
					</div>

					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-min">55</div>
						<div class="bwdcd-count-down-title">Minutes</div>
					</div>

					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-sec">22</div>
						<div class="bwdcd-count-down-title">Seconds</div>
					</div>
				</div>
			<!-- count down 5 end -->
			<!-- ============================================= -->
			<?php
		}else if($settings['bwdcd_count_down_choose']=== 'style6'){
			?>
			<!-- count down 6 start -->
				<div class="bwdcd-count-down-6 bwdcd-count-down-common">
				<input class="bwdcd-expired-time" type="text" hidden value="<?php echo $provided_date ;?>">
					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-day">100</div>
						<div class="bwdcd-count-down-title">days</div>
					</div>

					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-hour">20</div>
						<div class="bwdcd-count-down-title">Hours</div>
					</div>

					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-min">55</div>
						<div class="bwdcd-count-down-title">Minutes</div>
					</div>

					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-sec">22</div>
						<div class="bwdcd-count-down-title">Seconds</div>
					</div>
				</div>
			<!-- count down 6 end -->
			<!-- ============================================= -->
			<?php
		}else if($settings['bwdcd_count_down_choose']=== 'style7'){
			?>
			<!-- count down 7 start -->
				<div class="bwdcd-count-down-7 bwdcd-count-down-common">
					<div class="bwdcd-count-down-wrapper bwdcd-wrapper-common">
					<input class="bwdcd-expired-time" type="text" hidden value="<?php echo $provided_date ;?>">
						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-day">100</div>
							<div class="bwdcd-count-down-title">days</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-hour">20</div>
							<div class="bwdcd-count-down-title">Hours</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-min">55</div>
							<div class="bwdcd-count-down-title">Minutes</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-sec">22</div>
							<div class="bwdcd-count-down-title">Seconds</div>
						</div>
					</div>
				</div>
			<!-- count down 7 end -->
			<!-- ============================================= -->
			<?php
		}else if($settings['bwdcd_count_down_choose']=== 'style8'){
			?>
			<!-- count down 8 start -->
				<div class="bwdcd-count-down-8 bwdcd-count-down-common">
					<div class="bwdcd-count-down-wrapper">
					<input class="bwdcd-expired-time" type="text" hidden value="<?php echo $provided_date ;?>">
						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-count-down-num-common bwdcd-day">100</div>
							<div class="bwdcd-count-down-title">days</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-count-down-num-common bwdcd-hour">20</div>
							<div class="bwdcd-count-down-title">Hours</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-count-down-num-common bwdcd-min">55</div>
							<div class="bwdcd-count-down-title">Minutes</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-count-down-num-common bwdcd-sec">22</div>
							<div class="bwdcd-count-down-title">Seconds</div>
						</div>
					</div>
				</div>
			<!-- count down 8 end -->
			<!-- ============================================= -->
			<?php
		}else if($settings['bwdcd_count_down_choose']=== 'style9'){
			?>
			<!-- count down 9 start -->
				<div class="bwdcd-count-down-9 bwdcd-count-down-common">
					<div class="bwdcd-count-down-wrapper">
					<input class="bwdcd-expired-time" type="text" hidden value="<?php echo $provided_date ;?>">
						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-count-down-num-common bwdcd-day">100</div>
							<div class="bwdcd-count-down-title">days</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-count-down-num-common bwdcd-hour">20</div>
							<div class="bwdcd-count-down-title">Hours</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-count-down-num-common bwdcd-min">55</div>
							<div class="bwdcd-count-down-title">Minutes</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-count-down-num-common bwdcd-sec">22</div>
							<div class="bwdcd-count-down-title">Seconds</div>
						</div>
					</div>
				</div>
			<!-- count down 9 end -->
			<!-- ============================================= -->
			<?php
		}else if($settings['bwdcd_count_down_choose']=== 'style10'){
			?>
			<!-- count down 10 start -->
				<div class="bwdcd-count-down-10 bwdcd-count-down-common">
					<div class="bwdcd-count-down-wrapper">
						<input class="bwdcd-expired-time" type="text" hidden value="<?php echo $provided_date ;?>">
						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-day">100</div>
							<div class="bwdcd-count-down-title">days</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-hour">20</div>
							<div class="bwdcd-count-down-title">Hours</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-min">55</div>
							<div class="bwdcd-count-down-title">Minutes</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-sec">22</div>
							<div class="bwdcd-count-down-title">Seconds</div>
						</div>
					</div>
				</div>
			<!-- count down 10 end -->
			<!-- ============================================= -->
			<?php
		}else if($settings['bwdcd_count_down_choose']=== 'style11'){
			?>
			<!-- count down 11 start -->
				<div class="bwdcd-count-down-11 bwdcd-count-down-common">
					<div class="bwdcd-count-down-wrapper">
					<input class="bwdcd-expired-time" type="text" hidden value="<?php echo $provided_date ;?>">
						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-day">100</div>
							<div class="bwdcd-count-down-title">days</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-hour">20</div>
							<div class="bwdcd-count-down-title">Hours</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-min">55</div>
							<div class="bwdcd-count-down-title">Minutes</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-sec">22</div>
							<div class="bwdcd-count-down-title">Seconds</div>
						</div>
					</div>
				</div>
			<!-- count down 11 end -->
			<!-- ============================================= -->
			<?php
		}else if($settings['bwdcd_count_down_choose']=== 'style12'){
			?>
			<!-- count down 12 start -->
				<div class="bwdcd-count-down-12 bwdcd-count-down-common">
					<div class="bwdcd-count-down-wrapper">
					<input class="bwdcd-expired-time" type="text" hidden value="<?php echo $provided_date ;?>">
						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-day">100</div>
							<div class="bwdcd-count-down-title">days</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-hour">20</div>
							<div class="bwdcd-count-down-title">Hours</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-min">55</div>
							<div class="bwdcd-count-down-title">Minutes</div>
						</div>

						<div class="bwdcd-count-down-item">
							<div class="bwdcd-count-down-num bwdcd-sec">22</div>
							<div class="bwdcd-count-down-title">Seconds</div>
						</div>
					</div>
				</div>
			<!-- count down 12 end -->
			<!-- ============================================= -->
			<?php
		}else if($settings['bwdcd_count_down_choose']=== 'style13'){
			?>
			<!-- count down 13 start -->
				<div class="bwdcd-count-down-13 bwdcd-count-down-common">
					<div class="bwdcd-count-down-wrapper">
					<input class="bwdcd-expired-time" type="text" hidden value="<?php echo $provided_date ;?>">
						<div class="bwdcd-count-down-item bwdcd-count-down-item-common bwdcd-wrapper-common">
							<div class="bwdcd-count-down-num bwdcd-day">100</div>
							<div class="bwdcd-count-down-title ">days</div>
						</div>

						<div class="bwdcd-count-down-item bwdcd-count-down-item-common bwdcd-wrapper-common">
							<div class="bwdcd-count-down-num bwdcd-hour">20</div>
							<div class="bwdcd-count-down-title ">Hours</div>
						</div>

						<div class="bwdcd-count-down-item bwdcd-count-down-item-common bwdcd-wrapper-common">
							<div class="bwdcd-count-down-num bwdcd-min">55</div>
							<div class="bwdcd-count-down-title ">Minutes</div>
						</div>

						<div class="bwdcd-count-down-item bwdcd-count-down-item-common bwdcd-wrapper-common">
							<div class="bwdcd-count-down-num bwdcd-sec">22</div>
							<div class="bwdcd-count-down-title ">Seconds</div>
						</div>
					</div>
				</div>
			<!-- count down 13 end -->
			<!-- ============================================= -->
			<?php
		}else if($settings['bwdcd_count_down_choose']=== 'style14'){
			?>
			<!-- count down 14 start -->
				<div class="bwdcd-count-down-14 bwdcd-count-down-common">
					<div class="bwdcd-count-down-wrapper bwdcd-count-down-color-common">
					<input class="bwdcd-expired-time" type="text" hidden value="<?php echo $provided_date ;?>">
						<div class="bwdcd-count-down-item bwdcd-count-down-item-common bwdcd-wrapper-common">
							<div class="bwdcd-count-down-num bwdcd-shape-common bwdcd-day">100</div>
							<div class="bwdcd-count-down-title">days</div>
						</div>

						<div class="bwdcd-count-down-item bwdcd-count-down-item-common bwdcd-wrapper-common">
							<div class="bwdcd-count-down-num bwdcd-shape-common bwdcd-hour">20</div>
							<div class="bwdcd-count-down-title ">Hours</div>
						</div>

						<div class="bwdcd-count-down-item bwdcd-count-down-item-common bwdcd-wrapper-common">
							<div class="bwdcd-count-down-num bwdcd-shape-common bwdcd-min">55</div>
							<div class="bwdcd-count-down-title ">Minutes</div>
						</div>

						<div class="bwdcd-count-down-item bwdcd-count-down-item-common bwdcd-wrapper-common">
							<div class="bwdcd-count-down-num bwdcd-shape-common bwdcd-sec">22</div>
							<div class="bwdcd-count-down-title ">Seconds</div>
						</div>
					</div>
				</div>
			<!-- count down 14 end -->
			<!-- ============================================= -->
			<?php
		}else if($settings['bwdcd_count_down_choose']=== 'style15'){
			?>
			<!-- count down 15 start -->
				<div class="bwdcd-count-down-15 bwdcd-count-down-common">
					<div class="bwdcd-count-down-item bwdcd-count-down-color-common bwdcd-item-padding">
					<input class="bwdcd-expired-time" type="text" hidden value="<?php echo $provided_date ;?>">
						<div class="bwdcd-count-down-num bwdcd-day">100</div>
						<div class="bwdcd-count-down-title">days</div>
					</div>

					<div class="bwdcd-count-down-item bwdcd-count-down-color-common bwdcd-item-padding">
						<div class="bwdcd-count-down-num bwdcd-hour">20</div>
						<div class="bwdcd-count-down-title">Hours</div>
					</div>

					<div class="bwdcd-count-down-item bwdcd-count-down-color-common bwdcd-item-padding">
						<div class="bwdcd-count-down-num bwdcd-min">55</div>
						<div class="bwdcd-count-down-title">Minutes</div>
					</div>

					<div class="bwdcd-count-down-item bwdcd-count-down-color-common bwdcd-item-padding">
						<div class="bwdcd-count-down-num bwdcd-sec">22</div>
						<div class="bwdcd-count-down-title">Seconds</div>
					</div>
				</div>
			<!-- count down 15 end -->
			<!-- ============================================= -->
			<?php
		}else if($settings['bwdcd_count_down_choose']=== 'style16'){
			?>
			<!-- count down 16 start -->
				<div class="bwdcd-count-down-16 bwdcd-count-down-common">
				<input class="bwdcd-expired-time" type="text" hidden value="<?php echo $provided_date ;?>">
					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-day">100</div>
						<div class="bwdcd-count-down-title">days</div>
					</div>

					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-hour">20</div>
						<div class="bwdcd-count-down-title">Hours</div>
					</div>

					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-min">55</div>
						<div class="bwdcd-count-down-title">Minutes</div>
					</div>

					<div class="bwdcd-count-down-item">
						<div class="bwdcd-count-down-num bwdcd-sec">22</div>
						<div class="bwdcd-count-down-title">Seconds</div>
					</div>
				</div>
			<!-- count down 16 end -->
			<!-- ============================================= -->
			<?php
		}
	}
}
?>
