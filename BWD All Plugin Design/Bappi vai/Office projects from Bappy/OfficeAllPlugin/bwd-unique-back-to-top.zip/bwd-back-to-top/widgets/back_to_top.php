<?php
namespace BWDBackToTop\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class BWDBTTBackToTop extends Widget_Base {

	public function get_name() {
		return esc_html__( 'BWDBackToTop', 'bwd-back-to-top' );
	}

	public function get_title() {
		return esc_html__( 'BWD Back To Top', 'elementor' );
	}

	public function get_icon() {
		return 'bwdbtt-band-icon eicon-v-align-top';
	}

	public function get_categories() {
		return [ 'bwd-back-to-top-category' ];
	}

	public function get_script_depends() {
		return [ 'bwd-back-to-top-category' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'text_content_section',
			[
				'label' => esc_html__( 'Back To Top Content', 'bwd-back-to-top' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'bwdbtt_style_selection',
			[
				'label' => esc_html__( 'Back To Top Style', 'bwd-back-to-top' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'bwd-back-to-top' ),
					'style2' => esc_html__( 'Style 2', 'bwd-back-to-top' ),
					'style3' => esc_html__( 'Style 3', 'bwd-back-to-top' ),
					'style4' => esc_html__( 'Style 4', 'bwd-back-to-top' ),
					'style5' => esc_html__( 'Style 5', 'bwd-back-to-top' ),
					'style6' => esc_html__( 'Style 6', 'bwd-back-to-top' ),
					'style7' => esc_html__( 'Style 7', 'bwd-back-to-top' ),
					'style8' => esc_html__( 'Style 8', 'bwd-back-to-top' ),
					'style9' => esc_html__( 'Style 9', 'bwd-back-to-top' ),
					'style10' => esc_html__( 'Style 10', 'bwd-back-to-top' ),
					'style11' => esc_html__( 'Style 11', 'bwd-back-to-top' ),
					'style12' => esc_html__( 'Style 12', 'bwd-back-to-top' ),
					'style13' => esc_html__( 'Style 13', 'bwd-back-to-top' ),
					'style14' => esc_html__( 'Style 14', 'bwd-back-to-top' ),
					'style15' => esc_html__( 'Style 15', 'bwd-back-to-top' ),
					'style16' => esc_html__( 'Style 16', 'bwd-back-to-top' ),
					'style17' => esc_html__( 'Style 17', 'bwd-back-to-top' ),
					'style18' => esc_html__( 'Style 18', 'bwd-back-to-top' ),
					'style19' => esc_html__( 'Style 19', 'bwd-back-to-top' ),
					'style20' => esc_html__( 'Style 20', 'bwd-back-to-top' ),
					'style21' => esc_html__( 'Style 21', 'bwd-back-to-top' ),
					'style22' => esc_html__( 'Style 22', 'bwd-back-to-top' ),
					'style23' => esc_html__( 'Style 23', 'bwd-back-to-top' ),
					'style24' => esc_html__( 'Style 24', 'bwd-back-to-top' ),
					'style25' => esc_html__( 'Style 25', 'bwd-back-to-top' ),
				],
			]
		);
		$this->add_control(
			'bwdbtt_back_to_top_btn_icon_one',
			[
				'label' => esc_html__( 'Icon', 'bwd-back-to-top' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-arrow-up',
					'library' => 'solid',
				],
			]
		);
		$this->add_control(
			'bwdbtt_back_to_top_btn_align',
			[
				'label' => esc_html__( 'Alignment', 'bwd-back-to-top' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bwd-back-to-top' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bwd-back-to-top' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bwd-back-to-top' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'right',
				'toggle' => true,
			]
		);
		$this->add_control(
			'bwdbtt_back_to_top_btn_text', [
				'label' => esc_html__( 'Text', 'bwd-back-to-top' ),
				'type' => Controls_Manager::TEXT,
				'condition' => [
					'bwdbtt_style_selection' => ['style9', 'style19'],
				],
				'default' => esc_html__( 'Top' , 'bwd-back-to-top' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'bwdbtt_back_to_top_btn_text_color',
			[
				'label' => esc_html__( 'Text Color', 'bwd-back-to-top' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'bwdbtt_style_selection' => ['style9', 'style19'],
				],
				'selectors' => [
					'{{WRAPPER}} .bwdbtt-scroll-to-top-9 span, {{WRAPPER}} .bwdbtt-scroll-to-top-19 span' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'bwdbtt_back_to_top_btn_text_divider_sk',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'bwdbtt_style_selection' => ['style9', 'style19'],
				],
			]
		);

		$this->add_control(
			'bwdbtt_back_to_top_btn_color',
			[
				'label' => esc_html__( 'Background Color', 'bwd-back-to-top' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bwdbtt_background_and_main_common_style, {{WRAPPER}} .bwdbtt-progress-value-25' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'bwdbtt_back_to_top_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'bwd-back-to-top' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bwdbtt_background_and_main_common_style i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();

	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		if('style1' === $settings['bwdbtt_style_selection']){
		?>
			<a href="#" class="bwdbtt-scroll-to-top-1 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style"><i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i></a>
		<?php
		} elseif('style2' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-2 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style"><i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i></button>
		<?php
		} elseif('style3' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-3 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style"><i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i><i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i></button>
		<?php
		} elseif('style4' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-4 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style bwdbtt-blob1"><i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i></button>
		<?php
		} elseif('style5' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-5 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style"><i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i></button>
		<?php
		} elseif('style6' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-6 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style bwdbtt-scroll-to-target" data-target="html">
				<i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
			</button>
		<?php
		} elseif('style7' === $settings['bwdbtt_style_selection']){
		?>
			<div id="bwdbtt-scroll__up-7">
				<button id="bwdbtt-scroll-top" class="bwdbtt-scroll-to-top <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style"><i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i></button>
			</div>
		<?php
		} elseif('style8' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-8 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style"><i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i></button>
		<?php
		} elseif('style9' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-9 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style">
				<i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
				<span><?php echo esc_html($settings['bwdbtt_back_to_top_btn_text']); ?></span>
			</button>
		<?php
		} elseif('style10' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-top-10 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style">
				<i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
			</button>
		<?php
		} elseif('style11' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-top-11 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style">
				<i class="arrow-top <?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
				<i class="arrow-bottom <?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
			</button>
		<?php
		} elseif('style12' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-12 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style bwdbtt-scroll-to-target-12" data-target="html">
				<i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
			</button>
		<?php
		} elseif('style13' === $settings['bwdbtt_style_selection']){
		?>
			<div class="bwdbtt-scroll-to-top-13 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style">
				<a href="#" class="bwdbtt-scroll">
				<i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
				<i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
				</a>
			</div>
		<?php
		} elseif('style14' === $settings['bwdbtt_style_selection']){
		?>
			<div class="bwdbtt-scroll-to-top-14 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style">
				<i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?> bwdbtt-scrollup-icon"></i>
			</div>
		<?php
		} elseif('style15' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-15 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style">
				<i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
			</button>
		<?php
		} elseif('style16' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-16 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style">
				<i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
			</button>
		<?php
		} elseif('style17' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-17 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style">
				<i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
			</button>
		<?php
		} elseif('style18' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-18 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style">
				<i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
			</button>
		<?php
		} elseif('style19' === $settings['bwdbtt_style_selection']){
		?>
			<div class="bwdbtt-scroll-to-top-19 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style">
				<span><?php echo esc_html($settings['bwdbtt_back_to_top_btn_text']); ?></span>
			</div>
		<?php
		} elseif('style20' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-20 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style">
				<i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
			</button>
		<?php
		} elseif('style21' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-21 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style">
				<i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
			</button>
		<?php
		} elseif('style22' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-22 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style">
				<i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
			</button>
		<?php
		} elseif('style23' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-23 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style">
				<i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
			</button>
		<?php
		} elseif('style24' === $settings['bwdbtt_style_selection']){
		?>
			<button class="bwdbtt-scroll-to-top-24 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style">
				<i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i>
			</button>
		<?php
		} elseif('style25' === $settings['bwdbtt_style_selection']){
		?>
			<div id="bwdbtt-progress-25" class="bwdbtt-progress-25 <?php if('left' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-left <?php } elseif('center' === $settings['bwdbtt_back_to_top_btn_align']){ ?> bwdbtt-scroll-to-top-2-btn-alignment-center <?php } ?> bwdbtt_background_and_main_common_style">
				<span id="bwdbtt-progress-value-25" class="bwdbtt-progress-value-25"><i class="<?php echo esc_attr( $settings['bwdbtt_back_to_top_btn_icon_one']['value'] ); ?>"></i></span>
			</div>
		<?php
		}
	}

	protected function content_template() {
		?>
		<# if('style1' === settings['bwdbtt_style_selection']){ #>
			<a href="#" class="bwdbtt-scroll-to-top-1 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style"><i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i></a>
		<# } else if('style2' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-2 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style"><i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i></button>
		<# } else if('style3' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-3 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style"><i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i><i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i></button>
		<# } else if('style4' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-4 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style bwdbtt-blob1"><i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i></button>
		<# } else if('style5' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-5 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style"><i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i></button>
		<# } else if('style6' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-6 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style bwdbtt-scroll-to-target" data-target="html">
				<i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
			</button>
		<# } else if('style7' === settings['bwdbtt_style_selection']){ #>
			<div id="bwdbtt-scroll__up-7">
				<button id="bwdbtt-scroll-top" class="bwdbtt-scroll-to-top <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style"><i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i></button>
			</div>
		<# } else if('style8' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-8 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style"><i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i></button>
		<# } else if('style9' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-9 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style">
				<i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
				<span>{{{settings['bwdbtt_back_to_top_btn_text']}}}</span>
			</button>
		<# } else if('style10' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-top-10 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style">
				<i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
			</button>
		<# } else if('style11' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-top-11 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style">
				<i class="arrow-top {{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
				<i class="arrow-bottom {{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
			</button>
		<# } else if('style12' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-12 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style bwdbtt-scroll-to-target-12" data-target="html">
				<i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
			</button>
		<# } else if('style13' === settings['bwdbtt_style_selection']){ #>
			<div class="bwdbtt-scroll-to-top-13 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style">
				<a href="#" class="bwdbtt-scroll">
				<i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
				<i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
				</a>
			</div>
		<# } else if('style14' === settings['bwdbtt_style_selection']){ #>
			<div class="bwdbtt-scroll-to-top-14 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style">
				<i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}} bwdbtt-scrollup-icon"></i>
			</div>
		<# } else if('style15' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-15 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style">
				<i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
			</button>
		<# } else if('style16' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-16 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style">
				<i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
			</button>
		<# } else if('style17' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-17 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style">
				<i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
			</button>
		<# } else if('style18' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-18 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style">
				<i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
			</button>
		<# } else if('style19' === settings['bwdbtt_style_selection']){ #>
			<div class="bwdbtt-scroll-to-top-19 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style">
				<span>{{{settings['bwdbtt_back_to_top_btn_text']}}}</span>
			</div>
		<# } else if('style20' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-20 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style">
				<i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
			</button>
		<# } else if('style21' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-21 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style">
				<i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
			</button>
		<# } else if('style22' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-22 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style">
				<i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
			</button>
		<# } else if('style23' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-23 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style">
				<i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
			</button>
		<# } else if('style24' === settings['bwdbtt_style_selection']){ #>
			<button class="bwdbtt-scroll-to-top-24">
				<i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i>
			</button>
		<# } else if('style25' === settings['bwdbtt_style_selection']){ #>
			<div id="bwdbtt-progress-25" class="bwdbtt-progress-25 <# if('left' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-left <# } else if('center' === settings['bwdbtt_back_to_top_btn_align']){ #> bwdbtt-scroll-to-top-2-btn-alignment-center <# } #> bwdbtt_background_and_main_common_style">
				<span id="bwdbtt-progress-value-25" class="bwdbtt-progress-value-25"><i class="{{{settings['bwdbtt_back_to_top_btn_icon_one']['value']}}}"></i></span>
			</div>
		<# } #>
		<?php
	}
}
