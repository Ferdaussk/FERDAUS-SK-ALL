<?php
/**
 * Plugin Name: BWD Back To Top
 * Description: BWD Back To Top plugin with 20+ type of responsive designs also unlimited back to top buttons for Elementor.
 * Plugin URI:  https://bestwpdeveloper.com/plugins/elementor/bwd-back-to-top-elemetor-addon
 * Version:     1.0
 * Author:      Best WP Developer
 * Author URI:  https://bestwpdeveloper.com/
 * Text Domain: bwd-back-to-top
 * Elementor tested up to: 3.0.0
 * Elementor Pro tested up to: 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
require_once ( plugin_dir_path(__FILE__) ) . '/includes/class-tgm-plugin-activation.php';
final class BWDBTT_Back_To_Top{

	const VERSION = '1.0';

	const MINIMUM_ELEMENTOR_VERSION = '3.0.0';

	const MINIMUM_PHP_VERSION = '7.0';

	public function __construct() {
		// Load translation
		add_action( 'bwdbtt_init', array( $this, 'bwdbtt_loaded_textdomain' ) );
		// bwdbtt_init Plugin
		add_action( 'plugins_loaded', array( $this, 'bwdbtt_init' ) );
	}

	public function bwdbtt_loaded_textdomain() {
		load_plugin_textdomain( 'bwd-back-to-top' );
	}

	public function bwdbtt_init() {
		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			// For tgm plugin activation
			add_action( 'tgmpa_register', [$this, 'bwdbtt_back_top_register_required_plugins'] );
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', array( $this, 'bwdbtt_admin_notice_minimum_elementor_version' ) );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', array( $this, 'bwdbtt_admin_notice_minimum_php_version' ) );
			return;
		}

		// Once we get here, We have passed all validation checks so we can safely include our plugin
		require_once( 'bwdbtt_plugin_boots.php' );
	}

	function bwdbtt_back_top_register_required_plugins() {
		$plugins = array(
			array(
				'name'        => esc_html__('Elementor', 'bwd-back-to-top'),
				'slug'        => 'elementor',
				'is_callable' => 'wpseo_init',
			),
	
		);

		$config = array(
			'id'           => 'bwd-back-to-top',
			'default_path' => '',
			'menu'         => 'tgmpa-install-plugins',
			'parent_slug'  => 'plugins.php',
			'capability'   => 'manage_options',
			'has_notices'  => true,
			'dismissable'  => true,
			'dismiss_msg'  => '',
			'is_automatic' => false,
			'message'      => '',
		);
	
		tgmpa( $plugins, $config );
	}

	public function bwdbtt_admin_notice_minimum_elementor_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bwd-back-to-top' ),
			'<strong>' . esc_html__( 'BWD Back To Top', 'bwd-back-to-top' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'bwd-back-to-top' ) . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>' . esc_html__('%1$s', 'bwd-back-to-top') . '</p></div>', $message );
	}

	public function bwdbtt_admin_notice_minimum_php_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bwd-back-to-top' ),
			'<strong>' . esc_html__( 'BWD Back To Top', 'bwd-back-to-top' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'bwd-back-to-top' ) . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>' . esc_html__('%1$s', 'bwd-back-to-top') . '</p></div>', $message );
	}
}

// Instantiate bwd-back-to-top.
new BWDBTT_Back_To_Top();
remove_action( 'shutdown', 'wp_ob_end_flush_all', 1 );