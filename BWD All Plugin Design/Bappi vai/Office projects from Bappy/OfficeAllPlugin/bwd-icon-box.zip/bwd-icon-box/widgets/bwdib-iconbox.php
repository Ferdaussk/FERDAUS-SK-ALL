<?php
namespace Creativeiconbox\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class BWDIBIconbox extends \Elementor\Widget_Base {


	public function get_name() {
		return 'bwbib-icon-box';
	}

	public function get_title() {
		return esc_html__( 'BWD Icon Box', 'bwdib-icon-box' );
	}

	public function get_icon() {
		return ' eicon-info-box bwdib-icon-box';
	}

	public function get_categories() {
		return [ 'bwdib-icon-box-category' ];
	}

	public function get_keywords() {
		return [ 'icon box', 'icon', 'info box'. 'box' ];
	}

	public function get_script_depends() {
		return [ 'bwdib-icon-box-category' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'bwdib_pricing_choose_style',
		    [
		        'label' => esc_html__('Choose Style','bwdib-icon-box'),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
		   
		    ]
		);
		$this->add_control(
			'bwdib_icon_box_style',
			[
				'label' => esc_html__( 'Choose Style', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'bwdib-icon-box' ),
					'style2' => esc_html__( 'Style 2', 'bwdib-icon-box' ),
					'style3' => esc_html__( 'Style 3', 'bwdib-icon-box' ),
					'style4' => esc_html__( 'Style 4', 'bwdib-icon-box' ),
					'style5' => esc_html__( 'Style 5', 'bwdib-icon-box' ),
					'style6' => esc_html__( 'Style 6', 'bwdib-icon-box' ),
					'style7' => esc_html__( 'Style 7', 'bwdib-icon-box' ),
					'style8' => esc_html__( 'Style 8', 'bwdib-icon-box' ),
					'style9' => esc_html__( 'Style 9', 'bwdib-icon-box' ),
					'style10' => esc_html__( 'Style 10', 'bwdib-icon-box' ),
					'style11' => esc_html__( 'Style 11', 'bwdib-icon-box' ),
					'style12' => esc_html__( 'Style 12', 'bwdib-icon-box' ),
					'style13' => esc_html__( 'Style 13', 'bwdib-icon-box' ),
					'style14' => esc_html__( 'Style 14', 'bwdib-icon-box' ),
					'style15' => esc_html__( 'Style 15', 'bwdib-icon-box' ),
					'style16' => esc_html__( 'Style 16', 'bwdib-icon-box' ),
					'style17' => esc_html__( 'Style 17', 'bwdib-icon-box' ),
					'style18' => esc_html__( 'Style 18', 'bwdib-icon-box' ),
					'style19' => esc_html__( 'Style 19', 'bwdib-icon-box' ),
					'style20' => esc_html__( 'Style 20', 'bwdib-icon-box' ),
					'style21' => esc_html__( 'Style 21', 'bwdib-icon-box' ),
					'style22' => esc_html__( 'Style 22', 'bwdib-icon-box' ),
					'style23' => esc_html__( 'Style 23', 'bwdib-icon-box' ),
					'style24' => esc_html__( 'Style 24', 'bwdib-icon-box' ),
					'style25' => esc_html__( 'Style 25', 'bwdib-icon-box' ),
					'style26' => esc_html__( 'Style 26', 'bwdib-icon-box' ),
					'style27' => esc_html__( 'Style 27', 'bwdib-icon-box' ),
					'style28' => esc_html__( 'Style 28', 'bwdib-icon-box' ),
					'style29' => esc_html__( 'Style 29', 'bwdib-icon-box' ),
					'style30' => esc_html__( 'Style 30', 'bwdib-icon-box' ),
					'style31' => esc_html__( 'Style 31', 'bwdib-icon-box' ),
				],
			]
		);
		$this->add_control(
			'bwdib-icon-box_column_option',
			[
				'label' => esc_html__( 'Column', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '3',
				'options' => [
					'12'  => esc_html__( '1', 'bwdib-icon-box' ),
					'6' => esc_html__( '2', 'bwdib-icon-box' ),
					'4' => esc_html__( '3', 'bwdib-icon-box' ),
					'3' => esc_html__( '4', 'bwdib-icon-box' ),
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'bwdib_icon_box_content',
		    [
		        'label' => esc_html__('Content','bwdib-icon-box'),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
		   
		    ]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'bwdib_icon_box_icon',
			[
				'label' => esc_html__( 'Icon', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fa fa-globe',
					'library' => 'solid',
				],
			]
		);
		$repeater->add_control(
			'bwdib_icon_box_icon_color',
			[
				'label' => esc_html__( 'Color', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-icon-part, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-sub-icon, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-icon' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'bwdib_icon_box_icon_hover_color',
			[
				'label' => esc_html__( 'Icon Hover Color', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-icon-box-wrapper:hover .bwd-icon-part, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-icon-box-wrapper:hover .bwd-sub-icon, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-icon-box-wrapper:hover .bwd-service-icon' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'bwdib_icon_box_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-icon-bg-color, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-icon-bg-colorb::before, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-icon-bg-colora::after' => 'background-color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'bwdib_icon_box_shape_bg_color_heading',
			[
				'label' => esc_html__( 'Shape Bg Color', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'bwdib_icon_box_shape_bg_color',
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .bwd-all-shape, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-all-shapeb::before, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-all-shapea::after',
			]
		);
		$repeater->add_responsive_control(
			'bwdib_icon_box_icon_size',
			[
				'label' => esc_html__( 'Icon Size', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-icon-part, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-sub-icon, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$repeater->add_control(
			'bwdib_icon_box_title',
			[
				'label' => esc_html__( 'Title', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type your title here', 'bwdib-icon-box' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);
		$repeater->add_control(
			'bwdib_icon_box_title_color',
			[
				'label' => esc_html__( 'Color', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-icon-title' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'bwdib_icon_box_title_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-icon-box-wrapper:hover .bwd-icon-title' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwdib_icon_box_title_typography',
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .bwd-icon-title',
			]
		);
		$repeater->add_control(
			'bwdib_icon_box_description',
			[
				'label' => esc_html__( 'Description', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Type your description here', 'bwdib-icon-box' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);
		$repeater->add_control(
			'bwdib_icon_box_description_color',
			[
				'label' => esc_html__( 'Color', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-icon-description' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'bwdib_icon_box_description_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-icon-box-wrapper:hover .bwd-icon-description' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwdib_icon_box_description_typography',
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .bwd-icon-description',
			]
		);
		$this->add_control(
			'bwdib_icon_box_list',
			[
				'label' => esc_html__( 'Content', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'bwdib_icon_box_title' => esc_html__( 'Title #1', 'bwdib-icon-box' ),
						'bwdib_icon_box_description' => esc_html__( 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iure odio eius incidunt autem quia ipsam!', 'bwdib-icon-box' ),
					],
					[
						'bwdib_icon_box_title' => esc_html__( 'Title #2', 'bwdib-icon-box' ),
						'bwdib_icon_box_description' => esc_html__( 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iure odio eius incidunt autem quia ipsam!', 'bwdib-icon-box' ),
					],
					[
						'bwdib_icon_box_title' => esc_html__( 'Title #3', 'bwdib-icon-box' ),
						'bwdib_icon_box_description' => esc_html__( 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iure odio eius incidunt autem quia ipsam!', 'bwdib-icon-box' ),
					],
					[
						'bwdib_icon_box_title' => esc_html__( 'Title #4', 'bwdib-icon-box' ),
						'bwdib_icon_box_description' => esc_html__( 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iure odio eius incidunt autem quia ipsam!', 'bwdib-icon-box' ),
					],
				],
				'title_field' => '{{{ bwdib_icon_box_title }}}',
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'bwdib_icon_box_style_tab',
			[
				'label' => esc_html__('Content','bwdib-icon-box'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		   
			]
		);
		$this->start_controls_tabs(
			'bwdib_icon_box_style_tabs'
		);
		$this->start_controls_tab(
			'bwdib_icon_box_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'bwdib-icon-box' ),
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'bwdib_icon_box_background',
				'label' => esc_html__( 'Background', 'bwdib-icon-box' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .bwd-icon-box-wrapper-bg, {{WRAPPER}} .bwd-icon-box-wrapper-bgb::before',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'bwdib_icon_box_border',
				'label' => esc_html__( 'Border', 'bwdib-icon-box' ),
				'selector' => '{{WRAPPER}} .bwd-icon-box-wrapper-bg',
			]
		);
		$this->add_responsive_control(
			'bwdib_icon_box_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .bwd-icon-box-wrapper, {{WRAPPER}} .bwd-icon-content-part' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'bwdib_icon_box_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'bwdib-icon-box' ),
				'selector' => '{{WRAPPER}} .bwd-icon-box-wrapper',
			]
		);
		$this->add_responsive_control(
			'bwdib_icon_box_margin',
			[
				'label' => esc_html__( 'Margin', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .bwd-icon-box-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'bwdib_icon_box_padding',
			[
				'label' => esc_html__( 'Padding', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .bwd-icon-box-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'bwdib_icon_box_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'bwdib-icon-box' ),
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'bwdib_icon_box_hover_background',
				'label' => esc_html__( 'Background', 'bwdib-icon-box' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .bwd-icon-box-wrapper:hover .bwd-icon-box-wrapper-bg, {{WRAPPER}} .bwd-icon-box-wrapper:hover .bwd-icon-box-wrapper-bgb',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'bwdib_icon_box_hover_border',
				'label' => esc_html__( 'Border', 'bwdib-icon-box' ),
				'selector' => '{{WRAPPER}} .bwd-icon-box-wrapper:hover',
			]
		);
		$this->add_responsive_control(
			'bwdib_icon_box_hover_border_radius',
			[
				'label' => esc_html__( 'Border radius', 'bwdib-icon-box' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .bwd-icon-box-wrapper:hover, {{WRAPPER}} .bwd-icon-box-wrapper:hover .bwd-icon-content-part' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'bwdib_icon_box_hover_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'bwdib-icon-box' ),
				'selector' => '{{WRAPPER}} .bwd-icon-box-wrapper:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section()
;    }
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ('style1' === $settings['bwdib_icon_box_style']) { 
		?>
		<div class="bwd-icon-box-1">
			<div class="container-fluid">
				<div class="row">
				<?php   
					if( $settings['bwdib_icon_box_list'] ) {
						foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>

						<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
						<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
							<div class="bwd-icon-box-wrapper">
								<div class="bwd-wrapper-box">
									<div class="bwd-sub-icon">
										<div class="bwd-icon-part bwd-icon-bg-color">
											<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
										</div>
									</div>
									<div class="bwd-icon-content-part bwd-icon-box-wrapper-bg">
										<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
										<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?> </div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</div>
		<?php
		} elseif ('style2' === $settings['bwdib_icon_box_style']) {
		?>
		<div class="bwd-icon-box-2">
			<div class="container-fluid">
				<div class="row">
				<?php   
					if( $settings['bwdib_icon_box_list'] ) {
						foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>

						<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
						<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
							<div class="bwd-icon-box-wrapper">
								<div class="bwd-wrapper-box">
									<div class="bwd-box-shado">
										<div class="bwd-sub-icon">
											<div class="bwd-icon-part bwd-icon-bg-color">
												<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
											</div>
										</div>
									</div>
									<div class="bwd-icon-content-part bwd-icon-box-wrapper-bg">
										<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
										<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
									</div>
									<div class="bwd-box-footer bwd-all-shape">
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</div>
		<?php	
		} elseif ('style3' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-3">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-wrapper-box">
										<div class="bwd-box-shado bwd-all-shapeb">
											<div class="bwd-sub-icon">
												<div class="bwd-icon-part bwd-icon-bg-color">
													<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
												</div>
											</div>
										</div>
											<div class="bwd-icon-content-part bwd-icon-box-wrapper-bg">
											<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
											<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style4' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-4">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-wrapper-box">
										<div class="bwd-sub-icon bwd-all-shape">
											<div class="bwd-icon-part bwd-icon-bg-color">
												<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
											</div>
										</div>
										<div class="bwd-icon-content-part bwd-icon-box-wrapper-bg">
											<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
											<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
										</div>
										<div class="bwd-footer-part bwd-all-shapeb"></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style5' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-5">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part">
										<div class="bwd-sub-icon bwd-all-shape bwd-all-shapeb">
											<div class="bwd-icon-part bwd-icon-bg-color">
												<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
											</div>
										</div>
										<div class="bwd-icon-content-part bwd-icon-box-wrapper-bg">
											<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
											<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
										</div>
										<div class="bwd-footer-part bwd-all-shape"></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style6' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-6">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-all-shapeb bwd-icon-box-wrapper-bg">
										<div class="bwd-sub-icon">
											<div class="bwd-icon-part bwd-icon-bg-color">
												<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
											</div>
										</div>
										<div class="bwd-icon-content-part">
											<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
											<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
										</div>
										<div class="bwd-footer-part bwd-all-shape">
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style7' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-7">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-all-shapeb bwd-all-shapea bwd-icon-box-wrapper-bg">
										<div class="bwd-sub-icon">
											<div class="bwd-icon-part bwd-icon-bg-color">
												<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
											</div>
										</div>
										<div class="bwd-icon-content-part">
											<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
											<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style8' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-8">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part">
										<div class="bwd-sub-icon bwd-all-shape bwd-all-shapeb bwd-all-shapea">
											<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
										</div>
										<div class="bwd-icon-content-part bwd-icon-box-wrapper-bg">
											<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
											<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
										</div>
										<div class="bwd-footer-part bwd-all-shapeb">
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style9' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-9">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-all-shapeb">
										<div class="bwd-sub-icon bwd-all-shape">
											<div class="bwd-icon-part bwd-icon-bg-color">
												<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
											</div>
										</div>
										<div class="bwd-icon-content-part bwd-icon-box-wrapper-bg">
											<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
											<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
										</div>
										<div class="bwd-footer-part bwd-all-shape"></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style10' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-10">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-all-shapeb bwd-all-shapea bwd-icon-box-wrapper-bg">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
										</div>
										<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
										<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php	
		} elseif ('style11' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-11">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-all-shapeb bwd-icon-box-wrapper-bg">
										<div class="bwd-sub-icon bwd-all-shape">
											<div class="bwd-icon-part bwd-icon-bg-color">
												<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
											</div>
										</div>
										<div class="bwd-icon-content-part">
											<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
											<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
										</div>
										<div class="bwd-footer-part bwd-all-shape">
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style12' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-12">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-icon-box-wrapper-bg">
										<div class="bwd-sub-icon bwd-all-shape bwd-all-shapeb bwd-all-shapea">
											<div class="bwd-icon-part">
												<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
											</div>
										</div>
										<div class="bwd-icon-content-part">
											<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
											<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
										</div>
										<div class="bwd-footer-part bwd-all-shape">
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style13' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-13">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-icon-box-wrapper-bg">
										<div class="bwd-sub-icon bwd-all-shapeb">
											<div class="bwd-icon-part bwd-icon-box-wrapper-bg">
												<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
											</div>
										</div>
										<div class="bwd-icon-content-part">
											<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
											<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
										</div>
										<div class="bwd-footer-part bwd-all-shapeb">
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style14' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-14">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part">
										<div class="bwd-sub-icon bwd-all-shape">
											<div class="bwd-icon-part">
												<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
											</div>
										</div>
										<div class="bwd-icon-content-part bwd-icon-box-wrapper-bg">
											<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
											<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
										</div>
										<div class="bwd-footer-part bwd-all-shape">
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style15' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-15">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-all-shapeb bwd-icon-box-wrapper-bg">
										<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
										<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style16' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-16">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part">
										<div class="bwd-first-box">
											<div class="bwd-sub-icon">
												<div class="bwd-icon-part bwd-icon-bg-color">
													<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
												</div>
											</div>
										</div>
										<div class="bwd-icon-content-part bwd-icon-box-wrapper-bg">
											<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
											<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
										</div>
										<div class="bwd-footer-part"></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style17' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-17">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-icon-box-wrapper-bg">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
										</div>
										<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
										<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style18' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-18">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-icon-box-wrapper-bgb">
										<div class="bwd-icon-title bwd-all-shape"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
										<div class="bwd-service-icon bwd-icon-bg-color">
											<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
										</div>
										<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style19' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-19">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-icon-box-wrapper-bgb">
										<div class="bwd-service-icon bwd-icon-bg-color">
											<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
										</div>
										<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
										<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style20' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-20">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part">
										<div class="bwd-service-icon bwd-all-shape bwd-icon-bg-color">
											<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
										</div>
										<div class="bwd-service-content bwd-all-shape bwd-icon-box-wrapper-bgb">
											<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
											<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style21' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-21">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-icon-box-wrapper-bg bwd-all-shapeb bwd-all-shapea">
										<div class="bwd-service-icon bwd-all-shapeb bwd-all-shape">
											<div class="bwd-icon-box bwd-all-shapeb bwd-all-shapea">
												<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
											</div>
										</div>
										<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
										<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style22' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-22">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-icon-box-wrapper-bg">
										<div class="bwd-service-icon bwd-icon-bg-color">
											<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
											<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style23' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-23">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-icon-box-wrapper-bg">
										<div class="bwd-service-content bwd-all-shape">
											<div class="bwd-service-icon bwd-icon-bg-color">
												<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
											</div>
											<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
										</div>
										<div class="bwd-icon-description bwd-all-shapea"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style24' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-24">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-all-shapeb bwd-icon-box-wrapper-bg">
										<div class="bwd-service-icon bwd-all-shape bwd-all-shapea">
											<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
										</div>
										<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
										<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style25' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-25">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-all-shapeb">
										<div class="bwd-service-icon bwd-icon-bg-color bwd-icon-bg-colorb">
											<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
										</div>
										<div class="bwd-service-content bwd-icon-box-wrapper-bg">
											<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
											<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style26' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-26">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-all-shape bwd-icon-box-wrapper-bgb">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
										</div>
										<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
										<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style27' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-27">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-icon-box-wrapper-bg">
										<div class="bwd-service-icon bwd-all-shapea bwd-icon-bg-color">
											<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
										</div>
										<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
										<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style28' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-28">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-icon-box-wrapper-bg">
										<div class="bwd-service-icon bwd-all-shape bwd-all-shapeb bwd-icon-bg-colorb">
											<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
										</div>
										<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
										<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style29' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-29">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-icon-box-wrapper-bg">
										<div class="bwd-service-icon bwd-all-shapeb bwd-icon-bg-colora">
											<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
										</div>
										<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
										<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style30' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-30">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-all-shapeb bwd-icon-box-wrapper-bg">
										<div class="bwd-service-icon bwd-icon-bg-color">
											<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
										</div>
										<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
										<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style31' === $settings['bwdib_icon_box_style']) {
			?>
			<div class="bwd-icon-box-31">
				<div class="container-fluid">
					<div class="row">
					<?php   
						if( $settings['bwdib_icon_box_list'] ) {
							foreach( $settings['bwdib_icon_box_list'] as $item ) { ?>
	
							<div class="col-xl-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-sm-<?php echo esc_attr( $settings['bwdib-icon-box_column_option'] ); ?> col-lg-4 col-sm-6">
							<?php echo '<div class="elementor-repeater-item-' . esc_attr__( $item['_id'] ) . '">'; ?>
								<div class="bwd-icon-box-wrapper">
									<div class="bwd-box-part bwd-all-shapeb bwd-icon-box-wrapper-bg">
										<div class="bwd-service-icon bwd-all-shape bwd-all-shapeb">
											<div class="bwd-icon-part bwd-icon-bg-color">
												<i class="<?php echo esc_attr__( $item['bwdib_icon_box_icon']['value'] ); ?>"></i>
											</div>
										</div>
										<div class="bwd-icon-title"><?php echo esc_html__( $item['bwdib_icon_box_title'] ); ?></div>
										<div class="bwd-icon-description"><?php echo esc_html__( $item['bwdib_icon_box_description'] ); ?></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
		}
	}
}