<?php
namespace BWDEEOEasyEventOffer\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class BWDEEO_Event_Offer extends Widget_Base {

	public function get_name() {
		return esc_html__( 'BWDPromoBox', 'bwd-promo-box' );
	}

	public function get_title() {
		return esc_html__( 'BWD Promo Box', 'elementor' );
	}

	public function get_icon() {
		return 'bwdeeo-band-icon eicon-hypster';
	}

	public function get_categories() {
		return [ 'bwdeeo-easy-event-offer-category' ];
	}

	public function get_script_depends() {
		return [ 'bwd-promo-box-category' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'bwdeeo_text_content_section',
			[
				'label' => esc_html__( 'Promo Box Content', 'bwd-promo-box' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'bwdeeo_style_selection',
			[
				'label' => esc_html__( 'Promo Box Style', 'bwd-promo-box' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'bwd-promo-box' ),
					'style2' => esc_html__( 'Style 2', 'bwd-promo-box' ),
					'style3' => esc_html__( 'Style 3', 'bwd-promo-box' ),
					'style4' => esc_html__( 'Style 4', 'bwd-promo-box' ),
					'style5' => esc_html__( 'Style 5', 'bwd-promo-box' ),
					'style6' => esc_html__( 'Style 6', 'bwd-promo-box' ),
					'style7' => esc_html__( 'Style 7', 'bwd-promo-box' ),
					'style8' => esc_html__( 'Style 8', 'bwd-promo-box' ),
					'style9' => esc_html__( 'Style 9', 'bwd-promo-box' ),
					'style10' => esc_html__( 'Style 10', 'bwd-promo-box' ),
					'style11' => esc_html__( 'Style 11', 'bwd-promo-box' ),
					'style12' => esc_html__( 'Style 12', 'bwd-promo-box' ),
					'style13' => esc_html__( 'Style 13', 'bwd-promo-box' ),
					'style14' => esc_html__( 'Style 14', 'bwd-promo-box' ),
					'style15' => esc_html__( 'Style 15', 'bwd-promo-box' ),
					'style16' => esc_html__( 'Style 16', 'bwd-promo-box' ),
					'style17' => esc_html__( 'Style 17', 'bwd-promo-box' ),
					'style18' => esc_html__( 'Style 18', 'bwd-promo-box' ),
					'style19' => esc_html__( 'Style 19', 'bwd-promo-box' ),
					'style20' => esc_html__( 'Style 20', 'bwd-promo-box' ),
					'style21' => esc_html__( 'Style 21', 'bwd-promo-box' ),
					'style22' => esc_html__( 'Style 22', 'bwd-promo-box' ),
					'style23' => esc_html__( 'Style 23', 'bwd-promo-box' ),
					'style24' => esc_html__( 'Style 24', 'bwd-promo-box' ),
					'style25' => esc_html__( 'Style 25', 'bwd-promo-box' ),
					'style26' => esc_html__( 'Style 26', 'bwd-promo-box' ),
					'style27' => esc_html__( 'Style 27', 'bwd-promo-box' ),
					'style28' => esc_html__( 'Style 28', 'bwd-promo-box' ),
					'style29' => esc_html__( 'Style 29', 'bwd-promo-box' ),
					'style30' => esc_html__( 'Style 30', 'bwd-promo-box' ),
					'style31' => esc_html__( 'Style 31', 'bwd-promo-box' ),
				],
			]
		);
		$this->add_control(
			'bwdeeo_content_link_box',
			[
				'label' => esc_html__( 'Link', 'bwd-promo-box' ),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__( 'http://www.your-link.com', 'bwd-promo-box' ),
				'default' => [
					'url' => 'http://www.google.com',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
			]
		);

		$this->add_control(
			'bwdeeo_event_event_sk',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'bwdeeo_content_title',
			[
				'label' => esc_html__( 'Title', 'bwd-promo-box' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('BIG SALE', 'bwd-promo-box'),
				'label_block' => true,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwdeeo_box_title_typography',
				'selector' => '{{WRAPPER}} .bwdeeo_box_common .bwdeeo_title',
			]
		);
		$this->add_control(
			'bwdeeo_content_title_color',
			[
				'label' => esc_html__( 'Color', 'bwd-promo-box' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bwdeeo_box_common .bwdeeo_title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'bwdeeo_content_title_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'bwd-promo-box' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bwdeeo_box_common:hover .bwdeeo_title' => 'color: {{VALUE}}'
				],
			]
		);

		$this->add_control(
			'bwdeeo_event_subtitle',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		// Style 10 start
		$this->add_control(
			'bwdeeo_content_title_style10',
			[
				'label' => esc_html__( 'Title', 'bwd-promo-box' ),
				'type' => Controls_Manager::TEXT,
				'condition' => [
					'bwdeeo_style_selection' => 'style10',
				],
				'default' => esc_html__('SALE', 'bwd-promo-box'),
				'label_block' => true,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwdeeo_box_title_typography_style10',
				'selector' => '{{WRAPPER}} .bwdeeo_box_common .bwdeeo_title-color, {{WRAPPER}} .bwdeeo_creative-design_10 .bwdeeo_wraper_10 .bwdeeo_shape_1 .bwdeeo_content .bwdeeo_title .bwdeeo_title-color',
				'condition' => [
					'bwdeeo_style_selection' => 'style10',
				],
			]
		);
		$this->add_control(
			'bwdeeo_content_title_color_style10',
			[
				'label' => esc_html__( 'Color', 'bwd-promo-box' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'bwdeeo_style_selection' => 'style10',
				],
				'selectors' => [
					'{{WRAPPER}} .bwdeeo_box_common .bwdeeo_title-color, {{WRAPPER}} .bwdeeo_creative-design_10 .bwdeeo_wraper_10 .bwdeeo_shape_1 .bwdeeo_content .bwdeeo_title .bwdeeo_title-color' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'bwdeeo_content_title_hover_color_style10',
			[
				'label' => esc_html__( 'Hover Color', 'bwd-promo-box' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'bwdeeo_style_selection' => 'style10',
				],
				'selectors' => [
					'{{WRAPPER}} .bwdeeo_box_common:hover .bwdeeo_title-color, {{WRAPPER}} .bwdeeo_creative-design_10 .bwdeeo_wraper_10:hover .bwdeeo_shape_1 .bwdeeo_content .bwdeeo_title .bwdeeo_title-color' => 'color: {{VALUE}}'
				],
			]
		);

		$this->add_control(
			'bwdeeo_event_subtitle_style10',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'bwdeeo_style_selection' => 'style10',
				],
			]
		);
		// Style 10 end
		
		$this->add_control(
			'bwdeeo_content_subtitle',
			[
				'label' => esc_html__( 'Sub Title', 'bwd-promo-box' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('LIMITED', 'bwd-promo-box'),
				'label_block' => true,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwdeeo_box_subtitle_typography',
				'selector' => '{{WRAPPER}} .bwdeeo_box_common .bwdeeo_offer',
			]
		);
		$this->add_control(
			'bwdeeo_content_subtitle_color',
			[
				'label' => esc_html__( 'Color', 'bwd-promo-box' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bwdeeo_box_common .bwdeeo_offer' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'bwdeeo_content_subtitle_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'bwd-promo-box' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bwdeeo_box_common:hover .bwdeeo_offer' => 'color: {{VALUE}}'
				],
			]
		);

		$this->add_control(
			'bwdeeo_event_event',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'bwdeeo_content_event',
			[
				'label' => esc_html__( 'Event', 'bwd-promo-box' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('20% Off', 'bwd-promo-box'),
				'label_block' => true,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwdeeo_box_event_typography',
				'selector' => '{{WRAPPER}} .bwdeeo_box_common .bwdeeo_persent, {{WRAPPER}} .bwdeeo_creative-design_8 .bwdeeo_wraper_8 .bwdeeo_shape_1 .bwdeeo_persent .bwdeeo_persent_color',
			]
		);
		$this->add_control(
			'bwdeeo_content_event_color',
			[
				'label' => esc_html__( 'Color', 'bwd-promo-box' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bwdeeo_box_common .bwdeeo_persent, {{WRAPPER}} .bwdeeo_creative-design_8 .bwdeeo_wraper_8 .bwdeeo_shape_1 .bwdeeo_persent .bwdeeo_persent_color' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'bwdeeo_content_event_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'bwd-promo-box' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bwdeeo_box_common:hover .bwdeeo_persent, {{WRAPPER}} .bwdeeo_creative-design_8 .bwdeeo_wraper_8:hover .bwdeeo_shape_1 .bwdeeo_persent .bwdeeo_persent_color' => 'color: {{VALUE}}'
				],
			]
		);

		$this->add_control(
			'bwdeeo_event_event_sk_expration',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		// Style 9 start
		$this->add_control(
			'bwdeeo_content_event_style9',
			[
				'label' => esc_html__( 'Event', 'bwd-promo-box' ),
				'type' => Controls_Manager::TEXT,
				'condition' => [
					'bwdeeo_style_selection' => 'style9',
				],
				'default' => esc_html__('Up to', 'bwd-promo-box'),
				'label_block' => true,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwdeeo_box_event_typography_style9',
				'condition' => [
					'bwdeeo_style_selection' => 'style9',
				],
				'selector' => '{{WRAPPER}} .bwdeeo_box_common .bwdeeo_persent_color',
			]
		);
		$this->add_control(
			'bwdeeo_content_event_color_style9',
			[
				'label' => esc_html__( 'Color', 'bwd-promo-box' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'bwdeeo_style_selection' => 'style9',
				],
				'selectors' => [
					'{{WRAPPER}} .bwdeeo_box_common .bwdeeo_persent_color' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'bwdeeo_content_event_hover_color_style9',
			[
				'label' => esc_html__( 'Hover Color', 'bwd-promo-box' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'bwdeeo_style_selection' => 'style9',
				],
				'selectors' => [
					'{{WRAPPER}} .bwdeeo_box_common:hover .bwdeeo_persent_color' => 'color: {{VALUE}}'
				],
			]
		);

		$this->add_control(
			'bwdeeo_event_event_sk_expration_style9',
			[
				'type' => Controls_Manager::DIVIDER,
				'condition' => [
					'bwdeeo_style_selection' => 'style9',
				],
			]
		);
		// Style 9 end

		$this->end_controls_section();

		$this->start_controls_section(
			'bwdeeo_event_style_section',
			[
				'label' => esc_html__( 'Promo Box Style', 'bwd-promo-box' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'bwdeeo_event_section_background',
				'label' => esc_html__( 'Background', 'bwd-promo-box' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .bwdeeo_web_developer',
			]
		);
		$this->add_responsive_control(
            'bwdeeo_event_the_box_margin',
            [
                'label' => esc_html__('Margin', 'bwd-promo-box'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'rem', 'vh'],
                'selectors' => [
                    '{{WRAPPER}} .bwdeeo_web_developer' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
            'bwdeeo_event_the_box_padding',
            [
                'label' => esc_html__('Padding', 'bwd-promo-box'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%', 'rem', 'vh'],
                'selectors' => [
                    '{{WRAPPER}} .bwdeeo_web_developer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->end_controls_section();

	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		// Social Link
		if ( ! empty( $settings['bwdeeo_content_link_box']['url'] ) ) {
			$this->add_link_attributes( 'bwdeeo_content_link_box', $settings['bwdeeo_content_link_box'] );
		}
		if('style1' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_1">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_1">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_1/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_1/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_content_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style2' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_2">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_2">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_2/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_2/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_2/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_2/img4.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_5">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_2/img5.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style3' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_3">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_3">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_3/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_3/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_3/img3.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style4' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_4">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_4">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_4/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_persent">
							<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
						</div>
						<div class="bwdeeo_sub_offer">
						<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_4/img2.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_4/img3.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style5' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_5">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_5">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_5/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_5/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_5/img3.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_5/img4.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style6' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_6">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_6">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_6/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_6/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_6/img3.png' ?>" alt="Have Image"3>
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style7' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_7">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_7">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_7/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_persent">
							<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_7/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_7/img3.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style8' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_8">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_8">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_8/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><div class="bwdeeo_title-color"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div></div>
						</div>
						<div class="bwdeeo_sub_persent">
							<div class="bwdeeo_persent"> <div class="bwdeeo_persent_color"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div></div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_8/img2.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_8/img3.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style9' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_9">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_9">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_9/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_sub_persent">
							<div class="bwdeeo_persent"><div class="bwdeeo_persent_color"><?php echo esc_html($settings['bwdeeo_content_event_style9']); ?></div> <?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_9/img2.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_9/img3.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style10' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_10">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_10">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_10/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?><div class="bwdeeo_title-color"><?php echo esc_html($settings['bwdeeo_content_title_style10']); ?></div></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_10/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_10/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"> 
									<div class="bwdeeo_persent_color"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style11' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_11">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_11">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_11/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_11/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_11/img3.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_11/img4.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style12' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_12">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_12">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_12/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_12/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_12/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_12/img4.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style13' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_13">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_13">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_13/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_13/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_13/img3.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style14' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_14">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_14">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_14/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_14/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_14/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_14/img4.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_5">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_14/img5.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style15' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_15">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_15">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_15/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_15/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_14/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_15/img4.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style16' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_16">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_16">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_16/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_16/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style17' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_17">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_17">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_17/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_persent">
							<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_17/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style18' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_18">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_18">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_18/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_18/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_18/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_18/img4.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_5">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_18/img5.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style19' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_19">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_19">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_19/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_persent">
							<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_19/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_19/img3.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_19/img4.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_5">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_19/img5.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_6">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_19/img5.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style20' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_20">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_20">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_20/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_20/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_20/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_20/img4.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_5">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_20/img5.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style21' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_21">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_21">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_21/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_21/img2.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_21/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_21/img4.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_5">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_21/img5.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style22' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_22">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_22">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_22/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_22/img2.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_22/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_22/img4.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style23' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_23">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_23">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_23/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_23/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style24' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_24">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_24">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_24/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_sub_persent">
							<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style25' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_25">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_25">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_25/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_25/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style26' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_26">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_26">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_26/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_26/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style27' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_27">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_27">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_27/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_27/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style28' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_28">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_28">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_28/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_28/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style29' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_29">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_29">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_29/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_29/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_29/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style30' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_30">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_30">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_30/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_30/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_30/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		} elseif('style31' === $settings['bwdeeo_style_selection']){
		?>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_31">
			<a href="<?php echo esc_url($settings['bwdeeo_content_link_box']['url']); ?>">
				<div class="bwdeeo_box_common bwdeeo_wraper_31">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_31/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><?php echo esc_html($settings['bwdeeo_content_title']); ?></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_31/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"><?php echo esc_html($settings['bwdeeo_content_event']); ?></div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_31/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer"><?php echo esc_html($settings['bwdeeo_content_subtitle']); ?></div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<?php
		}
	}

	protected function content_template() {
		?>
		<# if('style1' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_1">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_1">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_1/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_1/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_content_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style2' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_2">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_2">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_2/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_2/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_2/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_2/img4.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_5">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_2/img5.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style3' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_3">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_3">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_3/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_3/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_3/img3.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style4' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_4">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_4">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_4/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_persent">
							<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
						</div>
						<div class="bwdeeo_sub_offer">
						<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_4/img2.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_4/img3.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style5' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_5">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_5">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_5/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_5/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_5/img3.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_5/img4.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style6' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_6">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_6">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_6/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_6/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_6/img3.png' ?>" alt="Have Image"3>
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style7' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_7">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_7">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_7/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_persent">
							<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_7/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_7/img3.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style8' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_8">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_8">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_8/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title"><div class="bwdeeo_title-color">{{{settings['bwdeeo_content_title']}}}</div></div>
						</div>
						<div class="bwdeeo_sub_persent">
							<div class="bwdeeo_persent"> <div class="bwdeeo_persent_color">{{{settings['bwdeeo_content_event']}}}</div></div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_8/img2.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_8/img3.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style9' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_9">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_9">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_9/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_sub_persent">
							<div class="bwdeeo_persent"><div class="bwdeeo_persent_color">{{{settings['bwdeeo_content_event_style9']}}}</div>{{{settings['bwdeeo_content_event']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_9/img2.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_9/img3.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style10' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_10">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_10">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_10/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}<div class="bwdeeo_title-color">{{{settings['bwdeeo_content_title_style10']}}}</div></div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_10/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_10/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent"> 
									<div class="bwdeeo_persent_color">{{{settings['bwdeeo_content_event']}}}</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style11' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_11">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_11">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_11/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_11/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_11/img3.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_11/img4.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style12' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_12">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_12">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_12/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_12/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_12/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_12/img4.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style13' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_13">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_13">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_13/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_13/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_13/img3.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style14' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_14">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_14">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_14/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_14/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_14/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_14/img4.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_5">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_14/img5.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style15' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_15">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_15">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_15/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_15/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_14/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_15/img4.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style16' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_16">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_16">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_16/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_16/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style17' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_17">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_17">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_17/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_persent">
							<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_17/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style18' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_18">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_18">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_18/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_18/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_18/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_18/img4.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_5">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_18/img5.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style19' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_19">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_19">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_19/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_persent">
							<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_19/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_19/img3.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_19/img4.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_5">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_19/img5.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_6">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_19/img5.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style20' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_20">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_20">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_20/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_20/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_20/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_20/img4.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_5">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_20/img5.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style21' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_21">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_21">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_21/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_21/img2.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_21/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_21/img4.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_5">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_21/img5.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style22' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_22">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_22">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_22/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_22/img2.png' ?>" alt="Have Image">
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_22/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_4">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_22/img4.png' ?>" alt="Have Image">
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style23' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_23">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_23">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_23/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_23/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style24' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_24">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_24">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_24/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_sub_persent">
							<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style25' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_25">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_25">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_25/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_25/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style26' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_26">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_26">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_26/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_26/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style27' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_27">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_27">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_27/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_27/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style28' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_28">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_28">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_28/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_sub_offer">
							<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_28/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style29' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_29">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_29">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_29/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_29/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_29/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style30' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_30">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_30">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_30/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_30/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_30/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } else if('style31' === settings['bwdeeo_style_selection']){ #>
		<div class="bwdeeo_web_developer bwdeeo_creative-design_31">
			<a href="{{{settings['bwdeeo_content_link_box']['url']}}}">
				<div class="bwdeeo_box_common bwdeeo_wraper_31">
					<div class="bwdeeo_shape_1">
						<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_31/img1.png' ?>" alt="Have Image">
						<div class="bwdeeo_content">
							<div class="bwdeeo_title">{{{settings['bwdeeo_content_title']}}}</div>
						</div>
						<div class="bwdeeo_shape_2">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_31/img2.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_persent">
								<div class="bwdeeo_persent">{{{settings['bwdeeo_content_event']}}}</div>
							</div>
						</div>
						<div class="bwdeeo_shape_3">
							<img src="<?php echo plugin_dir_url( __FILE__ ).'../assets/public/image/design_31/img3.png' ?>" alt="Have Image">
							<div class="bwdeeo_sub_offer">
								<div class="bwdeeo_offer">{{{settings['bwdeeo_content_subtitle']}}}</div>
							</div>
						</div>
					</div>
				</div>
			</a>
		</div>
		<# } #>
		<?php
	}
}
