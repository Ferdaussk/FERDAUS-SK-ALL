<?php
namespace DualHeadingFromBWD\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class BWDDHHeading extends Widget_Base {

	public function get_name() {
		return esc_html__( 'NameDualHeading', 'bwd-dual-heading' );
	}

	public function get_title() {
		return esc_html__( 'BWD Dual Heading', 'elementor' );
	}

	public function get_icon() {
		return 'bwddh-heading-icon eicon-heading';
	}

	public function get_categories() {
		return [ 'bwd-dual-heading-category' ];
	}

	public function get_script_depends() {
		return [ 'bwd-dual-heading-category' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'bwddh_heading_content_section',
			[
				'label' => esc_html__( 'Heading Content', 'bwd-dual-heading' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'bwddh_style_selection',
			[
				'label' => esc_html__( 'Heading Styles', 'bwd-dual-heading' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1' => esc_html__( 'Style 1', 'bwd-dual-heading' ),
					'style2' => esc_html__( 'Style 2', 'bwd-dual-heading' ),
					'style3' => esc_html__( 'Style 3', 'bwd-dual-heading' ),
					'style4' => esc_html__( 'Style 4', 'bwd-dual-heading' ),
					'style5' => esc_html__( 'Style 5', 'bwd-dual-heading' ),
					'style6' => esc_html__( 'Style 6', 'bwd-dual-heading' ),
					'style7' => esc_html__( 'Style 7', 'bwd-dual-heading' ),
					'style8' => esc_html__( 'Style 8', 'bwd-dual-heading' ),
					'style9' => esc_html__( 'Style 9', 'bwd-dual-heading' ),
					'style10' => esc_html__( 'Style 10', 'bwd-dual-heading' ),
					'style11' => esc_html__( 'Style 11', 'bwd-dual-heading' ),
					'style12' => esc_html__( 'Style 12', 'bwd-dual-heading' ),
					'style13' => esc_html__( 'Style 13', 'bwd-dual-heading' ),
					'style14' => esc_html__( 'Style 14', 'bwd-dual-heading' ),
					'style15' => esc_html__( 'Style 15', 'bwd-dual-heading' ),
					'style16' => esc_html__( 'Style 16', 'bwd-dual-heading' ),
					'style17' => esc_html__( 'Style 17', 'bwd-dual-heading' ),
					'style18' => esc_html__( 'Style 18', 'bwd-dual-heading' ),
					'style19' => esc_html__( 'Style 19', 'bwd-dual-heading' ),
					'style20' => esc_html__( 'Style 20', 'bwd-dual-heading' ),
					'style21' => esc_html__( 'Style 21', 'bwd-dual-heading' ),
					'style22' => esc_html__( 'Style 22', 'bwd-dual-heading' ),
					'style23' => esc_html__( 'Style 23', 'bwd-dual-heading' ),
					'style24' => esc_html__( 'Style 24', 'bwd-dual-heading' ),
					'style25' => esc_html__( 'Style 25', 'bwd-dual-heading' ),
					'style26' => esc_html__( 'Style 26', 'bwd-dual-heading' ),
					'style27' => esc_html__( 'Style 27', 'bwd-dual-heading' ),
					'style28' => esc_html__( 'Style 28', 'bwd-dual-heading' ),
					'style29' => esc_html__( 'Style 29', 'bwd-dual-heading' ),
					'style30' => esc_html__( 'Style 30', 'bwd-dual-heading' ),
					'style31' => esc_html__( 'Style 31', 'bwd-dual-heading' ),
				],
			]
		);

		
		$this->add_control(
			'bwddh_heading_title_url_switcher',
			[
				'label' => esc_html__( 'Hide Link', 'bwd-dual-heading' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'yes' => esc_html__( 'Show', 'bwd-dual-heading' ),
				'label_off' => esc_html__( 'Hide', 'bwd-dual-heading' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'bwddh_heading_title_url',
			[
				'label' => esc_html__( 'Link', 'bwd-dual-heading' ),
				'type' => Controls_Manager::URL,
				'condition' => [
					'bwddh_heading_title_url_switcher' => 'yes',
				],
				'placeholder' => esc_attr__( 'https://www.your-link.com', 'bwd-dual-heading' ),
				'default' => [
					'url' => 'https://www.google.com',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
			]
		);

		$this->add_control(
			'bwddh_heading_url_divider_sk',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'bwddh_heading_title01_switcher',
			[
				'label' => esc_html__( 'Hide Title', 'bwd-dual-heading' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'yes' => esc_html__( 'Show', 'bwd-dual-heading' ),
				'label_off' => esc_html__( 'Hide', 'bwd-dual-heading' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'bwddh_heading_title01',
			[
				'label' => esc_html__( 'Title', 'bwd-dual-heading' ),
				'type' => Controls_Manager::TEXT,
				'condition' => [
					'bwddh_heading_title01_switcher' => 'yes',
				],
				'default' => esc_html__('Got to our main', 'bwd-dual-heading'),
				'label_block' => true,
			]
		);
		// Hover control start
		$this->start_controls_tabs(
			'bwddh_heading_title_style_tabs01'
		);
		$this->start_controls_tab(
			'bwddh_heading_title_normal_tab01',
			[
				'label' => esc_html__( 'Normal', 'bwd-dual-heading' ),
				'condition' => [
					'bwddh_heading_title01_switcher' => 'yes',
				],
			]
		);
		// Normal Controls
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwddh_heading_title_typography01',
				'condition' => [
					'bwddh_heading_title01_switcher' => 'yes',
				],
				'selector' => '{{WRAPPER}} .bwddh-heading .bwddh-first-hedi',
			]
		);
		$this->add_control(
			'bwddh_heading_title_color01',
			[
				'label' => esc_html__( 'Color', 'bwd-dual-heading' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'bwddh_heading_title01_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .bwddh-heading .bwddh-first-hedi' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		$this->start_controls_tab(
			'bwddh_heading_title_hover_tab01',
			[
				'label' => esc_html__( 'Hover', 'bwd-dual-heading' ),
				'condition' => [
					'bwddh_heading_title01_switcher' => 'yes',
				],
			]
		);
		// Hover Controls
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwddh_heading_title_hover_typography01',
				'condition' => [
					'bwddh_heading_title01_switcher' => 'yes',
				],
				'selector' => '{{WRAPPER}} .bwddh-heading:hover .bwddh-first-hedi',
			]
		);
		$this->add_control(
			'bwddh_heading_title_hover_color01',
			[
				'label' => esc_html__( 'Hover Color', 'bwd-dual-heading' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'bwddh_heading_title01_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .bwddh-heading:hover .bwddh-first-hedi' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// Hover Control End

		$this->add_control(
			'bwddh_heading_title02_divider_sk',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'bwddh_heading_divider_title02_switcher',
			[
				'label' => esc_html__( 'Hide Divider', 'bwd-dual-heading' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'bwd-dual-heading' ),
				'label_off' => esc_html__( 'Hide', 'bwd-dual-heading' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
			'bwddh_heading_divider_color',
			[
				'label' => esc_html__( 'Color', 'bwd-dual-heading' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'bwddh_heading_divider_title02_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .bwddh-heddi-1:after' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control(
			'bwddh_heading_divider_height',
			[
				'label' => esc_html__( 'Height', 'bwd-dual-heading' ),
				'type' => Controls_Manager::SLIDER,
                'size_units' => ['vh', 'px', 'rem', 'em', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'devices' => [ 'desktop', 'laptop', 'tablet', 'tablet_extra', 'mobile', 'mobile_extra' ],
				'selectors' => [
					'{{WRAPPER}} .bwddh-heddi-1:after' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'bwddh_heading_divider_title02_switcher' => 'yes',
				],
			]
		);
		$this->add_responsive_control(
			'bwddh_heading_divider_width',
			[
				'label' => esc_html__( 'Width', 'bwd-dual-heading' ),
				'type' => Controls_Manager::SLIDER,
                'size_units' => ['vh', 'px', 'rem', 'em', '%'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'devices' => [ 'desktop', 'laptop', 'tablet', 'tablet_extra', 'mobile', 'mobile_extra' ],
				'selectors' => [
					'{{WRAPPER}} .bwddh-heddi-1:after' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'bwddh_heading_divider_title02_switcher' => 'yes',
				],
			]
		);
		$this->add_responsive_control(
            'bwddh_heading_divider_width_position',
            [
                'label' => esc_html__('Position', 'bwd-dual-heading'),
                'type' => Controls_Manager::DIMENSIONS,
				'condition' => [
					'bwddh_heading_divider_title02_switcher' => 'yes',
				],
                'size_units' => ['px', 'em', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bwddh-heddi-1:after' => 'position: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
			'bwddh_heading_title_headingdivider_divider_sk',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'bwddh_heading_title02_switcher',
			[
				'label' => esc_html__( 'Hide Title', 'bwd-dual-heading' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'bwd-dual-heading' ),
				'label_off' => esc_html__( 'Hide', 'bwd-dual-heading' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'bwddh_heading_title02',
			[
				'label' => esc_html__( 'Title', 'bwd-dual-heading' ),
				'type' => Controls_Manager::TEXT,
				'condition' => [
					'bwddh_heading_title02_switcher' => 'yes',
				],
				'default' => esc_html__('Program', 'bwd-dual-heading'),
				'label_block' => true,
			]
		);
		// Hover control start
		$this->start_controls_tabs(
			'bwddh_heading_title_style_tabs02'
		);
		$this->start_controls_tab(
			'bwddh_heading_title_normal_tab02',
			[
				'label' => esc_html__( 'Normal', 'bwd-dual-heading' ),
				'condition' => [
					'bwddh_heading_title02_switcher' => 'yes',
				],
			]
		);
		// Normal Controls
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwddh_heading_title_typography02',
				'condition' => [
					'bwddh_heading_title02_switcher' => 'yes',
				],
				'selector' => '{{WRAPPER}} .bwddh-heading .bwddh-sec-hedi',
			]
		);
		$this->add_control(
			'bwddh_heading_title_color02',
			[
				'label' => esc_html__( 'Color', 'bwd-dual-heading' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'bwddh_heading_title02_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .bwddh-heading .bwddh-sec-hedi' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		$this->start_controls_tab(
			'bwddh_heading_title_hover_tab02',
			[
				'label' => esc_html__( 'Hover', 'bwd-dual-heading' ),
				'condition' => [
					'bwddh_heading_title02_switcher' => 'yes',
				],
			]
		);
		// Hover Controls
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwddh_heading_title_hover_typography02',
				'condition' => [
					'bwddh_heading_title02_switcher' => 'yes',
				],
				'selector' => '{{WRAPPER}} .bwddh-heading:hover .bwddh-sec-hedi',
			]
		);
		$this->add_control(
			'bwddh_heading_title_hover_color02',
			[
				'label' => esc_html__( 'Hover Color', 'bwd-dual-heading' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'bwddh_heading_title02_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .bwddh-heading:hover .bwddh-sec-hedi' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// Hover Control End
		$this->end_controls_section();

		$this->start_controls_section(
			'bwddh_heading_style_section',
			[
				'label' => esc_html__( 'Heading Style', 'bwd-dual-heading' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'bwddh_heading_box_background',
				'label' => esc_html__( 'Background', 'bwd-dual-heading' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .bwddh-heading',
			]
		);
		$this->add_responsive_control(
            'bwddh_heading_the_box_margin',
            [
                'label' => esc_html__('Margin', 'bwd-dual-heading'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bwddh-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
            'bwddh_heading_the_box_padding',
            [
                'label' => esc_html__('Padding', 'bwd-dual-heading'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bwddh-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
            'bwddh_heading_the_box_border_radius',
            [
                'label' => esc_html__('Border Radius', 'bwd-dual-heading'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .bwddh-heading' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->end_controls_section();
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		// Link
		if ( ! empty( $settings['bwddh_heading_title_url']['url'] ) ) {
			$this->add_link_attributes( 'bwddh_heading_title_url', $settings['bwddh_heading_title_url'] );
		}
		if('style1' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-1">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-1"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style2' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-2">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-2"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style3' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-3">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-3 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-3"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style4' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-4">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-4 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-4"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style5' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-5">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-5 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-5"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style6' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-6">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-6 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-6"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style7' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-7">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-7 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-7"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style8' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-8">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-8 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-8"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style9' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-9">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-9 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-9"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style10' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-10">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-10 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-10"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style11' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-11">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-11 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-11"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style12' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-12">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-12 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-12"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style13' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-13">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-13 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-13"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style14' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-14">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-14 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-14"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style15' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-15">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-15 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-15"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style16' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-16">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-16 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-16"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style17' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-17">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-17 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-17"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style18' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-18">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-18 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-18"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style19' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-19">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-19 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-19"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style20' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-20">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-20 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-20"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style21' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-21">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-21 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-21"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style22' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-22">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-22 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-22"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style23' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-23">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-23 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-23"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style24' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-24">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-24 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-24"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style25' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-25">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-25 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-25"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style26' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-26">
			<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-26 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-26"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
		</div></a>
		<?php
		} elseif('style27' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-27">
			<div class="bwddh-bg">
				<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-27 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-27"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
			</div>
		</div></a>
		<?php
		} elseif('style28' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-28">
			<div class="bwddh-bg">
				<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-28 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-28"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
			</div>
		</div></a>
		<?php
		} elseif('style29' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-29">
			<div class="bwddh-bg">
				<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-29 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-29"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
			</div>
		</div></a>
		<?php
		} elseif('style30' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-30">
			<div class="bwddh-bg">
				<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-30 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-30"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
			</div>
		</div></a>
		<?php
		} elseif('style31' === $settings['bwddh_style_selection']){
		?>
		<?php if('yes' === $settings['bwddh_heading_title_url_switcher']){ ?><a href="<?php echo esc_url($settings['bwddh_heading_title_url']['url']); ?>"><?php } ?><div class="bwddh-heading bwddh-dual-hedi-31">
			<div class="bwddh-bg">
				<?php if('yes' === $settings['bwddh_heading_title01_switcher']){ ?><div class="bwddh-first-hedi bwddh-heddi-31 <?php if('yes' === $settings['bwddh_heading_divider_title02_switcher']){ ?>bwddh-heddi-1 <?php } ?>"><?php echo esc_html($settings['bwddh_heading_title01']); ?></div><?php } if('yes' === $settings['bwddh_heading_title02_switcher']){ ?><div class="bwddh-sec-hedi bwddh-cor-hedi-31"><?php echo esc_html($settings['bwddh_heading_title02']); ?></div><?php } ?>
			</div>
		</div></a>
		<?php
		}
	}

    protected function content_template() {
        ?>
		<# if('style1' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-1">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-1">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style2' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-2">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-2">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style3' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-3">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-3 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-3">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style4' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-4">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-4 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-4">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style5' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-5">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-5 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-5">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style6' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-6">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-6 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-6">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style7' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-7">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-7 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-7">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style8' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-8">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-8 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-8">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style9' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-9">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-9 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-9">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style10' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-10">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-10 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-10">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style11' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-11">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-11 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-11">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style12' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-12">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-12 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-12">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style13' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-13">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-13 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-13">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style14' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-14">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-14 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-14">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style15' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-15">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-15 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-15">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style16' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-16">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-16 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-16">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style17' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-17">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-17 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-17">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style18' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-18">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-18 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-18">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style19' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-19">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-19 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-19">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style20' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-20">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-20 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-20">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style21' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-21">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-21 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-21">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style22' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-22">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-22 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-22">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style23' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-23">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-23 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-23">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style24' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-24">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-24 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-24">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style25' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-25">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-25 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-25">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style26' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-26">
			<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-26 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-26">{{{settings['bwddh_heading_title02']}}}</div><# } #>
		</div></a>
		<# } else if('style27' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-27">
			<div class="bwddh-bg">
				<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-27 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-27">{{{settings['bwddh_heading_title02']}}}</div><# } #>
			</div>
		</div></a>
		<# } else if('style28' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-28">
			<div class="bwddh-bg">
				<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-28 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-28">{{{settings['bwddh_heading_title02']}}}</div><# } #>
			</div>
		</div></a>
		<# } else if('style29' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-29">
			<div class="bwddh-bg">
				<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-29 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-29">{{{settings['bwddh_heading_title02']}}}</div><# } #>
			</div>
		</div></a>
		<# } else if('style30' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-30">
			<div class="bwddh-bg">
				<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-30 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-30">{{{settings['bwddh_heading_title02']}}}</div><# } #>
			</div>
		</div></a>
		<# } else if('style31' === settings['bwddh_style_selection']){ #>
		<# if('yes' === settings['bwddh_heading_title_url_switcher']){ #><a href="{{{settings['bwddh_heading_title_url']['url']}}}"><# } #><div class="bwddh-heading bwddh-dual-hedi-31">
			<div class="bwddh-bg">
				<# if('yes' === settings['bwddh_heading_title01_switcher']){ #><div class="bwddh-first-hedi bwddh-heddi-31 <# if('yes' === settings['bwddh_heading_divider_title02_switcher']){ #>bwddh-heddi-1 <# } #>">{{{settings['bwddh_heading_title01']}}}</div><# } if('yes' === settings['bwddh_heading_title02_switcher']){ #><div class="bwddh-sec-hedi bwddh-cor-hedi-31">{{{settings['bwddh_heading_title02']}}}</div><# } #>
			</div>
		</div></a>
		<# } #>
        <?php
    }
}
