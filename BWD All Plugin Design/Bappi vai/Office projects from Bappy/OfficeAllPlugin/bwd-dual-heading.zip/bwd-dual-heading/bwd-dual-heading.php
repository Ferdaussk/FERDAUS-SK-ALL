<?php
/**
 * Plugin Name: BWD Dual Heading
 * Description: BWD Dual Heading plugin with 30+ types of dual heading also custom text with masking effects for Elementor.
 * Plugin URI:  https://bestwpdeveloper.com/plugins/elementor/bwd-dual-heading
 * Version:     1.0
 * Author:      Best WP Developer
 * Author URI:  https://bestwpdeveloper.com/
 * Text Domain: bwd-dual-heading
 * Elementor tested up to: 3.0.0
 * Elementor Pro tested up to: 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
require_once ( plugin_dir_path(__FILE__) ) . '/includes/class-tgm-plugin-activation.php';
final class FinalBWDDHeading{

	const VERSION = '1.0';

	const MINIMUM_ELEMENTOR_VERSION = '3.0.0';

	const MINIMUM_PHP_VERSION = '7.0';

	public function __construct() {
		// Load translation
		add_action( 'bwddh_init', array( $this, 'bwddh_loaded_textdomain' ) );
		// bwddh_init Plugin
		add_action( 'plugins_loaded', array( $this, 'bwddh_init' ) );
	}

	public function bwddh_loaded_textdomain() {
		load_plugin_textdomain( 'bwd-dual-heading' );
	}

	public function bwddh_init() {
		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			// For tgm plugin activation
			add_action( 'tgmpa_register', [$this, 'bwddh_heading_register_required_plugins'] );
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', array( $this, 'bwddh_admin_notice_minimum_elementor_version' ) );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', array( $this, 'bwddh_admin_notice_minimum_php_version' ) );
			return;
		}

		// Once we get here, We have passed all validation checks so we can safely include our plugin
		require_once( 'bwddh_plugin_boots.php' );
	}

	function bwddh_heading_register_required_plugins() {
		$plugins = array(
			array(
				'name'        => esc_html__('Elementor', 'bwd-dual-heading'),
				'slug'        => 'elementor',
				'is_callable' => 'wpseo_init',
			),
		);

		$config = array(
			'id'           => 'bwd-dual-heading',
			'default_path' => '',
			'menu'         => 'tgmpa-install-plugins',
			'parent_slug'  => 'plugins.php',
			'capability'   => 'manage_options',
			'has_notices'  => true,
			'dismissable'  => true,
			'dismiss_msg'  => '',
			'is_automatic' => false,
			'message'      => '',
		);
	
		tgmpa( $plugins, $config );
	}

	public function bwddh_admin_notice_minimum_elementor_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bwd-dual-heading' ),
			'<strong>' . esc_html__( 'BWD Dual Heading', 'bwd-dual-heading' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'bwd-dual-heading' ) . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>' . esc_html__('%1$s', 'bwd-dual-heading') . '</p></div>', $message );
	}

	public function bwddh_admin_notice_minimum_php_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bwd-dual-heading' ),
			'<strong>' . esc_html__( 'BWD Dual Heading', 'bwd-dual-heading' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'bwd-dual-heading' ) . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>' . esc_html__('%1$s', 'bwd-dual-heading') . '</p></div>', $message );
	}
}

// Instantiate bwd-dual-heading.
new FinalBWDDHeading();
remove_action( 'shutdown', 'wp_ob_end_flush_all', 1 );