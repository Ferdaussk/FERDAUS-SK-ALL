<?php
namespace Creativecalltoaction\PageSettings;

use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\PageBase;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Page_Settings {

	const PANEL_TAB = 'new-tab';

	public function __construct() {
		add_action( 'elementor/init', [ $this, 'bwdcta_call_to_action_add_panel_tab' ] );
		add_action( 'elementor/documents/register_controls', [ $this, 'bwdcta_call_to_action_register_document_controls' ] );
	}

	public function bwdcta_call_to_action_add_panel_tab() {
		Controls_Manager::add_tab( self::PANEL_TAB, esc_html__( 'New Call To Action', 'bwdcta-call-to-action' ) );
	}

	public function bwdcta_call_to_action_register_document_controls( $document ) {
		if ( ! $document instanceof PageBase || ! $document::get_property( 'has_elements' ) ) {
			return;
		}

		$document->start_controls_section(
			'bwdcta_call_to_action_new_section',
			[
				'label' => esc_html__( 'Settings', 'bwdcta-call-to-action' ),
				'tab' => self::PANEL_TAB,
			]
		);

		$document->add_control(
			'bwdcta_call_to_action_text',
			[
				'label' => esc_html__( 'Title', 'bwdcta-call-to-action' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Title', 'bwdcta-call-to-action' ),
			]
		);

		$document->end_controls_section();
	}
}
