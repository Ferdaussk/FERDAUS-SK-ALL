<?php
/**
 * Plugin Name: BWD Service Showcase
 * Description: Eye Catching Elementor Services Showcase, 29+ Unique Design, Chooseable column layout.
 * Plugin URI:  https://bestwpdeveloper.com/plugins/elementor/bwd-services-showcase
 * Version:     1.0
 * Author:      Best WP Developer
 * Author URI:  https://bestwpdeveloper.com/
 * Text Domain: bwd-services-showcase
 * Elementor tested up to: 3.0.0
 * Elementor Pro tested up to: 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
require_once ( plugin_dir_path(__FILE__) ) . '/includes/class-tgm-plugin-activation.php';
final class FinalBWDSSSevices{

	const VERSION = '1.0';

	const MINIMUM_ELEMENTOR_VERSION = '3.0.0';

	const MINIMUM_PHP_VERSION = '7.0';

	public function __construct() {
		// Load translation
		add_action( 'bwdss_init', array( $this, 'bwdss_loaded_textdomain' ) );
		// bwdss_init Plugin
		add_action( 'plugins_loaded', array( $this, 'bwdss_init' ) );
	}

	public function bwdss_loaded_textdomain() {
		load_plugin_textdomain( 'bwd-services-showcase' );
	}

	public function bwdss_init() {
		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			// For tgm plugin activation
			add_action( 'tgmpa_register', [$this, 'bwdss_service_register_required_plugins'] );
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', array( $this, 'bwdss_admin_notice_minimum_elementor_version' ) );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', array( $this, 'bwdss_admin_notice_minimum_php_version' ) );
			return;
		}

		// Once we get here, We have passed all validation checks so we can safely include our plugin
		require_once( 'bwdss_plugin_boots.php' );
	}

	function bwdss_service_register_required_plugins() {
		$plugins = array(
			array(
				'name'        => esc_html__('Elementor', 'bwd-services-showcase'),
				'slug'        => 'elementor',
				'is_callable' => 'wpseo_init',
			),
		);

		$config = array(
			'id'           => 'bwd-services-showcase',
			'default_path' => '',
			'menu'         => 'tgmpa-install-plugins',
			'parent_slug'  => 'plugins.php',
			'capability'   => 'manage_options',
			'has_notices'  => true,
			'dismissable'  => true,
			'dismiss_msg'  => '',
			'is_automatic' => false,
			'message'      => '',
		);
	
		tgmpa( $plugins, $config );
	}

	public function bwdss_admin_notice_minimum_elementor_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bwd-services-showcase' ),
			'<strong>' . esc_html__( 'BWD Service Showcase', 'bwd-services-showcase' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'bwd-services-showcase' ) . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>' . esc_html__('%1$s', 'bwd-services-showcase') . '</p></div>', $message );
	}

	public function bwdss_admin_notice_minimum_php_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bwd-services-showcase' ),
			'<strong>' . esc_html__( 'BWD Service Showcase', 'bwd-services-showcase' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'bwd-services-showcase' ) . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>' . esc_html__('%1$s', 'bwd-services-showcase') . '</p></div>', $message );
	}
}

// Instantiate bwd-services-showcase.
new FinalBWDSSSevices();
remove_action( 'shutdown', 'wp_ob_end_flush_all', 1 );