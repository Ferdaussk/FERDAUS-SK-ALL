<?php
namespace CreativeServiceShowcase\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class BWDSSService extends Widget_Base {

	public function get_name() {
		return esc_html__( 'NameServiceShowcase', 'bwd-services-showcase' );
	}

	public function get_title() {
		return esc_html__( 'BWD Service Showcase', 'bwd-services-showcase' );
	}

	public function get_icon() {
		return 'bwdss-services-icon eicon-columns';
	}

	public function get_categories() {
		return [ 'bwd-services-showcase-category' ];
	}

	public function get_script_depends() {
		return [ 'bwd-services-showcase-category' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'bwdss_service_content_section',
			[
				'label' => esc_html__( 'Layout', 'bwd-services-showcase' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control(
			'bwdss_service_showcase_style',
			[
				'label' => esc_html__( 'Choose Style', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'bwd-services-showcase' ),
					'style2' => esc_html__( 'Style 2', 'bwd-services-showcase' ),
					'style3' => esc_html__( 'Style 3', 'bwd-services-showcase' ),
					'style4' => esc_html__( 'Style 4', 'bwd-services-showcase' ),
					'style5' => esc_html__( 'Style 5', 'bwd-services-showcase' ),
					'style6' => esc_html__( 'Style 6', 'bwd-services-showcase' ),
					'style7' => esc_html__( 'Style 7', 'bwd-services-showcase' ),
					'style8' => esc_html__( 'Style 8', 'bwd-services-showcase' ),
					'style9' => esc_html__( 'Style 9', 'bwd-services-showcase' ),
					'style10' => esc_html__( 'Style 10', 'bwd-services-showcase' ),
					'style11' => esc_html__( 'Style 11', 'bwd-services-showcase' ),
					'style12' => esc_html__( 'Style 12', 'bwd-services-showcase' ),
					'style13' => esc_html__( 'Style 13', 'bwd-services-showcase' ),
					'style14' => esc_html__( 'Style 14', 'bwd-services-showcase' ),
					'style15' => esc_html__( 'Style 15', 'bwd-services-showcase' ),
					'style16' => esc_html__( 'Style 16', 'bwd-services-showcase' ),
					'style17' => esc_html__( 'Style 17', 'bwd-services-showcase' ),
					'style18' => esc_html__( 'Style 18', 'bwd-services-showcase' ),
					'style19' => esc_html__( 'Style 19', 'bwd-services-showcase' ),
					'style20' => esc_html__( 'Style 20', 'bwd-services-showcase' ),
					'style21' => esc_html__( 'Style 21', 'bwd-services-showcase' ),
					'style22' => esc_html__( 'Style 22', 'bwd-services-showcase' ),
					'style23' => esc_html__( 'Style 23', 'bwd-services-showcase' ),
					'style24' => esc_html__( 'Style 24', 'bwd-services-showcase' ),
					'style25' => esc_html__( 'Style 25', 'bwd-services-showcase' ),
					'style26' => esc_html__( 'Style 26', 'bwd-services-showcase' ),
					'style27' => esc_html__( 'Style 27', 'bwd-services-showcase' ),
					'style28' => esc_html__( 'Style 28', 'bwd-services-showcase' ),
					'style29' => esc_html__( 'Style 29', 'bwd-services-showcase' ),
					'style30' => esc_html__( 'Style 30', 'bwd-services-showcase' ),
				],
			]
		);
		$this->add_control(
			'bwdss_column_layout',
			[
				'label' => esc_html__( 'Choose Column', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'columnFour',
				'options' => [
                    'columnFour' => esc_html__( '4 Column', 'bwd-services-showcase' ),
					'columnThree'  => esc_html__( '3 Column', 'bwd-services-showcase' ),
					'columnSix' => esc_html__( '2 Column', 'bwd-services-showcase' ),
				],
			]
		);
        $this->end_controls_section();
        $this->start_controls_section(
			'bwdss_column_section',
			[
				'label' => esc_html__( 'Service Content', 'bwd-services-showcase' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
       
        

		$repeater = new \Elementor\Repeater();
		 
		// Service Box Start
		$repeater->add_control(
			'bwdss_service_service_box_style_heading',
			[
				'label' => esc_html__( 'Service Box Style', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);
		$repeater->start_controls_tabs(
			'bwdss_service_service_box_style_tabs'
		);
		$repeater->start_controls_tab(
			'bwdss_service_service_box_background_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'bwd-services-showcase' ),
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'bwdss_service_box_background',
				'label' => esc_html__( 'Background', 'bwd-services-showcase' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box',
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'bwdss_service_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'bwd-services-showcase' ),
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box',
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'bwdss_service_box_border',
				'label' => esc_html__( 'Border', 'plugin-name' ),
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box',
			]
		);
		$repeater->add_control(
			'bwdss_service_box_border-radius',
			[
				'label' => esc_html__( 'Border Radius', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$repeater->end_controls_tab();
		$repeater->start_controls_tab(
			'bwdss_service_box_background_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'bwd-services-showcase' ),
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'bwdss_service_box_hover_background',
				'label' => esc_html__( 'Background', 'bwd-services-showcase' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box:hover',
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'bwdss_service_hover_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'bwd-services-showcase' ),
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box:hover',
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'bwdss_service_box_border_hover',
				'label' => esc_html__( 'Border', 'plugin-name' ),
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box:hover',
			]
		);
		$repeater->add_control(
			'bwdss_service_box_border-radius_hover',
			[
				'label' => esc_html__( 'Border Radius', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$repeater->end_controls_tab();
		$repeater->end_controls_tabs();
		$repeater->add_control(
			'bwdss_service_box_end_separator',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		
		// Icon Box End
		// Icon Start

		$repeater->add_control(
			'bwdss_service_icon_heading',
			[
				'label' => esc_html__( 'Icon', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);
		$repeater->add_control(
			'bwdss_service_icon', [
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'bwdss_service_icon_color',
			[
				'label' => esc_html__( 'Color', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-icon ' => 'color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-style-6 .bwd-service-box.purple:after' => 'border-bottom-color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-style-3 .bwd-service-box:before, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box.blue::after' => 'border-color: {{VALUE}}'
				],
			]
		);
		$repeater->add_control(
			'bwdss_service_icon_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-icon i:hover, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box.blue .bwd-service-icon i:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-style-6 .bwd-service-box.purple:after' => 'border-bottom-color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-style-3 .bwd-service-box:before, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box.blue::after' => 'border-color: {{VALUE}}'
				],
			]
		);
		$repeater->add_control(
			'bwdss_service_icon_border_color',
			[
				'label' => esc_html__( 'Border Color', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-icon::before, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box span, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-icon, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box span:after, .bwd-service-style-18 .bwd-service-box .bwd-service-icon::before, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-icon::after' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-icon:after, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box span::before' => 'background-color: {{VALUE}}',
				],
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'bwdss_sevice_icon_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'bwd-services-showcase' ),
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box .bwd-service-icon',
			]
		);
		$repeater->add_control(
			'bwdss_service_icon_primary_background_color',
			[
				'label' => esc_html__( 'Primary Background', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'primary_background',
				'label' => esc_html__( 'Background', 'bwd-services-showcase' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => ['image'],
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-icon, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box.purple::before, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box.green .bwd-service-content::before, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box.green::before, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box.cyan::after, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box.cyan::before, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box .bwd-service-icon, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box .bwd-top-title, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-iteam .bwd-service-box .bwd-service-icon, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box .bwd-service-icon',
				
			]
		);
		$repeater->add_control(
			'bwdss_service_icon_secondary_background_color',
			[
				'label' => esc_html__( 'Secondary Background', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'secondary_background',
				'label' => esc_html__( 'Background', 'bwd-services-showcase' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => ['image'],
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box .bwd-service-icon::before, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box .bwd-service-content::before, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box .bwd-service-content::after, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box.sunrise .bwd-top-title' ,
			]
		);
		$repeater->add_control(
			'bwdss_service_icon_background_color_separator',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$repeater->add_responsive_control(
			'bwdss_service_icon_font_size',
			[
				'label' => esc_html__( 'Icon Size', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'rem', 'em', '%' ],
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-icon ' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$repeater->add_control(
			'bwdss_service_icon_font_size_separator',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$repeater->add_control(
			'important_note_title',
			[
				'label' => esc_html__( 'Important Note:', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);
		$repeater->add_control(
			'important_note',
			[
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw' => esc_html__( 'If you customize icon width and height  you should use the same value width, height, and line-height', 'bwd-services-showcase' ),
			]
		);
		$repeater->add_control(
			'important_note_title_separator',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$repeater->add_responsive_control(
			'bwdss_service_icon_width',
			[
				'label' => esc_html__( 'Width', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'rem', 'em', '%' ],
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-icon' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$repeater->add_control(
			'bwdss_service_icon_width_separator',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$repeater->add_responsive_control(
			'bwdss_service_icon_height',
			[
				'label' => esc_html__( 'Height', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'rem', 'em', '%' ],
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-icon' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$repeater->add_control(
			'bwdss_service_icon_height_separator',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$repeater->add_responsive_control(
			'bwdss_service_icon_line_height',
			[
				'label' => esc_html__( 'Line Height', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'rem', 'em', '%' ],
				'separator' => 'after',
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-icon' => 'line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		// Service Icon End Here
		// Service Title Start Here

		$repeater->add_control(
			'bwdss_service_heading',
			[
				'label' => esc_html__( 'Title', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);
		$repeater->add_control(
			'bwdss_service_title', [
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'bwdss_service_title_color',
			[
				'label' => esc_html__( 'Color', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .title' => 'color: {{VALUE}}'
				],
			]
		);
		$repeater->add_control(
			'bwdss_service_title_color_hover',
			[
				'label' => esc_html__( 'Hover Color', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .title:hover' => 'color: {{VALUE}}'
				],
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwdss_service_title_typography',
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .title',
			]
		);
		$repeater->add_control(
			'bwdss_service_text_shadow_popover_toggle',
			[
				'label' => esc_html__( 'Text Shadow', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
				'return_value' => 'yes',
			]
		);
		$repeater->start_popover();
		$repeater->add_control(
			'bwdss_service_text_shadow', 
			[
				'label' => esc_html__( 'Text Shadow', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::TEXT_SHADOW,
				'selectors' => [
					'{{SELECTOR}} {{CURRENT_ITEM}} .title' => 'text-shadow: {{HORIZONTAL}}px {{VERTICAL}}px {{BLUR}}px {{COLOR}};',
				],
				'condition' => [
					'bwdss_service_text_shadow_popover_toggle' => 'yes',
				],
			]	
		);	
		$repeater->end_popover();
		$repeater->add_control(
			'bwdss_service_title_separator',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		// Service Title End Here
		// Service Description Start Here

		$repeater->add_control(
			'bwdss_service_cont_heading',
			[
				'label' => esc_html__( 'Description', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);
		$repeater->add_control(
			'bwdss_service_cont', [
				'type' => \Elementor\Controls_Manager::TEXTAREA,
			]
		);
		$repeater->add_control(
			'bwdss_service_cont_color',
			[
				'label' => esc_html__( 'Color', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box .desc' => 'color: {{VALUE}}'
				],
			]
		);
		$repeater->add_control(
			'bwdss_service_cont_color_hover',
			[
				'label' => esc_html__( 'Hover Color', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box .desc:hover' => 'color: {{VALUE}}'
				],
			]
		);
		$repeater->add_control(
			'bwdss_service_cont_border_color',
			[
				'label' => esc_html__( 'Content Background', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box .bwd-service-content::before' => 'border-bottom-color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box .bwd-service-content' => 'background-color: {{VALUE}}'
				],
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwdss_service_cont_typography',
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .bwd-service-box .desc',
			]
		);
		
		// Service Description End Here
		
		$this->add_control(
			'bwdss_service_item',
			[
				'label' => esc_html__( 'Service', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'bwdss_service_title' => esc_html__( 'Title #1', 'bwd-services-showcase' ),
						'bwdss_service_cont' => esc_html__( 'Lorem ipsum dolor sit amet conse ctetur adipisicing elit. Qui quaerat fugit quas veniam perferendis repudiandae sequi, dolore quisquam illum.', 'bwd-services-showcase' ),
					],
					[
						'bwdss_service_title' => esc_html__( 'Title #2', 'bwd-services-showcase' ),
						'bwdss_service_cont' => esc_html__( 'Lorem ipsum dolor sit amet conse ctetur adipisicing elit. Qui quaerat fugit quas veniam perferendis repudiandae sequi, dolore quisquam illum.', 'bwd-services-showcase' ),
					],
					[
						'bwdss_service_title' => esc_html__( 'Title #3', 'bwd-services-showcase' ),
						'bwdss_service_cont' => esc_html__( 'Lorem ipsum dolor sit amet conse ctetur adipisicing elit. Qui quaerat fugit quas veniam perferendis repudiandae sequi, dolore quisquam illum.', 'bwd-services-showcase' ),
					],
					[
						'bwdss_service_title' => esc_html__( 'Title #4', 'bwd-services-showcase' ),
						'bwdss_service_cont' => esc_html__( 'Lorem ipsum dolor sit amet conse ctetur adipisicing elit. Qui quaerat fugit quas veniam perferendis repudiandae sequi, dolore quisquam illum.', 'bwd-services-showcase' ),
					],
				],
				'title_field' => '{{{ bwdss_service_title }}}',
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'bwdss_service_style_section',
			[
				'label' => esc_html__( 'Style', 'bwd-services-showcase' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'bwdss_service_background',
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .bwd-service-style-wrapper',
			]
		);
		$this->add_responsive_control(
			'bwdss_service_margin',
			[
				'label' => esc_html__( 'Margin', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .bwd-service-style-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'bwdss_service_padding',
			[
				'label' => esc_html__( 'Padding', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em','rem' ],
				'selectors' => [
					'{{WRAPPER}} .bwd-service-style-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'bwdss_service_section_border',
				'label' => esc_html__( 'Border', 'bwd-services-showcase' ),
				'selector' => '{{WRAPPER}} .bwd-service-style-wrapper',
			]
		);
		$this->add_responsive_control(
			'bwdss_service_section_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'bwd-services-showcase' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .bwd-service-style-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
	   
		if ('style1' === $settings['bwdss_service_showcase_style']) { 
		?>
		<div class="bwd-service-style-1 bwd-service-style-wrapper">
			<div class="container">
				<div class="row">
					<?php
						if( $settings['bwdss_service_item'] ) {
							foreach( $settings['bwdss_service_item'] as $item ) {
								?>
						<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
							echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="bwd-service-box red">
									<div class="bwd-service-icon">
										<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
									</div>
									<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
									<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
								</div>
							</div>		
						</div>
						<?php
							}
						}
						?>
				</div>
			</div>
		</div>
		<?php
		} elseif ('style2' === $settings['bwdss_service_showcase_style']) { 
		?>
		<div class="bwd-service-style-2 bwd-service-style-wrapper">
			<div class="container">
				<div class="row">
					<?php
						if( $settings['bwdss_service_item'] ) {
							foreach( $settings['bwdss_service_item'] as $item ) {
								?>
						<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
							echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="bwd-service-box red">
									<div class="bwd-service-icon">
										<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
									</div>
									<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
									<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
								</div>
							</div>		
						</div>
						<?php
							}
						}
						?>
				</div>
			</div>
		</div>
		<?php
		} elseif ('style3' === $settings['bwdss_service_showcase_style']) { 
		?>
		<div class="bwd-service-style-3 bwd-service-style-wrapper">
			<div class="container">
				<div class="row">
					<?php
						if( $settings['bwdss_service_item'] ) {
							foreach( $settings['bwdss_service_item'] as $item ) {
							?>
						<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
							echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="bwd-service-box red">
									<div class="bwd-service-icon">
										<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
									</div>
									<div class="bwd-service-content">
										<div class="bwd-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>
							</div>		
						</div>
						<?php
							}
						}
						?>
				</div>
			</div>
		</div>
		<?php				 										
		} elseif ('style4' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-4 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box red">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style5' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-5 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="bwd-content">
												<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
												<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
											</div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style6' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-6 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box red">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style7' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-7 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box red">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="bwd-content">
												<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
												<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
											</div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php 
		} elseif ('style8' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-8 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
										<div class="bwd-service-content">
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php 
		} elseif ('style9' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-9 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style10' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-10 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style11' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-11 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style12' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-12 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style13' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-13 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style14' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-14 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style15' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-15 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-top-title"></div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style16' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-16 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style17' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-17 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-content">
											<div class="bwd-service-icon">
												<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
											</div>
											<div class="bwd-service-content">
												<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
												<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
											</div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style18' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-18 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<span><i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i></span>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style19' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-19 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style20' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-20 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style21' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-21 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-top-title"></div>
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style22' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-22 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style23' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-23 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?>  col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-iteam">
										<div class="bwd-service-box">
											<div class="bwd-service-content">
												<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
												<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
											</div>
											<div class="bwd-service-icon">
												<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
											</div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style24' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-24 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style25' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-25 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style26' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-26 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style27' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-27 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style28' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-28 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style29' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-29 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="<?php if('columnFour' === $settings['bwdss_column_layout']) { ?> col-xl-3 <?php } elseif('columnThree' === $settings['bwdss_column_layout']) { ?> col-xl-4 <?php } elseif('columnSix' === $settings['bwdss_column_layout']) { ?> col-xl-6 <?php } ?> col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} elseif ('style30' === $settings['bwdss_service_showcase_style']) { 
			?>
			<div class="bwd-service-style-30 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
						<?php
							if( $settings['bwdss_service_item'] ) {
								foreach( $settings['bwdss_service_item'] as $item ) {
								?>
							<div class="col-xxl-3 col-xl-3 col-lg-4 col-md-4 col-sm-6"><?php
								echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="<?php echo esc_attr($item['bwdss_service_icon']['value']); ?>"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title"><?php echo esc_html($item['bwdss_service_title']); ?></div>
											<div class="desc"><?php echo esc_html($item['bwdss_service_cont']); ?></div>
										</div>
									</div>
								</div>		
							</div>
							<?php
								}
							}
							?>
					</div>
				</div>
			</div>
			<?php
		} 
	}

	
		protected function content_template() {
			?>
			<# if ('style1' === settings['bwdss_service_showcase_style']) { #>
				
			<div class="bwd-service-style-1 bwd-service-style-wrapper">
				<div class="container">
					<div class="row">
					
					<# if ( settings.bwdss_service_item.length ) { #>
						<# _.each( settings.bwdss_service_item, function( item ) { #>
	
						<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
							<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
								<div class="bwd-service-box red">
									<div class="bwd-service-icon">
										<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
									</div>
									<div class="title">{{{ item['bwdss_service_title'] }}}</div>
									<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
								</div>
							</div>		
						</div>
							<# }); #>
						<# } #>
					</div>
				</div>
			</div>
			<# } else if ('style2' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-2 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box red">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="title">{{{ item['bwdss_service_title'] }}}</div>
										<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style3' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-3 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box red">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="bwd-content">
												<div class="title">{{{ item['bwdss_service_title'] }}}</div>
												<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
											</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style4' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-4 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box red">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style5' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-5 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box red">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="bwd-content">
												<div class="title">{{{ item['bwdss_service_title'] }}}</div>
												<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
											</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style6' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-6 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# }  #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box red">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
			<# } else if ('style7' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-7 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# }  #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box red">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="bwd-content">
												<div class="title">{{{ item['bwdss_service_title'] }}}</div>
												<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
											</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style8' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-8 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# }  #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box red">
										<div class="title">{{{ item['bwdss_service_title'] }}}</div>
										<div class="bwd-service-content">
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style9' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-9 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# }  #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style10' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-10 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# }  #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style11' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-11 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# }  #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style12' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-12 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# }  #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style13' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-13 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# }  #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style14' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-14 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# }  #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style15' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-15 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# }  #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-top-title"></div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style16' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-16 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# }  #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style17' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-17 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-content">
											<div class="bwd-service-icon">
												<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
											</div>
											<div class="bwd-service-content">
												<div class="title">{{{ item['bwdss_service_title'] }}}</div>
												<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
											</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style18' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-18 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<span><i class="{{{ item['bwdss_service_icon']['value'] }}}"></i></span>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style19' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-19 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style20' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-20 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style21' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-21 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-top-title"></div>
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style22' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-22 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style23' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-23 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-iteam">
										<div class="bwd-service-box">
											<div class="bwd-service-content">
												<div class="title">{{{ item['bwdss_service_title'] }}}</div>
												<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
											</div>
											<div class="bwd-service-icon">
												<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
											</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style24' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-24 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style25' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-25 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style26' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-26 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style27' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-27 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style28' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-28 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style29' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-29 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
		
							<div class="<# if('columnFour' === settings['bwdss_column_layout']) { #> col-xl-3 <# } else if('columnThree' === settings['bwdss_column_layout']) { #> col-xl-4 <# } else if('columnSix' === settings['bwdss_column_layout']) { #> col-xl-6 <# } #> col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } else if ('style30' === settings['bwdss_service_showcase_style']) { #>
				
				<div class="bwd-service-style-30 bwd-service-style-wrapper">
					<div class="container">
						<div class="row">
						
						<# if ( settings.bwdss_service_item.length ) { #>
							<# _.each( settings.bwdss_service_item, function( item ) { #>
							<div class="col-lg-4 col-md-4 col-sm-6">
								<div class="elementor-repeater-item-{{ item._id }} bwdss_service_box_inner">
									<div class="bwd-service-box">
										<div class="bwd-service-icon">
											<i class="{{{ item['bwdss_service_icon']['value'] }}}"></i>
										</div>
										<div class="bwd-service-content">
											<div class="title">{{{ item['bwdss_service_title'] }}}</div>
											<div class="desc">{{{ item['bwdss_service_cont'] }}}</div>
										</div>
									</div>
								</div>		
							</div>
								<# }); #>
							<# } #>
						</div>
					</div>
				</div>
				<# } #>
		<?php
	}	
}			 
		
		