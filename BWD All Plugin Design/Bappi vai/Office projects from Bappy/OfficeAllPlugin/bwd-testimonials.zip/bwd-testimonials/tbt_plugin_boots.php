<?php
namespace TheBestTestimonials;

use TheBestTestimonials\PageSettings\Page_Settings;
define('TBT_TESTIMONIALS_PUBLIC_ASSETS_ALL', plugin_dir_url(__FILE__) . 'assets/public');
define('TBT_TEST_ASFSK_ASSETS_ADMIN_DIR_FILE', plugin_dir_url(__FILE__) . 'assets/admin');
class TheBestTestimonials {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public function tbt_admin_editor_scripts() {
		add_filter( 'script_loader_tag', [ $this, 'tbt_admin_editor_scripts_as_a_module' ], 10, 2 );
	}

	public function tbt_admin_editor_scripts_as_a_module( $tag, $handle ) {
		if ( 'tbt_meet_the_team_editor' === $handle ) {
			$tag = str_replace( '<script', '<script type="module"', $tag );
		}

		return $tag;
	}

	private function include_widgets_files() {
		require_once( __DIR__ . '/widgets/tbt_testimonial.php' );
	}

	public function tbt_register_widgets() {
		// Its is now safe to include Widgets files
		$this->include_widgets_files(); 

		// Register Widgets
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\TBTTheBestTestimonials() );
	}

	private function add_page_settings_controls() {
		require_once( __DIR__ . '/page-settings/manager.php' );
		new Page_Settings();
	}

	// Register Category
	function tbt_add_elementor_widget_categories( $elements_manager ) {

		$elements_manager->add_category(
			'bwd-testimonials',
			[
				'title' => esc_html__( 'BWD Testimonials', 'bwd-testimonials' ),
				'icon' => 'eicon-person',
			]
		);
	}
	public function tbt_all_assets_for_the_public(){
		wp_enqueue_script( 'tbt_testimonials_the_main_js', plugin_dir_url( __FILE__ ) . 'assets/public/js/main.js', array('jquery'), '1.0', true );
		$all_css_js_file = array(
            'tbt_testimonials_the_fontAwesomeAll_main_css' => array('tbt_path_define_with_testimonials'=>TBT_TESTIMONIALS_PUBLIC_ASSETS_ALL . '/css/all.min.css'),
            'tbt_testimonials_the_tbt_main_css' => array('tbt_path_define_with_testimonials'=>TBT_TESTIMONIALS_PUBLIC_ASSETS_ALL . '/css/tbt_main.css'),
        );
        foreach($all_css_js_file as $handle => $fileinfo){
            wp_enqueue_style( $handle, $fileinfo['tbt_path_define_with_testimonials'], null, '1.0', 'all');
            wp_enqueue_script( $handle, $fileinfo['tbt_path_define_with_testimonials'], '1.0', true);
        }
	}
	public function tbt_all_assets_for_elementor_editor_admin(){
		$all_css_js_file = array(
            'tbt_testimonials_admin_main_css' => array('tbt_path_admin_define'=>TBT_TEST_ASFSK_ASSETS_ADMIN_DIR_FILE . '/icon.css'),
        );
        foreach($all_css_js_file as $handle => $fileinfo){
            wp_enqueue_style( $handle, $fileinfo['tbt_path_admin_define'], null, '1.0', 'all');
        }
	}
	function tbt_testimonial_register_required_plugins() {
		$plugins = array(
			array(
				'name'        => esc_html__('Elementor', 'bwd-testimonials'),
				'slug'        => 'elementor',
				'is_callable' => 'wpseo_init',
			),
		);

		$config = array(
			'id'           => 'bwd-testimonials',
			'default_path' => '',
			'menu'         => 'tgmpa-install-plugins',
			'parent_slug'  => 'plugins.php',
			'capability'   => 'manage_options',
			'has_notices'  => true,
			'dismissable'  => true,
			'dismiss_msg'  => '',
			'is_automatic' => false,
			'message'      => '',
		);
	
		tgmpa( $plugins, $config );
	}
	

	public function __construct() {
		// For tgm plugin activation
		add_action( 'tgmpa_register', [$this, 'tbt_testimonial_register_required_plugins'] );

		// For public assets
		add_action('wp_enqueue_scripts', [$this, 'tbt_all_assets_for_the_public']);

		// For Elementor Editor
		add_action('elementor/editor/before_enqueue_scripts', [$this, 'tbt_all_assets_for_elementor_editor_admin']);

		// Register Category
		add_action( 'elementor/elements/categories_registered', [ $this, 'tbt_add_elementor_widget_categories' ] );

		// Register widgets
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'tbt_register_widgets' ] );

		// Register editor scripts
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'tbt_admin_editor_scripts' ] );
		
		$this->add_page_settings_controls();
	}
}

// Instantiate Plugin Class
TheBestTestimonials::instance();

