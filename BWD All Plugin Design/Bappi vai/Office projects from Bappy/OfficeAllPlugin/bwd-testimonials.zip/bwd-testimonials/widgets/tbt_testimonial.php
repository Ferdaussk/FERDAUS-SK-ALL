<?php
namespace TheBestTestimonials\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class TBTTheBestTestimonials extends Widget_Base {

	public function get_name() {
		return esc_html__('Testimonials', 'bwd-testimonials' );
	}

	public function get_title() {
		return esc_html__( 'BWD Testimonials', 'bwd-testimonials' );
	}

	public function get_icon() {
		return 'tbt-ua-icon eicon-blockquote';
	}

	public function get_categories() {
		return [ 'bwd-testimonials' ];
	}

	public function __construct($data = [], $args = null) {
        parent::__construct($data, $args);
        wp_register_style( 'tbt_testimonials_the_slick_main_css',  plugin_dir_url(__FILE__). '../assets/public/css/slick.css', null, '1.0', 'all' );
        wp_register_script( 'tbt_testimonials_the_slick_js', plugin_dir_url(__FILE__).  '../assets/public/js/slick.min.js', array('jquery'), '1.0', true );
    }

	public function get_script_depends() {
		return [ 'bwd-testimonials', 'tbt_testimonials_the_slick_js' ];
	}
	public function get_style_depends() {
        return [ 'tbt_testimonials_the_slick_main_css' ];
    }

	protected function register_controls() {
		$this->start_controls_section(
			'tbt_content_selection',
			[
				'label' => esc_html__( 'Testimonial Contents', 'bwd-testimonials' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'tbt_style_selection',
			[
				'label' => esc_html__( 'Testimonial Styles', 'bwd-testimonials' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1' => esc_html__( 'Style 1', 'bwd-testimonials' ),
					'style2'  => esc_html__( 'Style 2', 'bwd-testimonials' ),
					'style3' => esc_html__( 'Style 3', 'bwd-testimonials' ),
					'style4' => esc_html__( 'Style 4', 'bwd-testimonials' ),
					'style5' => esc_html__( 'Style 5', 'bwd-testimonials' ),
					'style6' => esc_html__( 'Style 6', 'bwd-testimonials' ),
					'style7' => esc_html__( 'Style 7', 'bwd-testimonials' ),
					'style8' => esc_html__( 'Style 8', 'bwd-testimonials' ),
					'style9' => esc_html__( 'Style 9', 'bwd-testimonials' ),
					'style10' => esc_html__( 'Style 10', 'bwd-testimonials' ),
					'style11' => esc_html__( 'Style 11', 'bwd-testimonials' ),
					'style12' => esc_html__( 'Style 12', 'bwd-testimonials' ),
					'style13' => esc_html__( 'Style 13', 'bwd-testimonials' ),
					'style14' => esc_html__( 'Style 14', 'bwd-testimonials' ),
					'style15' => esc_html__( 'Style 15', 'bwd-testimonials' ),
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'tbt_testimonial_box_background',
				'label' => esc_html__( 'Background', 'bwd-testimonials' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .tbt-background-box .tbt-testimonial-item-wrapper .tbt-testimonial-item',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'tbt_testimonial_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'bwd-testimonials' ),
				'selector' => '{{WRAPPER}} .tbt-slide-area-box-shadow',
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'tbt_image_profile_image',
			[
				'label' => esc_html__( 'Choose Profile', 'bwd-testimonials' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'tbt_team_a',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'tbt_content_name',
			[
				'label' => esc_html__( 'Name', 'bwd-testimonials' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('JHON DOE', 'bwd-testimonials'),
				'label_block' => true,
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'tbt_box_name_typography',
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .tbt-client-title',
			]
		);
		$repeater->add_control(
			'tbt_content_name_color',
			[
				'label' => esc_html__( 'Color', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tbt-testimonial-one {{CURRENT_ITEM}} .tbt-client-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbt-client-title' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'tbt_content_name_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}:hover .tbt-client-title' => 'color: {{VALUE}}'
				],
			]
		);

		$repeater->add_control(
			'tbt_team_b',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'tbt_content_designation_switcher',
			[
				'label' => esc_html__( 'Show Designation', 'bwd-testimonials' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'bwd-testimonials' ),
				'label_off' => esc_html__( 'Hide', 'bwd-testimonials' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$repeater->add_control(
			'tbt_content_designation', [
				'label' => esc_html__( 'Designation', 'bwd-testimonials' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Developer' , 'bwd-testimonials' ),
				'show_label' => false,
				'condition' => [
					'tbt_content_designation_switcher' => 'yes',
				],
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'tbt_box_TEXTAREA_typography',
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} span',
				'condition' => [
					'tbt_content_designation_switcher' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'tbt_content_designation_color',
			[
				'label' => esc_html__( 'Color', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} span' => 'color: {{VALUE}}'
				],
				'condition' => [
					'tbt_content_designation_switcher' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'tbt_content_designation_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}:hover span' => 'color: {{VALUE}}'
				],
				'condition' => [
					'tbt_content_designation_switcher' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'tbt_team_c',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'tbt_content_description', [
				'label' => esc_html__( 'Description', 'bwd-testimonials' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam, laborum laudantium. Eligendi repellat quis...' , 'bwd-testimonials' ),
				'show_label' => false,
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'tbt_box_WYSIWYG_typography',
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .tbt-client-comment',
			]
		);
		$repeater->add_control(
			'tbt_content_description_color',
			[
				'label' => esc_html__( 'Color', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbt-client-comment' => 'color: {{VALUE}}'
				],
			]
		);
		$repeater->add_control(
			'tbt_content_description_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}:hover .tbt-client-comment' => 'color: {{VALUE}}'
				],
			]
		);

		$repeater->add_control(
			'tbt_team_d',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'tbt_content_star_rating_number', [
				'label' => esc_html__( 'Star Rating', 'bwd-testimonials' ),
				'type' => Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 5,
				'default' => 4,
				'dynamic' => [
					'active' => true,
				],
			]
		);
		$repeater->add_control(
			'tbt_content_star_rating_number_color',
			[
				'label' => esc_html__( 'Color', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbt-rating' => 'color: {{VALUE}}'
				],
			]
		);
		$repeater->add_responsive_control(
			'tbt_content_star_rating_number_icon_size',
			[
				'label' => esc_html__( 'Icon Size', 'bwd-testimonials' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'laptop', 'tablet', 'tablet_extra', 'mobile', 'mobile_extra' ],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbt-rating-wrapper .tbt_testimonials_star_rating' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$repeater->add_control(
			'tbt_team_k',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'tbt_content_right_icon_switcher',
			[
				'label' => esc_html__( 'Right Icon Type (If Has)', 'bwd-testimonials' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'bwd-testimonials' ),
				'label_off' => esc_html__( 'Hide', 'bwd-testimonials' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$repeater->add_control(
			'tbt_content_icon_right',
			[
				'label' => esc_html__( 'Icon Right', 'bwd-testimonials' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-quote-right',
					'library' => 'solid',
				],
				'condition' => [
					'tbt_content_right_icon_switcher' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'tbt_content_quote_right_color',
			[
				'label' => esc_html__( 'Color', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbt-bottom-q' => 'color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbt-quote' => 'color: {{VALUE}}'
				],
				'condition' => [
					'tbt_content_right_icon_switcher' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'tbt_content_quote_right_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}:hover .tbt-bottom-q' => 'color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}}:hover .tbt-quote' => 'color: {{VALUE}}'
				],
				'condition' => [
					'tbt_content_right_icon_switcher' => 'yes',
				],
			]
		);
		$repeater->add_responsive_control(
			'tbt_testimonial_the_box_right_icon_size',
			[
				'label' => esc_html__( 'Icon Size', 'bwd-testimonials' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'devices' => [ 'desktop', 'laptop', 'tablet', 'tablet_extra', 'mobile', 'mobile_extra' ],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbt-bottom-q' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbt-quote' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'tbt_content_right_icon_switcher' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'tbt_team_f',
			[
				'type' => Controls_Manager::DIVIDER, 
			]
		);

		$repeater->add_control(
			'tbt_content_left_icon_switcher',
			[
				'label' => esc_html__( 'Left Icon Type (If Has)', 'bwd-testimonials' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'bwd-testimonials' ),
				'label_off' => esc_html__( 'Hide', 'bwd-testimonials' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$repeater->add_control(
			'tbt_content_icon_left',
			[
				'label' => esc_html__( 'Icon Left', 'bwd-testimonials' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-quote-left',
					'library' => 'solid',
				],
				'condition' => [
					'tbt_content_left_icon_switcher' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'tbt_content_quote_left_color',
			[
				'label' => esc_html__( 'Color', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbt-left-icon-tbt' => 'color: {{VALUE}}'
				],
				'condition' => [
					'tbt_content_left_icon_switcher' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'tbt_content_quote_left_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}:hover .tbt-left-icon-tbt' => 'color: {{VALUE}}'
				],
				'condition' => [
					'tbt_content_left_icon_switcher' => 'yes',
				],
			]
		);
		$repeater->add_responsive_control(
			'tbt_testimonial_the_box_left_icon_size',
			[
				'label' => esc_html__( 'Icon Size', 'bwd-testimonials' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'devices' => [ 'desktop', 'laptop', 'tablet', 'tablet_extra', 'mobile', 'mobile_extra' ],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbt-left-icon-tbt' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'tbt_content_left_icon_switcher' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'tbt_testimonials_sk_g',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'tbt_content_publish_date_switcher',
			[
				'label' => esc_html__( 'Publish Date', 'bwd-testimonials' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'bwd-testimonials' ),
				'label_off' => esc_html__( 'Hide', 'bwd-testimonials' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		$repeater->add_control(
			'tbt_testimonials_due_date',
			[
				'label' => esc_html__( 'Date', 'bwd-testimonials' ),
				'type' => \Elementor\Controls_Manager::DATE_TIME,
				'condition' => [
					'tbt_content_publish_date_switcher' => 'yes',
				],
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'tbt_due_date_typography',
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .tbt-date',
				'condition' => [
					'tbt_content_publish_date_switcher' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'tbt_content_date_color',
			[
				'label' => esc_html__( 'Color', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbt-date' => 'color: {{VALUE}}'
				],
				'condition' => [
					'tbt_content_publish_date_switcher' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'tbt_content_date_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}:hover .tbt-date:hover' => 'color: {{VALUE}}'
				],
				'condition' => [
					'tbt_content_publish_date_switcher' => 'yes',
				],
			]
		);

		$repeater->add_control(
			'tbt_team_e',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'tbt_content_box_bg_color',
			[
				'label' => esc_html__( 'Box Bg', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .slick-list.draggable' => 'background-color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'tbt_content_box_bg_hover_color',
			[
				'label' => esc_html__( 'Hover Box Bg', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}}:hover .slick-list.draggable' => 'background-color: {{VALUE}}',
				],
			]
		);

		$repeater->add_control(
			'tbt_team_h',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'tbt_content_bg_color',
			[
				'label' => esc_html__( 'Content Bg', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbt-testi-desc::before' => 'background: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbt-testi-desc' => 'background: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'tbt_content_bg_hover_color',
			[
				'label' => esc_html__( 'Hover Content Bg', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}:hover .tbt-testi-desc' => 'background-color: {{VALUE}}'
				],
			]
		);

		$repeater->add_control(
			'tbt_team_i',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'tbt_content_extra_shape_switcher',
			[
				'label' => esc_html__( 'Extra Shape (If Has)', 'bwd-testimonials' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'bwd-testimonials' ),
				'label_off' => esc_html__( 'Hide', 'bwd-testimonials' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$repeater->add_control(
			'tbt_content_extra_shape_color',
			[
				'label' => esc_html__( 'Extra Shape', 'bwd-testimonials' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbt-testi-desc::before' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbt-client-img-shape::before' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .tbt-testi-desc .tbt-quote' => 'background: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .slick-list.draggable' => 'background: {{VALUE}}',
				],
				'condition' => [
					'tbt_content_extra_shape_switcher' => 'yes',
				],
			]
		);

		$this->add_control(
			'tbt_total_box',
			[
				'label' => esc_html__( 'Testimonial Boxes', 'bwd-testimonials' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'tbt_total_box_title' => esc_html__( 'Testimonial #1', 'bwd-testimonials' ),
					],
					[
						'tbt_total_box_title' => esc_html__( 'Testimonial #2', 'bwd-testimonials' ),
					],
					[
						'tbt_total_box_title' => esc_html__( 'Testimonial #3', 'bwd-testimonials' ),
					],
					[
						'tbt_total_box_title' => esc_html__( 'Testimonial #4', 'bwd-testimonials' ),
					],
				],
				'title_field' => `{{{ tbt_total_box_title }}}`,
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'tbt_testimonial_style_section',
			[
				'label' => esc_html__( 'Testimonial Style', 'bwd-testimonials' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'tbt_testimonial_section_background',
				'label' => esc_html__( 'Background', 'bwd-testimonials' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .tbt-background-box',
			]
		);
		$this->add_responsive_control(
            'tbt_testimonial_the_box_margin',
            [
                'label' => esc_html__('Margin', 'bwd-testimonials'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .tbt-background-box .tbt-testimonial-item-wrapper .tbt-testimonial-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
            'tbt_testimonial_the_box_padding',
            [
                'label' => esc_html__('Padding', 'bwd-testimonials'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .tbt-background-box .tbt-testimonial-item-wrapper .tbt-testimonial-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
			'tbt_testimonial_the_box_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'bwd-testimonials' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'laptop', 'tablet', 'tablet_extra', 'mobile', 'mobile_extra' ],
				'selectors' => [
					'{{WRAPPER}} .tbt-background-box .tbt-testimonial-item-wrapper .tbt-testimonial-item' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		if('style1' === $settings['tbt_style_selection']){
		?>
		<section class="tbt-testimonial-two tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
				<?php
					if ( $settings['tbt_total_box'] ) {
						foreach (  $settings['tbt_total_box'] as $item ) {
					echo '<div class="tbt-testimonial-item elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
						<i class="tbt-top-q tbt-left-icon-tbt <?php echo esc_html( $item['tbt_content_icon_left']['value'] ); ?>"></i>
						<div class="tbt-client-img">
						<img src="<?php echo esc_url($item['tbt_image_profile_image']['url']); ?>" alt="client img">
						</div>
						<div class="tbt-testi-desc">
							<p class="tbt-client-comment"><?php echo esc_html($item['tbt_content_description']); ?></p>
							<h4 class="tbt-client-title"><?php echo esc_html($item['tbt_content_name']); ?></h4>
							<?php
							if ( 'yes' === $item['tbt_content_designation_switcher'] ) {
								?>
							<span><?php echo esc_html($item['tbt_content_designation']); ?></span>
							<?php
							}
							?>
							<div class="tbt-rating-wrapper">
								<div class="tbt-rating tbt_testimonials_star_rating">
									<?php
									if(0 >= $item['tbt_content_star_rating_number']){
									} elseif(1 == $item['tbt_content_star_rating_number']){
										?>
									<i class="fas fa-star"></i>
									<?php
									} elseif(2 == $item['tbt_content_star_rating_number']){
										?>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<?php
										} elseif(3 == $item['tbt_content_star_rating_number']){
											?>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<?php
											} elseif(4 == $item['tbt_content_star_rating_number']){
												?>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<?php
												} else {
													?>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<?php
													} 
									?>
								</div>
								<div class="tbt-rating-gray tbt_testimonials_star_rating">
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
								</div>
							</div>
							<?php
							if ( 'yes' === $item['tbt_content_publish_date_switcher'] ) {
								?>
							<div class="tbt-date"><?php echo esc_html($item['tbt_testimonials_due_date']); ?></div>
							<?php
							}
							?>
						</div>
						<!-- <i class="fas fa-quote-right tbt-bottom-q"></i> -->
						<i class="tbt-bottom-q <?php echo esc_attr( $item['tbt_content_icon_right']['value'] ); ?>"></i>
					</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</section>
		<?php
		} elseif ('style2' === $settings['tbt_style_selection']) {
		?>
		<section class="tbt-testimonial-one tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
				<?php
					if ( $settings['tbt_total_box'] ) {
						foreach (  $settings['tbt_total_box'] as $item ) {
					echo '<div class="tbt-testimonial-item elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
						<div class="tbt-testi-desc">
							<p class="tbt-client-comment"><?php echo esc_html($item['tbt_content_description']); ?></p>
						</div>
						<div class="tbt-client-profile">
							<div class="tbt-client-img">
								<img src="<?php echo esc_url($item['tbt_image_profile_image']['url']); ?>" alt="client img">
							</div>
							<div class="tbt-client-bio">
								<h4 class="tbt-client-title"><?php echo esc_html($item['tbt_content_name']); ?></h4>
								<?php
								if ( 'yes' === $item['tbt_content_designation_switcher'] ) {
									?>
								<span><?php echo esc_html($item['tbt_content_designation']); ?></span>
								<?php
								}
								?>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<?php
										if(0 >= $item['tbt_content_star_rating_number']){
										} elseif(1 == $item['tbt_content_star_rating_number']){
											?>
										<i class="fas fa-star"></i>
										<?php
										} elseif(2 == $item['tbt_content_star_rating_number']){
											?>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<?php
											} elseif(3 == $item['tbt_content_star_rating_number']){
												?>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<?php
												} elseif(4 == $item['tbt_content_star_rating_number']){
													?>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<?php
													} else {
														?>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<?php
														} 
										?>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
							</div>
						</div>
						<?php
						if ( 'yes' === $item['tbt_content_publish_date_switcher'] ) {
							?>
						<div class="tbt-date"><?php echo esc_html($item['tbt_testimonials_due_date']); ?></div>
						<?php
						}
						?>
					</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</section>
		<?php
		} elseif ('style3' === $settings['tbt_style_selection']){
		?>
		<section class="tbt-testimonial-three tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
				<?php
					if ( $settings['tbt_total_box'] ) {
						foreach (  $settings['tbt_total_box'] as $item ) {
					echo '<div class="tbt-testimonial-item elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
						<i class="tbt-bottom-q <?php echo esc_attr( $item['tbt_content_icon_right']['value'] ); ?>"></i>
						<div class="tbt-testi-desc">
							<p class="tbt-client-comment"><?php echo esc_html($item['tbt_content_description']); ?></p>
						</div>
						<div class="tbt-client-img">
							<img src="<?php echo esc_url($item['tbt_image_profile_image']['url']); ?>" alt="client img">
						</div>
						<h4 class="tbt-client-title"><?php echo esc_html($item['tbt_content_name']); ?></h4>
						<div class="tbt-rating-wrapper">
							<div class="tbt-rating tbt_testimonials_star_rating">
								<?php
								if(0 >= $item['tbt_content_star_rating_number']){
								} elseif(1 == $item['tbt_content_star_rating_number']){
									?>
								<i class="fas fa-star"></i>
								<?php
								} elseif(2 == $item['tbt_content_star_rating_number']){
									?>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<?php
									} elseif(3 == $item['tbt_content_star_rating_number']){
										?>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<?php
										} elseif(4 == $item['tbt_content_star_rating_number']){
											?>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<?php
											} else {
												?>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<?php
												} 
								?>
							</div>
							<div class="tbt-rating-gray tbt_testimonials_star_rating">
								<i class="fas fa-star"></i>
								<i class="fas fa-star"></i>
								<i class="fas fa-star"></i>
								<i class="fas fa-star"></i>
								<i class="fas fa-star"></i>
							</div>
						</div>
						<?php
						if ( 'yes' === $item['tbt_content_designation_switcher'] ) {
						?>
						<span><?php echo esc_html($item['tbt_content_designation']); ?></span>
						<?php
						}
						if ( 'yes' === $item['tbt_content_publish_date_switcher'] ) {
							?>
						<div class="tbt-date"><?php echo esc_html($item['tbt_testimonials_due_date']); ?></div>
						<?php
						}
						?>
					</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</section>
		<?php
		} elseif ('style4' === $settings['tbt_style_selection']){
		?>
		<section class="tbt-testimonial-four tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
				<?php
					if ( $settings['tbt_total_box'] ) {
						foreach (  $settings['tbt_total_box'] as $item ) {
					echo '<div class="tbt-testimonial-item elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
						<div class="tbt-testi-desc">
							<i class="tbt-quote-top <?php echo esc_attr( $item['tbt_content_icon_left']['value'] ); ?>"></i>
							<p class="tbt-client-comment"><?php echo esc_html($item['tbt_content_description']); ?></p>
							<i class="tbt-quote-bottom <?php echo esc_attr( $item['tbt_content_icon_right']['value'] ); ?>"></i>
						</div>
						<div class="tbt-client-profile">
							<div class="tbt-client-img">
								<img src="<?php echo esc_url($item['tbt_image_profile_image']['url']); ?>" alt="client img">
							</div>
							<div class="tbt-client-bio">
								<h4 class="tbt-client-title"><?php echo esc_html($item['tbt_content_name']); ?></h4>
								<?php
								if ( 'yes' === $item['tbt_content_designation_switcher'] ) {
								?>
								<span><?php echo esc_html($item['tbt_content_designation']); ?></span>
								<?php
								} ?>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<?php
										if(0 >= $item['tbt_content_star_rating_number']){
										} elseif(1 == $item['tbt_content_star_rating_number']){
											?>
										<i class="fas fa-star"></i>
										<?php
										} elseif(2 == $item['tbt_content_star_rating_number']){
											?>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<?php
											} elseif(3 == $item['tbt_content_star_rating_number']){
												?>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<?php
												} elseif(4 == $item['tbt_content_star_rating_number']){
													?>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<?php
													} else {
														?>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<?php
														} 
										?>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
								<?php
								if ( 'yes' === $item['tbt_content_publish_date_switcher'] ) {
									?>
								<div class="tbt-date"><?php echo esc_html($item['tbt_testimonials_due_date']); ?></div>
								<?php
								}
								?>
							</div>
						</div>
					</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</section>
		<?php
		} elseif ('style5' === $settings['tbt_style_selection']){
		?>
		<section class="tbt-testimonial-five tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
				<?php
					if ( $settings['tbt_total_box'] ) {
						foreach (  $settings['tbt_total_box'] as $item ) {
					echo '<div class="tbt-testimonial-item elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
						<div class="tbt-client-profile tbt-slide-area-box-shadow">
							<div class="tbt-client-img">
								<img src="<?php echo esc_url($item['tbt_image_profile_image']['url']); ?>" alt="client img">
							</div>
							<div class="tbt-client-bio">
								<h4 class="tbt-client-title"><?php echo esc_html($item['tbt_content_name']); ?></h4>
								<?php
								if ( 'yes' === $item['tbt_content_designation_switcher'] ) {
								?>
								<span><?php echo esc_html($item['tbt_content_designation']); ?></span>
								<?php
								}
								?>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<?php
										if(0 >= $item['tbt_content_star_rating_number']){
										} elseif(1 == $item['tbt_content_star_rating_number']){
											?>
										<i class="fas fa-star"></i>
										<?php
										} elseif(2 == $item['tbt_content_star_rating_number']){
											?>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<?php
											} elseif(3 == $item['tbt_content_star_rating_number']){
												?>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<?php
												} elseif(4 == $item['tbt_content_star_rating_number']){
													?>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<?php
													} else {
														?>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<?php
														} 
										?>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
							</div>
						</div>
						<div class="tbt-testi-desc">
							<i class="tbt-quote <?php echo esc_attr( $item['tbt_content_icon_right']['value'] ); ?>"></i>
							<?php
							if ( 'yes' === $item['tbt_content_publish_date_switcher'] ) {
							?>
							<h5 class="tbt-client-skill"><?php echo esc_html($item['tbt_testimonials_due_date']); ?></h5>
							<?php
							}
							?>
							<p class="tbt-client-comment"><?php echo esc_html($item['tbt_content_description']); ?></p>
						</div>
					</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</section>
		<?php
		} elseif ('style6' === $settings['tbt_style_selection']){
		?>
		<div class="tbt-testimonial-six tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
					<div class="tbt-slide-area tbt-slide-area-box-shadow">
				<?php
					if ( $settings['tbt_total_box'] ) {
						foreach (  $settings['tbt_total_box'] as $item ) {
						echo '<div class="tbt-slide-item elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; 
							if ( 'yes' === $item['tbt_content_publish_date_switcher'] ) {
								?>
							<div class="tbt-date"><?php echo esc_html($item['tbt_testimonials_due_date']); ?></div>
							<?php
							}
							?>
							<p class="tbt-client-comment"><?php echo esc_html($item['tbt_content_description']); ?></p>
							<h4 class="tbt-client-title"><?php echo esc_html($item['tbt_content_name']); ?></h4>
								<?php
								if ( 'yes' === $item['tbt_content_designation_switcher'] ) {
								?>
								<span><?php echo esc_html($item['tbt_content_designation']); ?></span>
								<?php
								}
								?>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<?php
										if(0 >= $item['tbt_content_star_rating_number']){
										} elseif(1 == $item['tbt_content_star_rating_number']){
											?>
										<i class="fas fa-star"></i>
										<?php
										} elseif(2 == $item['tbt_content_star_rating_number']){
											?>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<?php
											} elseif(3 == $item['tbt_content_star_rating_number']){
												?>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<?php
												} elseif(4 == $item['tbt_content_star_rating_number']){
													?>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<?php
													} else {
														?>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<?php
														} 
										?>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
						</div>
					<?php
						}
					}
					?>
					</div>
					<div class="tbt-slide-indicators tbt-slide-area-box-shadow">
				<?php
					if ( $settings['tbt_total_box'] ) {
						foreach (  $settings['tbt_total_box'] as $item ) {
						echo '<div class="tbt-indicators-img elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
						<img src="<?php echo esc_url($item['tbt_image_profile_image']['url']); ?>" alt="client img">
						</div>
					<?php
						}
					}
					?>
					</div>
				</div>
			</div>
		</div>
		<?php
		} elseif ('style7' === $settings['tbt_style_selection']){
		?>
		<section class="tbt-testimonial-seven tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
				<?php
					if ( $settings['tbt_total_box'] ) {
						foreach (  $settings['tbt_total_box'] as $item ) {
					echo '<div class="tbt-testimonial-item elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
						<div class="tbt-client-profile">
							<div class="tbt-client-img">
								<img src="<?php echo esc_url($item['tbt_image_profile_image']['url']); ?>" alt="client img">
							</div>
							<div class="tbt-client-bio">
								<h4 class="tbt-client-title"><?php echo esc_html($item['tbt_content_name']); ?></h4>
								<?php
								if ( 'yes' === $item['tbt_content_designation_switcher'] ) {
								?>
								<span><?php echo esc_html($item['tbt_content_designation']); ?></span>
								<?php
								}
								?>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<?php
										if(0 >= $item['tbt_content_star_rating_number']){
										} elseif(1 == $item['tbt_content_star_rating_number']){
											?>
										<i class="fas fa-star"></i>
										<?php
										} elseif(2 == $item['tbt_content_star_rating_number']){
											?>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<?php
											} elseif(3 == $item['tbt_content_star_rating_number']){
												?>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<?php
												} elseif(4 == $item['tbt_content_star_rating_number']){
													?>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<?php
													} else {
														?>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<?php
														} 
										?>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
							</div>
						</div>
						<div class="tbt-testi-desc">
						<?php
						if ( 'yes' === $item['tbt_content_publish_date_switcher'] ) {
							?>
						<div class="tbt-date"><?php echo esc_html($item['tbt_testimonials_due_date']); ?></div>
						<?php
						}
						?>
						<p class="tbt-client-comment"><?php echo esc_html($item['tbt_content_description']); ?></p>
						</div>
					</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</section>
		<?php
		} elseif ('style8' === $settings['tbt_style_selection']){
		?>
		<section class="tbt-testimonial-eight tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
				<?php
					if ( $settings['tbt_total_box'] ) {
						foreach (  $settings['tbt_total_box'] as $item ) {
					echo '<div class="tbt-testimonial-item elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
						<div class="tbt-client-img">
								<img src="<?php echo esc_url($item['tbt_image_profile_image']['url']); ?>" alt="client img">
						</div>
						<div class="tbt-testi-desc tbt-slide-area-box-shadow">
							<i class="tbt-quote <?php echo esc_attr( $item['tbt_content_icon_right']['value'] ); ?>"></i>
							<?php
							if ( 'yes' === $item['tbt_content_publish_date_switcher'] ) {
								?>
							<div class="tbt-date"><?php echo esc_html($item['tbt_testimonials_due_date']); ?></div>
							<?php
							}
							?>
							<p class="tbt-client-comment"><?php echo esc_html($item['tbt_content_description']); ?></p>
							<h4 class="tbt-client-title"><?php echo esc_html($item['tbt_content_name']); ?></h4>
								<?php
								if ( 'yes' === $item['tbt_content_designation_switcher'] ) {
								?>
								<span><?php echo esc_html($item['tbt_content_designation']); ?></span>
								<?php
								}
								?>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<?php
										if(0 >= $item['tbt_content_star_rating_number']){
										} elseif(1 == $item['tbt_content_star_rating_number']){
											?>
										<i class="fas fa-star"></i>
										<?php
										} elseif(2 == $item['tbt_content_star_rating_number']){
											?>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<?php
											} elseif(3 == $item['tbt_content_star_rating_number']){
												?>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<?php
												} elseif(4 == $item['tbt_content_star_rating_number']){
													?>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<?php
													} else {
														?>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<?php
														} 
										?>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
						</div>
					</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</section>
		<?php
		} elseif ('style9' === $settings['tbt_style_selection']){
		?>
		<section class="tbt-testimonial-nine tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
				<?php
					if ( $settings['tbt_total_box'] ) {
						foreach (  $settings['tbt_total_box'] as $item ) {
					echo '<div class="tbt-testimonial-item elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
						<div class="tbt-client-profile tbt-slide-area-box-shadow">
							<div class="tbt-client-img">
								<img src="<?php echo esc_url($item['tbt_image_profile_image']['url']); ?>" alt="client img">
							</div>
							<div class="tbt-client-bio">
								<h4 class="tbt-client-title"><?php echo esc_html($item['tbt_content_name']); ?></h4>
								<?php
								if ( 'yes' === $item['tbt_content_designation_switcher'] ) {
								?>
								<span><?php echo esc_html($item['tbt_content_designation']); ?></span>
								<?php
								}
								?>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<?php
										if(0 >= $item['tbt_content_star_rating_number']){
										} elseif(1 == $item['tbt_content_star_rating_number']){
											?>
										<i class="fas fa-star"></i>
										<?php
										} elseif(2 == $item['tbt_content_star_rating_number']){
											?>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<?php
											} elseif(3 == $item['tbt_content_star_rating_number']){
												?>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<?php
												} elseif(4 == $item['tbt_content_star_rating_number']){
													?>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<?php
													} else {
														?>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<?php
														} 
										?>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
							</div>
						</div>
						<div class="tbt-testi-desc tbt-slide-area-box-shadow">
							<i class="tbt-quote <?php echo esc_attr( $item['tbt_content_icon_right']['value'] ); ?>"></i>
							<p class="tbt-client-comment"><?php echo esc_html($item['tbt_content_description']); ?></p>
							<?php
							if ( 'yes' === $item['tbt_content_publish_date_switcher'] ) {
								?>
							<div class="tbt-date"><?php echo esc_html($item['tbt_testimonials_due_date']); ?></div>
							<?php
							}
							?>
						</div>
					</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</section>
		<?php
		} elseif ('style10' === $settings['tbt_style_selection']){
		?>
		<section class="tbt-testimonial-ten tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
				<?php
					if ( $settings['tbt_total_box'] ) {
						foreach (  $settings['tbt_total_box'] as $item ) {
					echo '<div class="tbt-testimonial-item elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
						<div class="tbt-client-img-shape">
							<div class="tbt-client-img">
								<img src="<?php echo esc_url($item['tbt_image_profile_image']['url']); ?>" alt="client img">
							</div>
						</div>
						<div class="tbt-testi-desc">
							<i class="tbt-quote <?php echo esc_attr( $item['tbt_content_icon_left']['value'] ); ?>"></i>
							<p class="tbt-client-comment"><?php echo esc_html($item['tbt_content_description']); ?></p>
							<div class="tbt-rating-wrapper">
								<div class="tbt-rating tbt_testimonials_star_rating">
									<?php
									if(0 >= $item['tbt_content_star_rating_number']){
									} elseif(1 == $item['tbt_content_star_rating_number']){
										?>
									<i class="fas fa-star"></i>
									<?php
									} elseif(2 == $item['tbt_content_star_rating_number']){
										?>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<?php
										} elseif(3 == $item['tbt_content_star_rating_number']){
											?>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<?php
											} elseif(4 == $item['tbt_content_star_rating_number']){
												?>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<?php
												} else {
													?>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<?php
													} 
									?>
								</div>
								<div class="tbt-rating-gray tbt_testimonials_star_rating">
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
								</div>
							</div>
							<div class="tbt-client-bio">
								<h4 class="tbt-client-title"><?php echo esc_html($item['tbt_content_name']); ?></h4>
								<?php
								if ( 'yes' === $item['tbt_content_publish_date_switcher'] ) {
									?>
								<div class="tbt-date"><?php echo esc_html($item['tbt_testimonials_due_date']); ?></div>
								<?php
								}
								
								if ( 'yes' === $item['tbt_content_designation_switcher'] ) {
								?>
								<span><?php echo esc_html($item['tbt_content_designation']); ?></span>
								<?php
								}
								?>
							</div>
						</div>
					</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</section>
		<?php
		} elseif ('style11' === $settings['tbt_style_selection']){
		?>
		<section class="tbt-testimonial-eleven tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
				<?php
					if ( $settings['tbt_total_box'] ) {
						foreach (  $settings['tbt_total_box'] as $item ) {
					echo '<div class="tbt-testimonial-item elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
						<div class="tbt-client-profile">
							<div class="tbt-client-img">
								<img src="<?php echo esc_url($item['tbt_image_profile_image']['url']); ?>" alt="client img">
							</div>
							<div class="tbt-client-bio">
								<h4 class="tbt-client-title"><?php echo esc_html($item['tbt_content_name']); ?></h4>
								<?php
								if ( 'yes' === $item['tbt_content_designation_switcher'] ) {
								?>
								<span><?php echo esc_html($item['tbt_content_designation']); ?></span>
								<?php
								}
								?>
							</div>
						</div>
						<div class="tbt-testi-desc">
						<p class="tbt-client-comment"><?php echo esc_html($item['tbt_content_description']); ?></p>
							<div class="tbt-client-review">
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<?php
										if(0 >= $item['tbt_content_star_rating_number']){
										} elseif(1 == $item['tbt_content_star_rating_number']){
											?>
										<i class="fas fa-star"></i>
										<?php
										} elseif(2 == $item['tbt_content_star_rating_number']){
											?>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<?php
											} elseif(3 == $item['tbt_content_star_rating_number']){
												?>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<?php
												} elseif(4 == $item['tbt_content_star_rating_number']){
													?>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<?php
													} else {
														?>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<?php
														} 
										?>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
								<?php
								if ( 'yes' === $item['tbt_content_publish_date_switcher'] ) {
									?>
								<div class="tbt-date"><?php echo esc_html($item['tbt_testimonials_due_date']); ?></div>
								<?php
								}
								?>
							</div>
						</div>
					</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</section>
		<?php
		} elseif ('style12' === $settings['tbt_style_selection']){
		?>
		<section class="tbt-testimonial-twelve tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
				<?php
					if ( $settings['tbt_total_box'] ) {
						foreach (  $settings['tbt_total_box'] as $item ) {
					echo '<div class="tbt-testimonial-item elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
						<div class="tbt-client-img-shape">
							<div class="tbt-client-img">
								<img src="<?php echo esc_url($item['tbt_image_profile_image']['url']); ?>" alt="client img">
							</div>
						</div>
						<div class="tbt-client-profile">
							<h4 class="tbt-client-title"><?php echo esc_html($item['tbt_content_name']); ?></h4>
							<?php
							if ( 'yes' === $item['tbt_content_designation_switcher'] ) {
							?>
							<span><?php echo esc_html($item['tbt_content_designation']); ?></span>
							<?php
							}
							?>
							<p class="tbt-client-comment"><?php echo esc_html($item['tbt_content_description']); ?></p>
							<?php
							if ( 'yes' === $item['tbt_content_publish_date_switcher'] ) {
								?>
							<div class="tbt-date"><?php echo esc_html($item['tbt_testimonials_due_date']); ?></div>
							<?php
							}
							?>
							<div class="tbt-rating-wrapper">
								<div class="tbt-rating tbt_testimonials_star_rating">
									<?php
									if(0 >= $item['tbt_content_star_rating_number']){
									} elseif(1 == $item['tbt_content_star_rating_number']){
										?>
									<i class="fas fa-star"></i>
									<?php
									} elseif(2 == $item['tbt_content_star_rating_number']){
										?>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<?php
										} elseif(3 == $item['tbt_content_star_rating_number']){
											?>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<?php
											} elseif(4 == $item['tbt_content_star_rating_number']){
												?>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<?php
												} else {
													?>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<?php
													} 
									?>
								</div>
								<div class="tbt-rating-gray tbt_testimonials_star_rating">
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
								</div>
							</div>
						</div>
					</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</section>
		<?php
		} elseif ('style13' === $settings['tbt_style_selection']){
		?>
		<section class="tbt-testimonial-thirteen tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
				<?php
					if ( $settings['tbt_total_box'] ) {
						foreach (  $settings['tbt_total_box'] as $item ) {
					echo '<div class="tbt-testimonial-item elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
						<div class="tbt-testi-desc">
							<i class="tbt-quote tbt-left-icon-tbt <?php echo esc_attr( $item['tbt_content_icon_left']['value'] ); ?>"></i>
							<p class="tbt-client-comment"><?php echo esc_html($item['tbt_content_description']); ?></p>
						</div>
						<div class="tbt-client-profile">
							<div class="tbt-client-img">
								<img src="<?php echo esc_url($item['tbt_image_profile_image']['url']); ?>" alt="client img">
							</div>
							<h4 class="tbt-client-title"><?php echo esc_html($item['tbt_content_name']); ?></h4>
								<?php
								if ( 'yes' === $item['tbt_content_publish_date_switcher'] ) {
									?>
								<div class="tbt-date"><?php echo esc_html($item['tbt_testimonials_due_date']); ?></div>
								<?php
								}
								
								if ( 'yes' === $item['tbt_content_designation_switcher'] ) {
								?>
								<span><?php echo esc_html($item['tbt_content_designation']); ?></span>
								<?php
								}
								?>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<?php
										if(0 >= $item['tbt_content_star_rating_number']){
										} elseif(1 == $item['tbt_content_star_rating_number']){
											?>
										<i class="fas fa-star"></i>
										<?php
										} elseif(2 == $item['tbt_content_star_rating_number']){
											?>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<?php
											} elseif(3 == $item['tbt_content_star_rating_number']){
												?>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<?php
												} elseif(4 == $item['tbt_content_star_rating_number']){
													?>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<?php
													} else {
														?>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<?php
														} 
										?>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
						</div>
					</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</section>
		<?php
		} elseif ('style14' === $settings['tbt_style_selection']){
		?>
		<section class="tbt-testimonial-fourteen tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
				<?php
					if ( $settings['tbt_total_box'] ) {
						foreach (  $settings['tbt_total_box'] as $item ) {
					echo '<div class="tbt-testimonial-item elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
						<div class="tbt-client-profile tbt-slide-area-box-shadow">
							<div class="tbt-client-img">
								<img src="<?php echo esc_url($item['tbt_image_profile_image']['url']); ?>" alt="client img">
							</div>
							<div class="tbt-client-bio">
								<?php
								if ( 'yes' === $item['tbt_content_publish_date_switcher'] ) {
									?>
								<div class="tbt-date"><?php echo esc_html($item['tbt_testimonials_due_date']); ?></div>
								<?php
								}
								?>
								<h4 class="tbt-client-title"><?php echo esc_html($item['tbt_content_name']); ?></h4>
								<?php
								if ( 'yes' === $item['tbt_content_designation_switcher'] ) {
								?>
								<span><?php echo esc_html($item['tbt_content_designation']); ?></span>
								<?php
								}
								?>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<?php
										if(0 >= $item['tbt_content_star_rating_number']){
										} elseif(1 == $item['tbt_content_star_rating_number']){
											?>
										<i class="fas fa-star"></i>
										<?php
										} elseif(2 == $item['tbt_content_star_rating_number']){
											?>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<?php
											} elseif(3 == $item['tbt_content_star_rating_number']){
												?>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<?php
												} elseif(4 == $item['tbt_content_star_rating_number']){
													?>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<?php
													} else {
														?>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<?php
														} 
										?>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
							</div>
						</div>
						<div class="tbt-testi-desc">
						<p class="tbt-client-comment"><?php echo esc_html($item['tbt_content_description']); ?></p>
						</div>
					</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</section>
		<?php
		} elseif ('style15' === $settings['tbt_style_selection']){
		?>
		<section class="tbt-testimonial-fifteen tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
				<?php
					if ( $settings['tbt_total_box'] ) {
						foreach (  $settings['tbt_total_box'] as $item ) {
					echo '<div class="tbt-testimonial-item elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
						<div class="tbt-testi-desc">
							<p class="tbt-client-comment"><?php echo esc_html($item['tbt_content_description']); ?></p>
						</div>
						<div class="tbt-client-profile">
							<div class="tbt-client-img">
								<img src="<?php echo esc_url($item['tbt_image_profile_image']['url']); ?>" alt="client img">
							</div>
							<div class="tbt-client-bio">
								<?php
								if ( 'yes' === $item['tbt_content_publish_date_switcher'] ) {
									?>
								<div class="tbt-date"><?php echo esc_html($item['tbt_testimonials_due_date']); ?></div>
								<?php
								}
								?>
								<h4 class="tbt-client-title"><?php echo esc_html($item['tbt_content_name']); ?></h4>
								<?php
								if ( 'yes' === $item['tbt_content_designation_switcher'] ) {
								?>
								<span><?php echo esc_html($item['tbt_content_designation']); ?></span>
								<?php
								}
								?>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<?php
										if(0 >= $item['tbt_content_star_rating_number']){
										} elseif(1 == $item['tbt_content_star_rating_number']){
											?>
										<i class="fas fa-star"></i>
										<?php
										} elseif(2 == $item['tbt_content_star_rating_number']){
											?>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<?php
											} elseif(3 == $item['tbt_content_star_rating_number']){
												?>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<?php
												} elseif(4 == $item['tbt_content_star_rating_number']){
													?>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<?php
													} else {
														?>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<?php
														} 
										?>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php
						}
					}
					?>
				</div>
			</div>
		</section>
		<?php
		}
	}
	
	protected function content_template() {
		?>
		<# if('style1' === settings['tbt_style_selection']){ #>
		<section class="tbt-testimonial-two tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
					<# if ( settings.tbt_total_box.length ) { #>
						<# _.each( settings.tbt_total_box, function( item ) { #>
					<div class="tbt-testimonial-item elementor-repeater-item-{{ item._id }}">
						<i class="tbt-top-q tbt-left-icon-tbt {{{item['tbt_content_icon_left']['value']}}}"></i>
						<div class="tbt-client-img">
							<img src="{{{item['tbt_image_profile_image']['url']}}}" alt="client img">
						</div>
						<div class="tbt-testi-desc">
							<p class="tbt-client-comment">{{{item['tbt_content_description']}}}</p>
							<h4 class="tbt-client-title">{{{item['tbt_content_name']}}}</h4>
							<# if ( 'yes' === item.tbt_content_designation_switcher ) { #>
							<span>{{{item['tbt_content_designation']}}}</span>
							<# } #>
							<div class="tbt-rating-wrapper">
								<div class="tbt-rating tbt_testimonials_star_rating">
									<#
									if(0 >= item['tbt_content_star_rating_number']){
									} else if(1 == item['tbt_content_star_rating_number']){
										#>
									<i class="fas fa-star"></i>
									<#
									} else if(2 == item['tbt_content_star_rating_number']){
										#>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<#
										} else if(3 == item['tbt_content_star_rating_number']){
											#>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<#
											} else if(4 == item['tbt_content_star_rating_number']){
												#>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<#
												} else {
													#>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<#
													} 
									#>
								</div>
								<div class="tbt-rating-gray tbt_testimonials_star_rating">
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
								</div>
							</div>
							<# if ( 'yes' === item.tbt_content_publish_date_switcher ) { #>
							<div class="tbt-date">{{{item['tbt_testimonials_due_date']}}}</div>
							<# } #>
						</div>
						<i class="tbt-bottom-q {{{item['tbt_content_icon_right']['value']}}}"></i>
					</div>
						<# }); #>
					<# } #>
				</div>
			</div>
		</section>
		<# } else if('style2' === settings['tbt_style_selection']){ #>
		<section class="tbt-testimonial-one tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
					<# if ( settings.tbt_total_box.length ) { #>
						<# _.each( settings.tbt_total_box, function( item ) { #>
					<div class="tbt-testimonial-item elementor-repeater-item-{{ item._id }}">
						<div class="tbt-testi-desc">
							<p class="tbt-client-comment">{{{item['tbt_content_description']}}}</p>
						</div>
						<div class="tbt-client-profile">
							<div class="tbt-client-img">
								<img src="{{{item['tbt_image_profile_image']['url']}}}" alt="client img">
							</div>
							<div class="tbt-client-bio">
								<h4 class="tbt-client-title">{{{item['tbt_content_name']}}}</h4>
								<# if ( 'yes' === item.tbt_content_designation_switcher ) { #>
								<span>{{{item['tbt_content_designation']}}}</span>
								<# } #>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<#
										if(0 >= item['tbt_content_star_rating_number']){
										} else if(1 == item['tbt_content_star_rating_number']){
											#>
										<i class="fas fa-star"></i>
										<#
										} else if(2 == item['tbt_content_star_rating_number']){
											#>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<#
											} else if(3 == item['tbt_content_star_rating_number']){
												#>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<#
												} else if(4 == item['tbt_content_star_rating_number']){
													#>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<#
													} else {
														#>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<#
														} 
										#>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
							</div>
						</div>
						<# if ( 'yes' === item.tbt_content_publish_date_switcher ) { #>
						<div class="tbt-date">{{{item['tbt_testimonials_due_date']}}}</div>
						<# } #>
					</div>
						<# }); #>
					<# } #>
				</div>
			</div>
		</section>
		<# } else if('style3' === settings['tbt_style_selection']){ #>
		<section class="tbt-testimonial-three tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
					<# if ( settings.tbt_total_box.length ) { #>
						<# _.each( settings.tbt_total_box, function( item ) { #>
					<div class="tbt-testimonial-item elementor-repeater-item-{{ item._id }}">
						<i class="tbt-bottom-q {{{item['tbt_content_icon_right']['value']}}}"></i>
						<div class="tbt-testi-desc">
							<p class="tbt-client-comment">{{{item['tbt_content_description']}}}</p>
						</div>
						<div class="tbt-client-img">
							<img src="{{{item['tbt_image_profile_image']['url']}}}" alt="client img">
						</div>
						<h4 class="tbt-client-title">{{{item['tbt_content_name']}}}</h4>
						<div class="tbt-rating-wrapper">
							<div class="tbt-rating tbt_testimonials_star_rating">
								<#
								if(0 >= item['tbt_content_star_rating_number']){
								} else if(1 == item['tbt_content_star_rating_number']){
									#>
								<i class="fas fa-star"></i>
								<#
								} else if(2 == item['tbt_content_star_rating_number']){
									#>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<#
									} else if(3 == item['tbt_content_star_rating_number']){
										#>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<#
										} else if(4 == item['tbt_content_star_rating_number']){
											#>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<#
											} else {
												#>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<#
												} 
								#>
							</div>
							<div class="tbt-rating-gray tbt_testimonials_star_rating">
								<i class="fas fa-star"></i>
								<i class="fas fa-star"></i>
								<i class="fas fa-star"></i>
								<i class="fas fa-star"></i>
								<i class="fas fa-star"></i>
							</div>
						</div>
						<# if ( 'yes' === item.tbt_content_designation_switcher ) { #>
						<span>{{{item['tbt_content_designation']}}}</span>
						<# } 
						if ( 'yes' === item.tbt_content_publish_date_switcher ) { #>
						<div class="tbt-date">{{{item['tbt_testimonials_due_date']}}}</div>
						<# } #>
					</div>
						<# }); #>
					<# } #>
				</div>
			</div>
		</section>
		<# } else if('style4' === settings['tbt_style_selection']){ #>
		<section class="tbt-testimonial-four tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
					<# if ( settings.tbt_total_box.length ) { #>
						<# _.each( settings.tbt_total_box, function( item ) { #>
					<div class="tbt-testimonial-item elementor-repeater-item-{{ item._id }}">
						<div class="tbt-testi-desc">
							<i class="tbt-quote-top {{{item['tbt_content_icon_left']['value']}}}"></i>
							<p class="tbt-client-comment">{{{item['tbt_content_description']}}}</p>
							<i class="tbt-quote-bottom {{{item['tbt_content_icon_right']['value']}}}"></i>
						</div>
						<div class="tbt-client-profile">
							<div class="tbt-client-img">
								<img src="{{{item['tbt_image_profile_image']['url']}}}" alt="client img">
							</div>
							<div class="tbt-client-bio">
								<h4 class="tbt-client-title">{{{item['tbt_content_name']}}}</h4>
								<# if ( 'yes' === item.tbt_content_designation_switcher ) { #>
								<span>{{{item['tbt_content_designation']}}}</span>
								<# } #>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<#
										if(0 >= item['tbt_content_star_rating_number']){
										} else if(1 == item['tbt_content_star_rating_number']){
											#>
										<i class="fas fa-star"></i>
										<#
										} else if(2 == item['tbt_content_star_rating_number']){
											#>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<#
											} else if(3 == item['tbt_content_star_rating_number']){
												#>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<#
												} else if(4 == item['tbt_content_star_rating_number']){
													#>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<#
													} else {
														#>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<#
														} 
										#>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
								<# if ( 'yes' === item.tbt_content_publish_date_switcher ) { #>
								<div class="tbt-date">{{{item['tbt_testimonials_due_date']}}}</div>
								<# } #>
							</div>
						</div>
					</div>
						<# }); #>
					<# } #>
				</div>
			</div>
		</section>
		<# } else if('style5' === settings['tbt_style_selection']){ #>
		<section class="tbt-testimonial-five tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
					<# if ( settings.tbt_total_box.length ) { #>
						<# _.each( settings.tbt_total_box, function( item ) { #>
					<div class="tbt-testimonial-item elementor-repeater-item-{{ item._id }}">
						<div class="tbt-client-profile tbt-slide-area-box-shadow">
							<div class="tbt-client-img">
								<img src="{{{item['tbt_image_profile_image']['url']}}}" alt="client img">
							</div>
							<div class="tbt-client-bio">
								<h4 class="tbt-client-title">{{{item['tbt_content_name']}}}</h4>
								<# if ( 'yes' === item.tbt_content_designation_switcher ) { #>
								<span>{{{item['tbt_content_designation']}}}</span>
								<# } #>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<#
										if(0 >= item['tbt_content_star_rating_number']){
										} else if(1 == item['tbt_content_star_rating_number']){
											#>
										<i class="fas fa-star"></i>
										<#
										} else if(2 == item['tbt_content_star_rating_number']){
											#>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<#
											} else if(3 == item['tbt_content_star_rating_number']){
												#>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<#
												} else if(4 == item['tbt_content_star_rating_number']){
													#>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<#
													} else {
														#>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<#
														} 
										#>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
							</div>
						</div>
						<div class="tbt-testi-desc">
							<i class="tbt-quote {{{item['tbt_content_icon_right']['value']}}}"></i>
							<# if ( 'yes' === item.tbt_content_publish_date_switcher ) { #>
							<h5 class="tbt-client-skill">{{{item['tbt_testimonials_due_date']}}}</h5>
							<# } #>
							<p class="tbt-client-comment">{{{item['tbt_content_description']}}}</p>
						</div>
					</div>
						<# }); #>
					<# } #>
				</div>
			</div>
		</section>
		<# } else if('style6' === settings['tbt_style_selection']){ #>
			<div class="tbt-testimonial-six tbt-background-box">
				<div class="container">
					<div class="tbt-testimonial-item-wrapper">
						<div class="tbt-slide-area tbt-slide-area-box-shadow">
					<# if ( settings.tbt_total_box.length ) { #>
						<# _.each( settings.tbt_total_box, function( item ) { #>
							<div class="tbt-slide-item elementor-repeater-item-{{ item._id }}">
								<# if ( 'yes' === item.tbt_content_publish_date_switcher ) { #>
								<div class="tbt-date">{{{item['tbt_testimonials_due_date']}}}</div>
								<# } #>
								<p class="tbt-client-comment">{{{item['tbt_content_description']}}}</p>
								<h4 class="tbt-client-title">{{{item['tbt_content_name']}}}</h4>
								<# if ( 'yes' === item.tbt_content_designation_switcher ) { #>
								<span>{{{item['tbt_content_designation']}}}</span>
								<# } #>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<#
										if(0 >= item['tbt_content_star_rating_number']){
										} else if(1 == item['tbt_content_star_rating_number']){
											#>
										<i class="fas fa-star"></i>
										<#
										} else if(2 == item['tbt_content_star_rating_number']){
											#>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<#
											} else if(3 == item['tbt_content_star_rating_number']){
												#>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<#
												} else if(4 == item['tbt_content_star_rating_number']){
													#>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<#
													} else {
														#>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<#
														} 
										#>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
							</div>
						<# }); #>
					<# } #>
						</div>
						<div class="tbt-slide-indicators tbt-slide-area-box-shadow">
					<# if ( settings.tbt_total_box.length ) { #>
						<# _.each( settings.tbt_total_box, function( item ) { #>
							<div class="tbt-indicators-img elementor-repeater-item-{{ item._id }}">
								<img src="{{{item['tbt_image_profile_image']['url']}}}" alt="client img">
							</div>
						<# }); #>
					<# } #>
						</div>
					</div>
				</div>
			</div>
		<# } else if('style7' === settings['tbt_style_selection']){ #>
		<section class="tbt-testimonial-seven tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
					<# if ( settings.tbt_total_box.length ) { #>
						<# _.each( settings.tbt_total_box, function( item ) { #>
					<div class="tbt-testimonial-item elementor-repeater-item-{{ item._id }}">
						<div class="tbt-client-profile">
							<div class="tbt-client-img">
								<img src="{{{item['tbt_image_profile_image']['url']}}}" alt="client img">
							</div>
							<div class="tbt-client-bio">
								<h4 class="tbt-client-title">{{{item['tbt_content_name']}}}</h4>
								<# if ( 'yes' === item.tbt_content_designation_switcher ) { #>
								<span>{{{item['tbt_content_designation']}}}</span>
								<# } #>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<#
										if(0 >= item['tbt_content_star_rating_number']){
										} else if(1 == item['tbt_content_star_rating_number']){
											#>
										<i class="fas fa-star"></i>
										<#
										} else if(2 == item['tbt_content_star_rating_number']){
											#>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<#
											} else if(3 == item['tbt_content_star_rating_number']){
												#>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<#
												} else if(4 == item['tbt_content_star_rating_number']){
													#>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<#
													} else {
														#>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<#
														} 
										#>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
							</div>
						</div>
						<div class="tbt-testi-desc">
						<# if ( 'yes' === item.tbt_content_publish_date_switcher ) { #>
						<div class="tbt-date">{{{item['tbt_testimonials_due_date']}}}</div>
						<# } #>
						<p class="tbt-client-comment">{{{item['tbt_content_description']}}}</p>
						</div>
					</div>
						<# }); #>
					<# } #>
				</div>
			</div>
		</section>
		<# } else if('style8' === settings['tbt_style_selection']){ #>
		<section class="tbt-testimonial-eight tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
					<# if ( settings.tbt_total_box.length ) { #>
						<# _.each( settings.tbt_total_box, function( item ) { #>
					<div class="tbt-testimonial-item elementor-repeater-item-{{ item._id }}">
						<div class="tbt-client-img">
								<img src="{{{item['tbt_image_profile_image']['url']}}}" alt="client img">
						</div>
						<div class="tbt-testi-desc tbt-slide-area-box-shadow">
							<i class="tbt-quote {{{item['tbt_content_icon_right']['value']}}}"></i>
							<# if ( 'yes' === item.tbt_content_publish_date_switcher ) { #>
							<div class="tbt-date">{{{item['tbt_testimonials_due_date']}}}</div>
							<# } #>
							<p class="tbt-client-comment">{{{item['tbt_content_description']}}}</p>
								<h4 class="tbt-client-title">{{{item['tbt_content_name']}}}</h4>
								<# if ( 'yes' === item.tbt_content_designation_switcher ) { #>
								<span>{{{item['tbt_content_designation']}}}</span>
								<# } #>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<#
										if(0 >= item['tbt_content_star_rating_number']){
										} else if(1 == item['tbt_content_star_rating_number']){
											#>
										<i class="fas fa-star"></i>
										<#
										} else if(2 == item['tbt_content_star_rating_number']){
											#>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<#
											} else if(3 == item['tbt_content_star_rating_number']){
												#>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<#
												} else if(4 == item['tbt_content_star_rating_number']){
													#>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<#
													} else {
														#>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<#
														} 
										#>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
						</div>
					</div>
						<# }); #>
					<# } #>
				</div>
			</div>
		</section>
		<# } else if('style9' === settings['tbt_style_selection']){ #>
		<section class="tbt-testimonial-nine tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
					<# if ( settings.tbt_total_box.length ) { #>
						<# _.each( settings.tbt_total_box, function( item ) { #>
					<div class="tbt-testimonial-item elementor-repeater-item-{{ item._id }}">
						<div class="tbt-client-profile tbt-slide-area-box-shadow">
							<div class="tbt-client-img">
								<img src="{{{item['tbt_image_profile_image']['url']}}}" alt="client img">
							</div>
							<div class="tbt-client-bio">
								<h4 class="tbt-client-title">{{{item['tbt_content_name']}}}</h4>
								<# if ( 'yes' === item.tbt_content_designation_switcher ) { #>
								<span>{{{item['tbt_content_designation']}}}</span>
								<# } #>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<#
										if(0 >= item['tbt_content_star_rating_number']){
										} else if(1 == item['tbt_content_star_rating_number']){
											#>
										<i class="fas fa-star"></i>
										<#
										} else if(2 == item['tbt_content_star_rating_number']){
											#>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<#
											} else if(3 == item['tbt_content_star_rating_number']){
												#>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<#
												} else if(4 == item['tbt_content_star_rating_number']){
													#>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<#
													} else {
														#>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<#
														} 
										#>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
							</div>
						</div>
						<div class="tbt-testi-desc tbt-slide-area-box-shadow">
							<i class="tbt-quote {{{item['tbt_content_icon_right']['value']}}}"></i>
							<p class="tbt-client-comment">{{{item['tbt_content_description']}}}</p>
							<# if ( 'yes' === item.tbt_content_publish_date_switcher ) { #>
							<div class="tbt-date">{{{item['tbt_testimonials_due_date']}}}</div>
							<# } #>
						</div>
					</div>
						<# }); #>
					<# } #>
				</div>
			</div>
		</section>
		<# } else if('style10' === settings['tbt_style_selection']){ #>
		<section class="tbt-testimonial-ten tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
					<# if ( settings.tbt_total_box.length ) { #>
						<# _.each( settings.tbt_total_box, function( item ) { #>
					<div class="tbt-testimonial-item elementor-repeater-item-{{ item._id }}">
						<div class="tbt-client-img-shape">
							<div class="tbt-client-img">
								<img src="{{{item['tbt_image_profile_image']['url']}}}" alt="client img">
							</div>
						</div>
						<div class="tbt-testi-desc">
							<i class="tbt-quote {{{item['tbt_content_icon_left']['value']}}}"></i>
							<p class="tbt-client-comment">{{{item['tbt_content_description']}}}</p>
							<div class="tbt-rating-wrapper">
								<div class="tbt-rating tbt_testimonials_star_rating">
									<#
									if(0 >= item['tbt_content_star_rating_number']){
									} else if(1 == item['tbt_content_star_rating_number']){
										#>
									<i class="fas fa-star"></i>
									<#
									} else if(2 == item['tbt_content_star_rating_number']){
										#>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<#
										} else if(3 == item['tbt_content_star_rating_number']){
											#>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<#
											} else if(4 == item['tbt_content_star_rating_number']){
												#>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<#
												} else {
													#>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<#
													} 
									#>
								</div>
								<div class="tbt-rating-gray tbt_testimonials_star_rating">
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
								</div>
							</div>
							<div class="tbt-client-bio">
								<h4 class="tbt-client-title">{{{item['tbt_content_name']}}}</h4>
								<# if ( 'yes' === item.tbt_content_publish_date_switcher ) { #>
								<div class="tbt-date">{{{item['tbt_testimonials_due_date']}}}</div>
								<# } #>
								<# if ( 'yes' === item.tbt_content_designation_switcher ) { #>
								<span>{{{item['tbt_content_designation']}}}</span>
								<# } #>
							</div>
						</div>
					</div>
						<# }); #>
					<# } #>
				</div>
			</div>
		</section>
		<# } else if('style11' === settings['tbt_style_selection']){ #>
		<section class="tbt-testimonial-eleven tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
					<# if ( settings.tbt_total_box.length ) { #>
						<# _.each( settings.tbt_total_box, function( item ) { #>
					<div class="tbt-testimonial-item elementor-repeater-item-{{ item._id }}">
						<div class="tbt-client-profile">
							<div class="tbt-client-img">
								<img src="{{{item['tbt_image_profile_image']['url']}}}" alt="client img">
							</div>
							<div class="tbt-client-bio">
								<h4 class="tbt-client-title">{{{item['tbt_content_name']}}}</h4>
								<# if ( 'yes' === item.tbt_content_designation_switcher ) { #>
								<span>{{{item['tbt_content_designation']}}}</span>
								<# } #>
							</div>
						</div>
						<div class="tbt-testi-desc">
						<p class="tbt-client-comment">{{{item['tbt_content_description']}}}</p>
							<div class="tbt-client-review">
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<#
										if(0 >= item['tbt_content_star_rating_number']){
										} else if(1 == item['tbt_content_star_rating_number']){
											#>
										<i class="fas fa-star"></i>
										<#
										} else if(2 == item['tbt_content_star_rating_number']){
											#>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<#
											} else if(3 == item['tbt_content_star_rating_number']){
												#>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<#
												} else if(4 == item['tbt_content_star_rating_number']){
													#>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<#
													} else {
														#>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<#
														} 
										#>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
								<# if ( 'yes' === item.tbt_content_publish_date_switcher ) { #>
								<div class="tbt-date">{{{item['tbt_testimonials_due_date']}}}</div>
								<# } #>
							</div>
						</div>
					</div>
						<# }); #>
					<# } #>
				</div>
			</div>
		</section>
		<# } else if('style12' === settings['tbt_style_selection']){ #>
		<section class="tbt-testimonial-twelve tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
					<# if ( settings.tbt_total_box.length ) { #>
						<# _.each( settings.tbt_total_box, function( item ) { #>
					<div class="tbt-testimonial-item elementor-repeater-item-{{ item._id }}">
						<div class="tbt-client-img-shape">
							<div class="tbt-client-img">
								<img src="{{{item['tbt_image_profile_image']['url']}}}" alt="client img">
							</div>
						</div>
						<div class="tbt-client-profile">
								<h4 class="tbt-client-title">{{{item['tbt_content_name']}}}</h4>
								<# if ( 'yes' === item.tbt_content_designation_switcher ) { #>
								<span>{{{item['tbt_content_designation']}}}</span>
								<# } #>
								<p class="tbt-client-comment">{{{item['tbt_content_description']}}}</p>
								<# if ( 'yes' === item.tbt_content_publish_date_switcher ) { #>
								<div class="tbt-date">{{{item['tbt_testimonials_due_date']}}}</div>
								<# } #>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<#
										if(0 >= item['tbt_content_star_rating_number']){
										} else if(1 == item['tbt_content_star_rating_number']){
											#>
										<i class="fas fa-star"></i>
										<#
										} else if(2 == item['tbt_content_star_rating_number']){
											#>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<#
											} else if(3 == item['tbt_content_star_rating_number']){
												#>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<#
												} else if(4 == item['tbt_content_star_rating_number']){
													#>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<#
													} else {
														#>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<#
														} 
										#>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
						</div>
					</div>
						<# }); #>
					<# } #>
				</div>
			</div>
		</section>
		<# } else if('style13' === settings['tbt_style_selection']){ #>
		<section class="tbt-testimonial-thirteen tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
					<# if ( settings.tbt_total_box.length ) { #>
						<# _.each( settings.tbt_total_box, function( item ) { #>
					<div class="tbt-testimonial-item elementor-repeater-item-{{ item._id }}">
						<div class="tbt-testi-desc">
							<i class="tbt-quote tbt-left-icon-tbt {{{item['tbt_content_icon_left']['value']}}}"></i>
							<p class="tbt-client-comment">{{{item['tbt_content_description']}}}</p>
						</div>
						<div class="tbt-client-profile">
								<div class="tbt-client-img">
									<img src="{{{item['tbt_image_profile_image']['url']}}}" alt="client img">
								</div>
								<h4 class="tbt-client-title">{{{item['tbt_content_name']}}}</h4>
								<# if ( 'yes' === item.tbt_content_publish_date_switcher ) { #>
								<div class="tbt-date">{{{item['tbt_testimonials_due_date']}}}</div>
								<# } #>
								<# if ( 'yes' === item.tbt_content_designation_switcher ) { #>
								<span>{{{item['tbt_content_designation']}}}</span>
								<# } #>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<#
										if(0 >= item['tbt_content_star_rating_number']){
										} else if(1 == item['tbt_content_star_rating_number']){
											#>
										<i class="fas fa-star"></i>
										<#
										} else if(2 == item['tbt_content_star_rating_number']){
											#>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<#
											} else if(3 == item['tbt_content_star_rating_number']){
												#>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<#
												} else if(4 == item['tbt_content_star_rating_number']){
													#>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<#
													} else {
														#>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<#
														} 
										#>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
						</div>
					</div>
						<# }); #>
					<# } #>
				</div>
			</div>
		</section>
		<# } else if('style14' === settings['tbt_style_selection']){ #>
		<section class="tbt-testimonial-fourteen tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
					<# if ( settings.tbt_total_box.length ) { #>
						<# _.each( settings.tbt_total_box, function( item ) { #>
					<div class="tbt-testimonial-item elementor-repeater-item-{{ item._id }}">
						<div class="tbt-client-profile tbt-slide-area-box-shadow">
							<div class="tbt-client-img">
								<img src="{{{item['tbt_image_profile_image']['url']}}}" alt="client img">
							</div>
							<div class="tbt-client-bio">
								<# if ( 'yes' === item.tbt_content_publish_date_switcher ) { #>
								<div class="tbt-date">{{{item['tbt_testimonials_due_date']}}}</div>
								<# } #>
								<h4 class="tbt-client-title">{{{item['tbt_content_name']}}}</h4>
								<# if ( 'yes' === item.tbt_content_designation_switcher ) { #>
								<span>{{{item['tbt_content_designation']}}}</span>
								<# } #>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<#
										if(0 >= item['tbt_content_star_rating_number']){
										} else if(1 == item['tbt_content_star_rating_number']){
											#>
										<i class="fas fa-star"></i>
										<#
										} else if(2 == item['tbt_content_star_rating_number']){
											#>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<#
											} else if(3 == item['tbt_content_star_rating_number']){
												#>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<#
												} else if(4 == item['tbt_content_star_rating_number']){
													#>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<#
													} else {
														#>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<#
														} 
										#>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
							</div>
						</div>
						<div class="tbt-testi-desc">
						<p class="tbt-client-comment">{{{item['tbt_content_description']}}}</p>
						</div>
					</div>
						<# }); #>
					<# } #>
				</div>
			</div>
		</section>
		<# } else if('style15' === settings['tbt_style_selection']){ #>
		<section class="tbt-testimonial-fifteen tbt-background-box">
			<div class="container">
				<div class="tbt-testimonial-item-wrapper">
					<# if ( settings.tbt_total_box.length ) { #>
						<# _.each( settings.tbt_total_box, function( item ) { #>
					<div class="tbt-testimonial-item elementor-repeater-item-{{ item._id }}">
						<div class="tbt-testi-desc">
							<p class="tbt-client-comment">{{{item['tbt_content_description']}}}</p>
						</div>
						<div class="tbt-client-profile">
							<div class="tbt-client-img">
								<img src="{{{item['tbt_image_profile_image']['url']}}}" alt="client img">
							</div>
							<div class="tbt-client-bio">
								<# if ( 'yes' === item.tbt_content_publish_date_switcher ) { #>
								<div class="tbt-date">{{{item['tbt_testimonials_due_date']}}}</div>
								<# } #>
								<h4 class="tbt-client-title">{{{item['tbt_content_name']}}}</h4>
								<# if ( 'yes' === item.tbt_content_designation_switcher ) { #>
								<span>{{{item['tbt_content_designation']}}}</span>
								<# } #>
								<div class="tbt-rating-wrapper">
									<div class="tbt-rating tbt_testimonials_star_rating">
										<#
										if(0 >= item['tbt_content_star_rating_number']){
										} else if(1 == item['tbt_content_star_rating_number']){
											#>
										<i class="fas fa-star"></i>
										<#
										} else if(2 == item['tbt_content_star_rating_number']){
											#>
											<i class="fas fa-star"></i>
											<i class="fas fa-star"></i>
											<#
											} else if(3 == item['tbt_content_star_rating_number']){
												#>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<i class="fas fa-star"></i>
												<#
												} else if(4 == item['tbt_content_star_rating_number']){
													#>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<#
													} else {
														#>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<i class="fas fa-star"></i>
														<#
														} 
										#>
									</div>
									<div class="tbt-rating-gray tbt_testimonials_star_rating">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
								</div>
							</div>
						</div>
					</div>
						<# }); #>
					<# } #>
				</div>
			</div>
		</section>
		<# } #>
		<?php
	}
}
