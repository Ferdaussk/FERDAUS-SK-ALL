<?php
namespace MeetTheTeam\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class MTTMeetTheTeam extends Widget_Base {

	public function get_name() {
		return esc_html__( 'MeetTheTeam', 'meet-the-team' );
	}

	public function get_title() {
		return esc_html__( 'Meet The Team', 'elementor' );
	}

	public function get_icon() {
		return 'mtt-ua-icon eicon-image-rollover';
	}

	public function get_categories() {
		return [ 'meet-the-team-category' ];
	}

	public function get_script_depends() {
		return [ 'meet-the-team-category' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'text_content_section',
			[
				'label' => esc_html__( 'Team Content', 'meet-the-team' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'mtt_style_selection',
			[
				'label' => esc_html__( 'Team Style', 'meet-the-team' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'meet-the-team' ),
					'style2' => esc_html__( 'Style 2', 'meet-the-team' ),
					'style3' => esc_html__( 'Style 3', 'meet-the-team' ),
					'style4' => esc_html__( 'Style 4', 'meet-the-team' ),
					'style5' => esc_html__( 'Style 5', 'meet-the-team' ),
					'style6' => esc_html__( 'Style 6', 'meet-the-team' ),
					'style7' => esc_html__( 'Style 7', 'meet-the-team' ),
					'style8' => esc_html__( 'Style 8', 'meet-the-team' ),
					'style9' => esc_html__( 'Style 9', 'meet-the-team' ),
					'style10' => esc_html__( 'Style 10', 'meet-the-team' ),
					'style11' => esc_html__( 'Style 11', 'meet-the-team' ),
					'style12' => esc_html__( 'Style 12', 'meet-the-team' ),
					'style13' => esc_html__( 'Style 13', 'meet-the-team' ),
					'style14' => esc_html__( 'Style 14', 'meet-the-team' ),
					'style15' => esc_html__( 'Style 15', 'meet-the-team' ),
					'style16' => esc_html__( 'Style 16', 'meet-the-team' ),
					'style17' => esc_html__( 'Style 17', 'meet-the-team' ),
					'style18' => esc_html__( 'Style 18', 'meet-the-team' ),
					'style19' => esc_html__( 'Style 19', 'meet-the-team' ),
					'style20' => esc_html__( 'Style 20', 'meet-the-team' ),
					'style21' => esc_html__( 'Style 21', 'meet-the-team' ),
					'style22' => esc_html__( 'Style 22', 'meet-the-team' ),
					'style23' => esc_html__( 'Style 23', 'meet-the-team' ),
					'style24' => esc_html__( 'Style 24', 'meet-the-team' ),
					'style25' => esc_html__( 'Style 25', 'meet-the-team' ),
					'style26' => esc_html__( 'Style 26', 'meet-the-team' ),
					'style27' => esc_html__( 'Style 27', 'meet-the-team' ),
					'style28' => esc_html__( 'Style 28', 'meet-the-team' ),
					'style29' => esc_html__( 'Style 29', 'meet-the-team' ),
					'style30' => esc_html__( 'Style 30', 'meet-the-team' ),
					'style31' => esc_html__( 'Style 31', 'meet-the-team' ),
				],
			]
		);
		$this->add_control(
			'mtt_team_box_align',
			[
				'label' => esc_html__( 'Alignment', 'meet-the-team' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'left' => esc_html__( 'Left', 'meet-the-team' ),
					'center'  => esc_html__( 'Center', 'meet-the-team' ),
					'right' => esc_html__( 'Right', 'meet-the-team' ),
				],
			]
		);

		$this->add_control(
			'mtt_meet_the_team_column',
			[
				'label' => esc_html__( 'Column', 'meet-the-team' ),
				'type' => Controls_Manager::SELECT,
				'default' => '3',
				'options' => [
					'4' => esc_html__( '4', 'meet-the-team' ),
					'3' => esc_html__( '3', 'meet-the-team' ),
					'2' => esc_html__( '2', 'meet-the-team' ),
					'1' => esc_html__( '1', 'meet-the-team' ),
				],
			]
		);
		$this->add_control(
			'mtt_meet_the_team_content_width',
			[
				'label' => esc_html__( 'Content Width', 'meet-the-team' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'full_width',
				'options' => [
					'boxed' => esc_html__( 'Boxed', 'meet-the-team' ),
					'full_width' => esc_html__( 'Full Width', 'meet-the-team' ),
				],
			]
		);
		$this->add_responsive_control(
			'mtt_team__the_social_icon_size',
			[
				'label' => esc_html__( 'Social Icon Size', 'meet-the-team' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'laptop', 'tablet', 'tablet_extra', 'mobile', 'mobile_extra' ],
				'selectors' => [
					'{{WRAPPER}} .mtt_social_media_one' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .mtt_social_media_two' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .mtt_social_media_three' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .mtt_social_media_four' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		
		$this->start_controls_section(
			'mtt_flipflop_step_content_box_section',
			[
				'label' => esc_html__( 'Team Boxes', 'meet-the-team' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'mtt_box_name', [
				'label' => esc_html__( 'Name', 'meet-the-team' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'JHON DOE' , 'meet-the-team' ),
				'dynamic' => [
					'active' => true,
				],
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'mtt_box_name_color',
			[
				'label' => esc_html__( 'Text Color', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-title' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'mtt_box_profile_title_background_color',
			[
				'label' => esc_html__( 'Title Background', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-content .mtt-title' => 'background-color: {{VALUE}}',
				],
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'mtt_title_shadow',
				'label' => esc_html__( 'Title Shadow', 'meet-the-team' ),
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-content .mtt-title',
				'default' => [
					'color' => 'transparent',
				]
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'mtt_box_name_typography',
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .mtt-title',
			]
		);
		
		$repeater->add_control(
			'mtt_team_b',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'mtt_box_designation', [
				'label' => esc_html__( 'Designation', 'meet-the-team' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Web Developer' , 'meet-the-team' ),
				'dynamic' => [
					'active' => true,
				],
				'show_label' => false,
			]
		);
		$repeater->add_control(
			'mtt_box_designation_color',
			[
				'label' => esc_html__( 'Text Color', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-post' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'mtt_box_profile_des_background_color',
			[
				'label' => esc_html__( 'Designation Background', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-content .mtt-post' => 'background-color: {{VALUE}}',
				],
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'mtt_designation_shadow',
				'label' => esc_html__( 'Designaion Shadow', 'meet-the-team' ),
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-content .mtt-post',
				'default' => [
					'color' => 'transparent',
				]
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'mtt_box_designation_typography',
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .mtt-post',
			]
		);

		$repeater->add_control(
			'mtt_team_c',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'mtt_team_profile_image',
			[
				'label' => esc_html__( 'Choose Image', 'meet-the-team' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => plugin_dir_url(__DIR__) .'assets/public/img/bwd-placeholder.jpg',
				],
			]
		);
		$repeater->add_control(
			'mtt_box_profile_background_color',
			[
				'label' => esc_html__( 'Profile Background', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt_team_profile_background, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-pic::before, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-26-team .mtt-team-content::before' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-portfolio-team .mtt-pic::before' => 'background: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-section::before,{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-28-team:hover' => 'background: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-section' => 'border: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-thumble::after,{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-29-team::before' => 'background: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-portfolio:after' => 'background: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-our-box:hover, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-30-team, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-31-team' => 'background: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-16-box::before' => 'background: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-pic:after' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-20-team .mtt-pic' => 'border: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-23-team' => 'background: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-22-team, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-21-team .mtt-pic::before' => 'background: {{VALUE}}',
				],
			]
		);

		$repeater->add_control(
			'mtt_team_d',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'mtt_social_icon_one_switcher',
			[
				'label' => esc_html__( 'Hide This', 'meet-the-team' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'meet-the-team' ),
				'label_off' => esc_html__( 'Hide', 'meet-the-team' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$repeater->add_control(
			'mtt_social_icon_one',
			[
				'label' => esc_html__( 'Icon', 'meet-the-team' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fab fa-facebook-f',
					'library' => 'solid',
				],
				'condition' => [
					'mtt_social_icon_one_switcher' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'mtt_team_icon_type_one',
			[
				'label' => esc_html__( 'Color Type', 'meet-the-team' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'custom',
				'options' => [
					'official' => esc_html__( 'Official', 'meet-the-team' ),
					'custom'  => esc_html__( 'Custom', 'meet-the-team' ),
				],
				'condition' => [
					'mtt_social_icon_one_switcher' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_one_color_official',
			[
				'label' => esc_html__( 'Color', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#3b5998',
				'condition' => [
					'mtt_team_icon_type_one' => 'official',
					'mtt_social_icon_one_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-social .mtt_social_media_one' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_one_link_official',
			[
				'label' => esc_html__( 'Link', 'meet-the-team' ),
				'type' => Controls_Manager::URL,
				'condition' => [
					'mtt_team_icon_type_one' => 'official',
					'mtt_social_icon_one_switcher' => 'yes',
				],
				'placeholder' => esc_html__( 'your-link.com', 'meet-the-team' ),
				'default' => [
					'url' => 'www.facebook.com',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_one_color',
			[
				'label' => esc_html__( 'Color', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'mtt_team_icon_type_one' => 'custom',
					'mtt_social_icon_one_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-social .mtt_social_media_one' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_one_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'mtt_team_icon_type_one' => 'custom',
					'mtt_social_icon_one_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-social .mtt_social_media_one:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_one_link',
			[
				'label' => esc_html__( 'Link', 'meet-the-team' ),
				'type' => Controls_Manager::URL,
				'condition' => [
					'mtt_team_icon_type_one' => 'custom',
					'mtt_social_icon_one_switcher' => 'yes',
				],
				'placeholder' => esc_html__( 'your-link.com', 'meet-the-team' ),
				'default' => [
					'url' => 'www.facebook.com',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
			]
		);

		$repeater->add_control(
			'mtt_team_e',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'mtt_social_icon_two_switcher',
			[
				'label' => esc_html__( 'Hide This', 'meet-the-team' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'meet-the-team' ),
				'label_off' => esc_html__( 'Hide', 'meet-the-team' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$repeater->add_control(
			'mtt_social_icon_two',
			[
				'label' => esc_html__( 'Icon', 'meet-the-team' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fab fa-twitter',
					'library' => 'solid',
				],
				'condition' => [
					'mtt_social_icon_two_switcher' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'mtt_team_icon_type_two',
			[
				'label' => esc_html__( 'Color Type', 'meet-the-team' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'custom',
				'options' => [
					'official' => esc_html__( 'Official', 'meet-the-team' ),
					'custom'  => esc_html__( 'Custom', 'meet-the-team' ),
				],
				'condition' => [
					'mtt_social_icon_two_switcher' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_two_color_official',
			[
				'label' => esc_html__( 'Color', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#00acee',
				'condition' => [
					'mtt_team_icon_type_two' => 'official',
					'mtt_social_icon_two_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-social .mtt_social_media_two' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_two_link_official',
			[
				'label' => esc_html__( 'Link', 'meet-the-team' ),
				'type' => Controls_Manager::URL,
				'condition' => [
					'mtt_team_icon_type_two' => 'official',
					'mtt_social_icon_two_switcher' => 'yes',
				],
				'placeholder' => esc_html__( 'your-link.com', 'meet-the-team' ),
				'default' => [
					'url' => 'www.twitter.com',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_two_color',
			[
				'label' => esc_html__( 'Color', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'mtt_team_icon_type_two' => 'custom',
					'mtt_social_icon_two_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-social .mtt_social_media_two' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_two_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'mtt_team_icon_type_two' => 'custom',
					'mtt_social_icon_two_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-social .mtt_social_media_two:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_two_link',
			[
				'label' => esc_html__( 'Link', 'meet-the-team' ),
				'type' => Controls_Manager::URL,
				'condition' => [
					'mtt_team_icon_type_two' => 'custom',
					'mtt_social_icon_two_switcher' => 'yes',
				],
				'placeholder' => esc_html__( 'your-link.com', 'meet-the-team' ),
				'default' => [
					'url' => 'www.twitter.com',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
			]
		);

		$repeater->add_control(
			'mtt_team_f',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'mtt_social_icon_three_switcher',
			[
				'label' => esc_html__( 'Hide This', 'meet-the-team' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'meet-the-team' ),
				'label_off' => esc_html__( 'Hide', 'meet-the-team' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$repeater->add_control(
			'mtt_social_icon_three',
			[
				'label' => esc_html__( 'Icon', 'meet-the-team' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fab fa-linkedin-in',
					'library' => 'solid',
				],
				'condition' => [
					'mtt_social_icon_three_switcher' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'mtt_team_icon_type_three',
			[
				'label' => esc_html__( 'Color Type', 'meet-the-team' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'custom',
				'options' => [
					'official' => esc_html__( 'Official', 'meet-the-team' ),
					'custom'  => esc_html__( 'Custom', 'meet-the-team' ),
				],
				'condition' => [
					'mtt_social_icon_three_switcher' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_three_color_official',
			[
				'label' => esc_html__( 'Color', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#0077b5',
				'condition' => [
					'mtt_team_icon_type_three' => 'official',
					'mtt_social_icon_three_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-social .mtt_social_media_three' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_three_link_official',
			[
				'label' => esc_html__( 'Link', 'meet-the-team' ),
				'type' => Controls_Manager::URL,
				'condition' => [
					'mtt_team_icon_type_three' => 'official',
					'mtt_social_icon_three_switcher' => 'yes',
				],
				'placeholder' => esc_html__( 'your-link.com', 'meet-the-team' ),
				'default' => [
					'url' => 'www.linkedin.com',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_three_color',
			[
				'label' => esc_html__( 'Color', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'mtt_team_icon_type_three' => 'custom',
					'mtt_social_icon_three_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-social .mtt_social_media_three' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_three_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'mtt_team_icon_type_three' => 'custom',
					'mtt_social_icon_three_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-social .mtt_social_media_three:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_three_link',
			[
				'label' => esc_html__( 'Link', 'meet-the-team' ),
				'type' => Controls_Manager::URL,
				'condition' => [
					'mtt_team_icon_type_three' => 'custom',
					'mtt_social_icon_three_switcher' => 'yes',
				],
				'placeholder' => esc_html__( 'your-link.com', 'meet-the-team' ),
				'default' => [
					'url' => 'www.linkedin.com',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
			]
		);

		$repeater->add_control(
			'mtt_team_g',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'mtt_social_icon_four_switcher',
			[
				'label' => esc_html__( 'Hide This', 'meet-the-team' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'meet-the-team' ),
				'label_off' => esc_html__( 'Hide', 'meet-the-team' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$repeater->add_control(
			'mtt_social_icon_four',
			[
				'label' => esc_html__( 'Icon', 'meet-the-team' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fab fa-instagram',
					'library' => 'solid',
				],
				'condition' => [
					'mtt_social_icon_four_switcher' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'mtt_team_icon_type_four',
			[
				'label' => esc_html__( 'Color Type', 'meet-the-team' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'custom',
				'options' => [
					'official' => esc_html__( 'Official', 'meet-the-team' ),
					'custom'  => esc_html__( 'Custom', 'meet-the-team' ),
				],
				'condition' => [
					'mtt_social_icon_four_switcher' => 'yes',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_four_color_official',
			[
				'label' => esc_html__( 'Color', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'default' => 'red',
				'condition' => [
					'mtt_team_icon_type_four' => 'official',
					'mtt_social_icon_four_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-social .mtt_social_media_four' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_four_link_official',
			[
				'label' => esc_html__( 'Link', 'meet-the-team' ),
				'type' => Controls_Manager::URL,
				'condition' => [
					'mtt_team_icon_type_four' => 'official',
					'mtt_social_icon_four_switcher' => 'yes',
				],
				'placeholder' => esc_html__( 'your-link.com', 'meet-the-team' ),
				'default' => [
					'url' => 'www.instagram.com',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_four_color',
			[
				'label' => esc_html__( 'Color', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'mtt_team_icon_type_four' => 'custom',
					'mtt_social_icon_four_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-social .mtt_social_media_four' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_four_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'mtt_team_icon_type_four' => 'custom',
					'mtt_social_icon_four_switcher' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-social .mtt_social_media_four:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$repeater->add_control(
			'mtt_social_icon_four_link',
			[
				'label' => esc_html__( 'Link', 'meet-the-team' ),
				'type' => Controls_Manager::URL,
				'condition' => [
					'mtt_team_icon_type_four' => 'custom',
					'mtt_social_icon_four_switcher' => 'yes',
				],
				'placeholder' => esc_html__( 'your-link.com', 'meet-the-team' ),
				'default' => [
					'url' => 'www.instagram.com',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
			]
		);

		$repeater->add_control(
			'mtt_team_h',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'mtt_box_icon_background_color',
			[
				'label' => esc_html__( 'Icon Background', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-social .mtt-social-icon-default, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-social-icon-default-aftr::after' => 'background: {{VALUE}}'
				],
			]
		);
		$repeater->add_control(
			'mtt_box_icon_hover_background_color',
			[
				'label' => esc_html__( 'Hover Background', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-social-icon-default-aftr:hover::after, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-social-icon-default:hover' => 'background: {{VALUE}}'
				],
			]
		);

		$repeater->add_control(
			'mtt_team_hhh',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$repeater->add_control(
			'mtt_icon_bg_shape_color',
			[
				'label' => esc_html__( 'Shape Color', 'meet-the-team' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt_team_shape, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-team .mtt-pic::before, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-26-team .mtt-team-content' => 'background: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-portfolio-team .mtt-pic::after, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-27-team .mtt-team-content .mtt-title::before, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-27-team .mtt-team-content .mtt-title::before' => 'background: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-portfolio::before, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-28-team::before' => 'background: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-our-box-content::after' => 'background: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-our-box::before, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-29-team .mtt-team-content .mtt-inner-content' => 'background: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-15-box:before' => 'background: {{VALUE}}',
				],
			]
		);
		$repeater->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'mtt_team_box_background',
				'label' => esc_html__( 'Background', 'meet-the-team' ),
				'types' => [ 'gradient' ],
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .mtt-six-number-bg, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-total-team-box .mtt-social, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-19-team::after, {{WRAPPER}} .mtt-team-style-19-team::before, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-25-team, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-pic:after, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-27-team .mtt-team-content, {{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-27-team .mtt-team-content:before,  {{WRAPPER}} {{CURRENT_ITEM}} .mtt-team-style-27-team .mtt-team-content:after',
			]
		);

		$this->add_control(
			'mtt_box',
			[
				'label' => esc_html__( 'Meet The Team', 'meet-the-team' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'mtt_box_name' => esc_html__( 'Jhon Doe', 'meet-the-team' ),
					],
					[
						'mtt_box_name' => esc_html__( 'Smith Jhon', 'meet-the-team' ),
					],
					[
						'mtt_box_name' => esc_html__( 'Robin Smith', 'meet-the-team' ),
					],
					[
						'mtt_box_name' => esc_html__( 'Json Doe', 'meet-the-team' ),
					],
				],
				'title_field' => `{{{ mtt_box_name }}}`,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'mtt_team_style_section',
			[
				'label' => esc_html__( 'Team Style', 'meet-the-team' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'mtt_team_box_background',
				'label' => esc_html__( 'Background', 'meet-the-team' ),
				'types' => ['gradient' ],
				'selector' => '{{WRAPPER}} .mtt-team, {{WRAPPER}} .mtt-team-style-23-area, {{WRAPPER}} .mtt-team-style-22-area, {{WRAPPER}} .mtt-team-style-21-team .mtt-team-content::before,
				{{WRAPPER}} .mtt-team-style-20-team .mtt-team-content',
			]
		);
		$this->add_responsive_control(
            'mtt_team_the_box_margin',
            [
                'label' => esc_html__('Margin', 'meet-the-team'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .mtt-team' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
            'mtt_team_the_box_padding',
            [
                'label' => esc_html__('Padding', 'meet-the-team'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .mtt-team' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
			'mtt_team_the_box_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'meet-the-team' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'laptop', 'tablet', 'tablet_extra', 'mobile', 'mobile_extra' ],
				'selectors' => [
					'{{WRAPPER}} .mtt-total-team-box' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		$mtt_column = $settings['mtt_meet_the_team_column'];
		if('1' === $mtt_column){
			$mtt_lg_dev_clmn = 'col-lg-12';
			$mtt_xl_dev_clmn = 'col-xl-12';
		} elseif('2' === $mtt_column){
			$mtt_lg_dev_clmn = 'col-lg-6';
			$mtt_xl_dev_clmn = 'col-xl-6';
		} elseif('3' === $mtt_column){
			$mtt_lg_dev_clmn = 'col-lg-4';
			$mtt_xl_dev_clmn = 'col-xl-4';
		} elseif('4' === $mtt_column){
			$mtt_lg_dev_clmn = 'col-lg-3';
			$mtt_xl_dev_clmn = 'col-xl-3';
		}

		$mtt_content_width = $settings['mtt_meet_the_team_content_width'];
		if('full_width' === $mtt_content_width){
			$mtt_content_c_f = 'container-fluid';
		} elseif('boxed' === $mtt_content_width){
			$mtt_content_c_f = 'container';
		}
		// Social Link
		if ( ! empty( $settings['mtt_social_icon_one_link']['url'] ) ) {
			$this->add_link_attributes( 'mtt_social_icon_one_link', $settings['mtt_social_icon_one_link'] );
		}
			if('style1' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
						echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
							<div class="mtt-team mtt-total-team-box">
								<div class="mtt-pic mtt_team_profile_background mtt-style-1">
								<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
								</div>
								<div class="mtt-team-content">
									<div class="mtt-title mtt-titleee"><?php echo esc_html($item['mtt_box_name']); ?></div>
									<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
								</div>
								<div class="mtt-social">
									<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
									<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
									<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
									<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
			} elseif('style2' === $settings['mtt_style_selection']){
			?>
			<div class="mtt-our-team-area">
				<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
						echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
							<div class="mtt-our-team-box mtt-total-team-box">
								<div class="mtt-our-team-item">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-team-content mtt_team_profile_background">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
										<div class="mtt-social">
											<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
			<?php
			} elseif('style3' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-portfolio-team-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-portfolio-team mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
										<div  class="mtt-social">
											<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default-aftr" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default-aftr" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default-aftr" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default-aftr" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
										</div >
									</div>
									<div class="mtt-team-content">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
			<?php
			} elseif('style4' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-single-team-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-single-team mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
										<div class="mtt-social mtt_team_profile_background">
											<div class="mtt-ul">
												<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
												<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
												<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
											</div>
										</div>
									</div>
									<div class="mtt-team-content mtt_team_shape">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
				<?php
			} elseif('style5' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-section-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
							<div class="mtt-team-section mtt-total-team-box">
								<div class="mtt-pic">
									<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
								</div>
									<div class="mtt-team-content mtt_team_shape">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
										<div class="mtt-social">
											<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
										</div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
				<?php
			} elseif('style6' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-iteam-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-iteam mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-social mtt_team_shape">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
									</div>
									<div class="mtt-team-content mtt_team_profile_background mtt-six-number-bg">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
				<?php
			} elseif('style7' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-card-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-cards mtt_team_profile_background mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-team-content">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
										<div class="mtt-social">
											<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
										</div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
				<?php
			} elseif('style8' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-box-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-box-item mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-team-content mtt_team_shape">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
									<div class="mtt-social mtt_team_profile_background">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
				<?php
			} elseif('style9' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-thumble-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-thumble mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-social">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
									</div>
									<div class="mtt-team-content mtt_team_shape">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
				<?php
			} elseif('style10' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-portfolio-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-portfolio mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-team-content">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
										<div class="mtt-social">
											<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
										</div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
				<?php
			} elseif('style11' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-our-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-our-box mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-team-our-box-content">
										<div class="mtt-team-content">
											<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
											<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
										</div>
										<div class="mtt-social">
											<div class="mtt-li">
												<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
												<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
												<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
											</div>
										</div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
				<?php
			} elseif('style12' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-style-12-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-box mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-team-content mtt_team_shape">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
									<div class="mtt-social">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
				<?php
			} elseif('style13' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-style-13-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-13-box mtt_team_profile_background mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-team-content mtt_team_shape">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
									<div class="mtt-social">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
				<?php
			} elseif('style14' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-style-14-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-14-box mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-team-content mtt_team_shape">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
										<div class="mtt-social">
											<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
										</div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
				<?php
			} elseif('style15' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-style-15-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-15-box mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-team-content">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
										<div class="mtt-social">
											<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
										</div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
				<?php
			} elseif('style16' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-style-16-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
							<div class="mtt-team-style-16-box mtt-total-team-box">
								<div class="mtt-pic">
									<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
								</div>
									<div class="mtt-team-content mtt_team_shape">
										<div class="mtt-social">
											<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default-aftr" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default-aftr" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default-aftr" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default-aftr" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
										</div>
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
				<?php
			} elseif('style17' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-style-17-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-17-box mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-team-content">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
										<div class="mtt-social">
											<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
										</div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
				<?php
			} elseif('style18' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-style-18-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-18-team mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
										<div class="mtt-social">
											<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
										</div>
									</div>
									<div class="mtt-team-content mtt_team_shape">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
			<?php
			} elseif('style19' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-style-19-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-19-team mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-team-content">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
										<div class="mtt-social">
											<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
											<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
										</div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
			<?php
			} elseif('style20' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-style-20-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-20-team mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-social">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
									</div>
									<div class="mtt-team-content">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
			<?php
			} elseif('style21' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-style-21-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-21-team mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-social">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
									</div>
									<div class="mtt-team-content">
										<div class="mtt-info">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
										</div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
			<?php
			} elseif('style22' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-style-22-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-22-team mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-team-content">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
									<div class="mtt-social">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
			<?php
			} elseif('style23' === $settings['mtt_style_selection']){
				?>
				<div class="mtt-team-style-23-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-23-team mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-team-content">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
									<div class="mtt-social">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
			<?php
			} elseif('style24' === $settings['mtt_style_selection']){
			?>
				<div class="mtt-team-style-24-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-24-team mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-team-content">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
										<div class="mtt-social">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
										</div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
			<?php
			} elseif('style25' === $settings['mtt_style_selection']){
			?>
				<div class="mtt-team-style-25-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-25-team mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-social">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
									</div>
									<div class="mtt-team-content">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
			<?php
			} elseif('style26' === $settings['mtt_style_selection']){
			?>
				<div class="mtt-team-style-26-area pb-100">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-26-team mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
										<div class="mtt-social">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
										</div>
									</div>
									<div class="mtt-team-content">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
			<?php
			} elseif('style27' === $settings['mtt_style_selection']){
			?>
				<div class="mtt-team-style-27-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-27-team mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
										<div class="bwd-img-layer"></div>
									</div>
									<div class="mtt-team-content">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
										<div class="mtt-social">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
										</div>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
			<?php
			} elseif('style28' === $settings['mtt_style_selection']){
			?>
				<div class="mtt-team-style-28-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-28-team mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
										<div class="bwd-img-layer"></div>
									</div>
									<div class="mtt-team-content">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
									<div class="mtt-social">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
			<?php
			} elseif('style29' === $settings['mtt_style_selection']){
			?>
				<div class="mtt-team-style-29-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-29-team mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
										<div class="bwd-img-layer"></div>
									</div>
									<div class="mtt-team-content">
										<div class="mtt-inner-content">
											<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
											<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
										</div>
									</div>
									<div class="mtt-social">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
			<?php
			} elseif('style30' === $settings['mtt_style_selection']){
			?>
				<div class="mtt-team-style-30-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-30-team mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-team-content">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
									<div class="mtt-social">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
			<?php
			} elseif('style31' === $settings['mtt_style_selection']){
			?>
				<div class="mtt-team-style-31-area">
					<div class="<?php echo $mtt_content_c_f; ?>">
					<?php
					if('left' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-start">';
					} elseif('center' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-center">';
					} elseif('right' === $settings['mtt_team_box_align']){
						echo '<div class="row justify-content-end">';
					}
					?>
						<?php
						if ( $settings['mtt_box'] ) {
							foreach (  $settings['mtt_box'] as $item ) {
							echo '<div class="'. $mtt_xl_dev_clmn .' '. $mtt_lg_dev_clmn .' col-sm-6 elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
								<div class="mtt-team-style-31-team mtt-total-team-box">
									<div class="mtt-pic">
										<img src="<?php echo esc_url($item['mtt_team_profile_image']['url']); ?>" alt="bestwpdeveloper">
									</div>
									<div class="mtt-team-content">
										<div class="mtt-title"><?php echo esc_html($item['mtt_box_name']); ?></div>
										<div class="mtt-post"><?php echo esc_html($item['mtt_box_designation']); ?></div>
									</div>
									<div class="mtt-social">
										<?php if('yes' === $item['mtt_social_icon_one_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_one_link']['url']); ?>"><i class="mtt_social_media_one <?php echo esc_attr( $item['mtt_social_icon_one']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_two_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_two_link']['url']); ?>"><i class="mtt_social_media_two <?php echo esc_attr( $item['mtt_social_icon_two']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_three_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_three_link']['url']); ?>"><i class="mtt_social_media_three <?php echo esc_attr( $item['mtt_social_icon_three']['value'] ); ?>"></i></a> <?php } ?>
										<?php if('yes' === $item['mtt_social_icon_four_switcher']){ ?><a class="mtt-social-icon-default" href="<?php echo esc_url($item['mtt_social_icon_four_link']['url']); ?>"><i class="mtt_social_media_four <?php echo esc_attr( $item['mtt_social_icon_four']['value'] ); ?>"></i></a> <?php } ?>
									</div>
								</div>
							</div>
						<?php
							}
						}
						?>
						</div>
					</div>
				</div>
			<?php
		}
	}
}
