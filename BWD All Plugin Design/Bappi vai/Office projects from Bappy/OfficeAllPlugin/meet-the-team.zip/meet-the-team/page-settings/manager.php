<?php
namespace MeetTheTeam\PageSettings;

use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\PageBase;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Page_Settings {

	const PANEL_TAB = 'new-tab';

	public function __construct() {
		add_action( 'elementor/init', [ $this, 'mtt_team_add_panel_tab' ] );
		add_action( 'elementor/documents/register_controls', [ $this, 'mtt_team_register_document_controls' ] );
	}

	public function mtt_team_add_panel_tab() {
		Controls_Manager::add_tab( self::PANEL_TAB, esc_html__( 'New Team', 'meet-the-team' ) );
	}

	public function mtt_team_register_document_controls( $document ) {
		if ( ! $document instanceof PageBase || ! $document::get_property( 'has_elements' ) ) {
			return;
		}

		$document->start_controls_section(
			'mtt_team_new_section',
			[
				'label' => esc_html__( 'Settings', 'meet-the-team' ),
				'tab' => self::PANEL_TAB,
			]
		);

		$document->add_control(
			'mtt_team_text',
			[
				'label' => esc_html__( 'Title', 'meet-the-team' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Title', 'meet-the-team' ),
			]
		);

		$document->end_controls_section();
	}
}
