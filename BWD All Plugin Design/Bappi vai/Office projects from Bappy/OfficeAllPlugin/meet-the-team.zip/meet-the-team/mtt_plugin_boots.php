<?php
namespace MeetTheTeam;

use MeetTheTeam\PageSettings\Page_Settings;
define( "TEST_ASFSK_ASSETS_PUBLIC_DIR_FILE", plugin_dir_url( __FILE__ ) . "assets/public" );
define( "TEST_ASFSK_ASSETS_ADMIN_DIR_FILE", plugin_dir_url( __FILE__ ) . "assets/admin" );
class MeetTheTeam {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public function mtt_admin_editor_scripts() {
		add_filter( 'script_loader_tag', [ $this, 'mtt_admin_editor_scripts_as_a_module' ], 10, 2 );
	}

	public function mtt_admin_editor_scripts_as_a_module( $tag, $handle ) {
		if ( 'mtt_meet_the_team_editor' === $handle ) {
			$tag = str_replace( '<script', '<script type="module"', $tag );
		}

		return $tag;
	}

	private function include_widgets_files() {
		require_once( __DIR__ . '/widgets/team-mtt.php' );
		require_once( __DIR__ . '/widgets/team-mtt-carousel.php' );
	}

	public function mtt_register_widgets() {
		// Its is now safe to include Widgets files
		$this->include_widgets_files();

		// Register WidgetsF
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\MTTMeetTheTeam() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\MTTMeetTheTeamCarousel() );
	}

	private function add_page_settings_controls() {
		require_once( __DIR__ . '/page-settings/manager.php' );
		new Page_Settings();
	}

	// Register Category
	function mtt_add_elementor_widget_categories( $elements_manager ) {

		$elements_manager->add_category(
			'meet-the-team-category',
			[
				'title' => esc_html__( 'Meet The Team', 'meet-the-team' ),
				'icon' => 'eicon-person',
			]
		);
	}
	public function mtt_all_assets_for_the_public(){
		wp_enqueue_script( 'mtt_the_js_jquery', plugin_dir_url( __FILE__ ) . 'assets/public/js/jquery-3.6.0.min.js', array('jquery'), '1.3', true );
		wp_enqueue_script( 'mtt_the_js_slick', plugin_dir_url( __FILE__ ) . 'assets/public/js/slick.min.js', array('jquery'), '1.3', true );
		wp_enqueue_script( 'mtt_the_js_image_load', plugin_dir_url( __FILE__ ) . 'assets/public/js/imagesloaded.pkgd.min.js', array('jquery'), '1.3', true );
		wp_enqueue_script( 'mtt_the_js_isotop', plugin_dir_url( __FILE__ ) . 'assets/public/js/isotope.pkgd.min.js', array('jquery'), '1.3', true );
		wp_enqueue_script( 'mtt_the_js_snake', plugin_dir_url( __FILE__ ) . 'assets/public/js/snake.js', array('jquery'), '1.3', true );
		wp_enqueue_script( 'mtt_the_js_min', plugin_dir_url( __FILE__ ) . 'assets/public/js/min.js', array('jquery'), '1.3', true );
		$all_css_js_file = array(
            'mtt_team_plugin_bootstrap_css' => array('mtt_path_define'=>TEST_ASFSK_ASSETS_PUBLIC_DIR_FILE . '/css/plugins/bootstrap/css/bootstrap.min.css'),
            'mtt_team_plugin_main_css' => array('mtt_path_define'=>TEST_ASFSK_ASSETS_PUBLIC_DIR_FILE . '/css/mtt-team-main.css'),
            'mtt_team_plugin_fontawesome_css' => array('mtt_path_define'=>TEST_ASFSK_ASSETS_PUBLIC_DIR_FILE . '/css/all.min.css'),
            'mtt_team_plugin_slick_css' => array('mtt_path_define'=>TEST_ASFSK_ASSETS_PUBLIC_DIR_FILE . '/css/slick/css/slick.css'),
        );
        foreach($all_css_js_file as $handle => $fileinfo){
            wp_enqueue_style( $handle, $fileinfo['mtt_path_define'], null, '1.3', 'all');
        }
	}
	public function mtt_all_assets_for_elementor_editor_admin(){
		$all_css_js_file = array(
            'mtt_team_admin_main_css' => array('mtt_path_admin_define'=>TEST_ASFSK_ASSETS_ADMIN_DIR_FILE . '/icon.css'),
        );
        foreach($all_css_js_file as $handle => $fileinfo){
            wp_enqueue_style( $handle, $fileinfo['mtt_path_admin_define'], null, '1.3', 'all');
        }
	}

	function mtt_team_register_required_plugins() {
		$plugins = array(
			array(
				'name'        => esc_html__('Elementor', 'meet-the-team'),
				'slug'        => 'elementor',
				'is_callable' => 'wpseo_init',
			),
	
		);

		$config = array(
			'id'           => 'meet_the_team',
			'default_path' => '',
			'menu'         => 'tgmpa-install-plugins',
			'parent_slug'  => 'plugins.php',
			'capability'   => 'manage_options',
			'has_notices'  => true,
			'dismissable'  => true,
			'dismiss_msg'  => '',
			'is_automatic' => false,
			'message'      => '',
		);
	
		tgmpa( $plugins, $config );
	}
	
	public function __construct() {
		// For tgm plugin activation
		add_action( 'tgmpa_register', [$this, 'mtt_team_register_required_plugins'] );

		// For public assets
		add_action('wp_enqueue_scripts', [$this, 'mtt_all_assets_for_the_public']);

		// For Elementor Editor
		add_action('elementor/editor/before_enqueue_scripts', [$this, 'mtt_all_assets_for_elementor_editor_admin']);
		
		// Register Category
		add_action( 'elementor/elements/categories_registered', [ $this, 'mtt_add_elementor_widget_categories' ] );

		// Register widgets
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'mtt_register_widgets' ] );

		// Register editor scripts
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'mtt_admin_editor_scripts' ] );
		
		$this->add_page_settings_controls();
	}
}

// Instantiate Plugin Class
MeetTheTeam::instance();