<?php
namespace CreativeBundleList;

use CreativeBundleList\PageSettings\Page_Settings;
define( "BWDBL_ASFSK_ASSETS_PUBLIC_DIR_FILE", plugin_dir_url( __FILE__ ) . "assets/public" );
define( "BWDBL_ASFSK_ASSETS_ADMIN_DIR_FILE", plugin_dir_url( __FILE__ ) . "assets/admin" );
class ClassBWDBLList {

	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public function bwdbl_admin_editor_scripts() {
		add_filter( 'script_loader_tag', [ $this, 'bwdbl_admin_editor_scripts_as_a_module' ], 10, 2 );
	}

	public function bwdbl_admin_editor_scripts_as_a_module( $tag, $handle ) {
		if ( 'bwdbl_the_list_editor' === $handle ) {
			$tag = str_replace( '<script', '<script type="module"', $tag );
		}

		return $tag;
	}

	private function include_widgets_files() {
		require_once( __DIR__ . '/widgets/bwdbl-list.php' );
	}

	public function bwdbl_register_widgets() {
		// Its is now safe to include Widgets files
		$this->include_widgets_files();

		// Register Widgets
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\bwdblBundleList() );
	}

	private function add_page_settings_controls() {
		require_once( __DIR__ . '/page-settings/super-list-manager.php' );
		new Page_Settings();
	}

	// Register Category
	function bwdbl_add_elementor_widget_categories( $elements_manager ) {

		$elements_manager->add_category(
			'bwdbl-bundle-list-category',
			[
				'title' => esc_html__( 'BWD Bundle List', 'bwd-bundle-list' ),
				'icon' => 'eicon-person',
			]
		);
	}
	public function bwdbl_all_assets_for_the_public(){
		$all_css_js_file = array(
            'bwdbl_budle_list_style_css' => array('bwdbl_path_define'=>BWDBL_ASFSK_ASSETS_PUBLIC_DIR_FILE . '/css/style.css'),
            'bwdbl_bundle_list_all_main_css' => array('bwdbl_path_define'=>BWDBL_ASFSK_ASSETS_PUBLIC_DIR_FILE . '/css/all.min.css'),
            'bwdbl_bundle_list_bootstrap_css' => array('bwdbl_path_define'=>BWDBL_ASFSK_ASSETS_PUBLIC_DIR_FILE . '/css/bootstrap.min.css'),
        );
        foreach($all_css_js_file as $handle => $fileinfo){
            wp_enqueue_style( $handle, $fileinfo['bwdbl_path_define'], null, '1.0', 'all');
        }
	}
	public function bwdbl_all_assets_for_elementor_editor_admin(){
		$all_css_js_file = array(
            'bwdbl_list_admin_icon_css' => array('bwdbl_path_admin_define'=>BWDBL_ASFSK_ASSETS_ADMIN_DIR_FILE . '/icon.css'),
        );
        foreach($all_css_js_file as $handle => $fileinfo){
            wp_enqueue_style( $handle, $fileinfo['bwdbl_path_admin_define'], null, '1.0', 'all');
        }
	}

	public function __construct() {
		// For public assets
		add_action('wp_enqueue_scripts', [$this, 'bwdbl_all_assets_for_the_public']);

		// For Elementor Editor
		add_action('elementor/editor/before_enqueue_scripts', [$this, 'bwdbl_all_assets_for_elementor_editor_admin']);
		
		// Register Category
		add_action( 'elementor/elements/categories_registered', [ $this, 'bwdbl_add_elementor_widget_categories' ] );

		// Register widgets
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'bwdbl_register_widgets' ] );

		// Register editor scripts
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'bwdbl_admin_editor_scripts' ] );
		
		$this->add_page_settings_controls();
	}
}

// Instantiate Plugin Class
ClassBWDBLList::instance();