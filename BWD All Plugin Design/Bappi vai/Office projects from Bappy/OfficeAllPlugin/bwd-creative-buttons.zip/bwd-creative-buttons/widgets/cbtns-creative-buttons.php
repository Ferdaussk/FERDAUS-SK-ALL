<?php
namespace CreativeButtons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CBTNSCreativeButtons extends Widget_Base {

	public function get_name() {
		return esc_html__( 'NameCreativeButtons', 'bwd-creative-buttons' );
	}

	public function get_title() {
		return esc_html__( 'BWD Creative Buttons', 'elementor' );
	}

	public function get_icon() {
		return 'cbtns-buttons-icon eicon-dual-button';
	}

	public function get_categories() {
		return [ 'bwd-creative-buttons-category' ];
	}

	public function get_script_depends() {
		return [ 'bwd-creative-buttons-category' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'cbtns_buttons_content_section',
			[
				'label' => esc_html__( 'Buttons Content', 'bwd-creative-buttons' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'cbtns_style_selection',
			[
				'label' => esc_html__( 'Button Styles', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1' => esc_html__( 'Style 1', 'bwd-creative-buttons' ),
					'style2' => esc_html__( 'Style 2', 'bwd-creative-buttons' ),
					'style3' => esc_html__( 'Style 3', 'bwd-creative-buttons' ),
					'style4' => esc_html__( 'Style 4', 'bwd-creative-buttons' ),
					'style5' => esc_html__( 'Style 5', 'bwd-creative-buttons' ),
					'style6' => esc_html__( 'Style 6', 'bwd-creative-buttons' ),
					'style7' => esc_html__( 'Style 7', 'bwd-creative-buttons' ),
					'style8' => esc_html__( 'Style 8', 'bwd-creative-buttons' ),
					'style9' => esc_html__( 'Style 9', 'bwd-creative-buttons' ),
					'style10' => esc_html__( 'Style 10', 'bwd-creative-buttons' ),
					'style11' => esc_html__( 'Style 11', 'bwd-creative-buttons' ),
					'style12' => esc_html__( 'Style 12', 'bwd-creative-buttons' ),
					'style13' => esc_html__( 'Style 13', 'bwd-creative-buttons' ),
					'style14' => esc_html__( 'Style 14', 'bwd-creative-buttons' ),
					'style15' => esc_html__( 'Style 15', 'bwd-creative-buttons' ),
					'style16' => esc_html__( 'Style 16', 'bwd-creative-buttons' ),
					'style17' => esc_html__( 'Style 17', 'bwd-creative-buttons' ),
					'style18' => esc_html__( 'Style 18', 'bwd-creative-buttons' ),
					'style19' => esc_html__( 'Style 19', 'bwd-creative-buttons' ),
					'style20' => esc_html__( 'Style 20', 'bwd-creative-buttons' ),
					'style21' => esc_html__( 'Style 21', 'bwd-creative-buttons' ),
					'style22' => esc_html__( 'Style 22', 'bwd-creative-buttons' ),
					'style23' => esc_html__( 'Style 23', 'bwd-creative-buttons' ),
					'style24' => esc_html__( 'Style 24', 'bwd-creative-buttons' ),
					'style25' => esc_html__( 'Style 25', 'bwd-creative-buttons' ),
					'style26' => esc_html__( 'Style 26', 'bwd-creative-buttons' ),
					'style27' => esc_html__( 'Style 27', 'bwd-creative-buttons' ),
					'style28' => esc_html__( 'Style 28', 'bwd-creative-buttons' ),
					'style29' => esc_html__( 'Style 29', 'bwd-creative-buttons' ),
					'style30' => esc_html__( 'Style 30', 'bwd-creative-buttons' ),
					'style31' => esc_html__( 'Style 31', 'bwd-creative-buttons' ),
					'style32' => esc_html__( 'Style 32', 'bwd-creative-buttons' ),
					'style33' => esc_html__( 'Style 33', 'bwd-creative-buttons' ),
					'style34' => esc_html__( 'Style 34', 'bwd-creative-buttons' ),
					'style35' => esc_html__( 'Style 35', 'bwd-creative-buttons' ),
					'style36' => esc_html__( 'Style 36', 'bwd-creative-buttons' ),
					'style37' => esc_html__( 'Style 37', 'bwd-creative-buttons' ),
					'style38' => esc_html__( 'Style 38', 'bwd-creative-buttons' ),
					'style39' => esc_html__( 'Style 39', 'bwd-creative-buttons' ),
					'style40' => esc_html__( 'Style 40', 'bwd-creative-buttons' ),
					'style41' => esc_html__( 'Style 41', 'bwd-creative-buttons' ),
					'style42' => esc_html__( 'Style 42', 'bwd-creative-buttons' ),
					'style43' => esc_html__( 'Style 43', 'bwd-creative-buttons' ),
					'style44' => esc_html__( 'Style 44', 'bwd-creative-buttons' ),
					'style45' => esc_html__( 'Style 45', 'bwd-creative-buttons' ),
					'style46' => esc_html__( 'Style 46', 'bwd-creative-buttons' ),
					'style47' => esc_html__( 'Style 47', 'bwd-creative-buttons' ),
					'style48' => esc_html__( 'Style 48', 'bwd-creative-buttons' ),
					'style49' => esc_html__( 'Style 49', 'bwd-creative-buttons' ),
					'style50' => esc_html__( 'Style 50', 'bwd-creative-buttons' ),
					'style51' => esc_html__( 'Style 51', 'bwd-creative-buttons' ),
					'style52' => esc_html__( 'Style 52', 'bwd-creative-buttons' ),
					'style53' => esc_html__( 'Style 53', 'bwd-creative-buttons' ),
					'style54' => esc_html__( 'Style 54', 'bwd-creative-buttons' ),
					'style55' => esc_html__( 'Style 55', 'bwd-creative-buttons' ),
					'style56' => esc_html__( 'Style 56', 'bwd-creative-buttons' ),
					'style57' => esc_html__( 'Style 57', 'bwd-creative-buttons' ),
					'style58' => esc_html__( 'Style 58', 'bwd-creative-buttons' ),
					'style59' => esc_html__( 'Style 59 Gradient', 'bwd-creative-buttons' ),
					'style60' => esc_html__( 'Style 60 Gradient', 'bwd-creative-buttons' ),
					'style61' => esc_html__( 'Style 61 Gradient', 'bwd-creative-buttons' ),
					'style62' => esc_html__( 'Style 62 Gradient', 'bwd-creative-buttons' ),
					'style63' => esc_html__( 'Style 63 Gradient', 'bwd-creative-buttons' ),
					'style64' => esc_html__( 'Style 64 Gradient', 'bwd-creative-buttons' ),
					'style65' => esc_html__( 'Style 65 Gradient', 'bwd-creative-buttons' ),
					'style66' => esc_html__( 'Style 66 Gradient', 'bwd-creative-buttons' ),
					'style67' => esc_html__( 'Style 67 Gradient', 'bwd-creative-buttons' ),
					'style68' => esc_html__( 'Style 68 Gradient', 'bwd-creative-buttons' ),
					'style69' => esc_html__( 'Style 69 Gradient', 'bwd-creative-buttons' ),
					'style70' => esc_html__( 'Style 70 Gradient', 'bwd-creative-buttons' ),
					'style71' => esc_html__( 'Style 71 Gradient', 'bwd-creative-buttons' ),
					'style72' => esc_html__( 'Style 72 Gradient', 'bwd-creative-buttons' ),
					'style73' => esc_html__( 'Style 73 Gradient', 'bwd-creative-buttons' ),
					'style74' => esc_html__( 'Style 74 Social', 'bwd-creative-buttons' ),
					'style75' => esc_html__( 'Style 75 Social', 'bwd-creative-buttons' ),
					'style76' => esc_html__( 'Style 76 Social', 'bwd-creative-buttons' ),
					'style77' => esc_html__( 'Style 77 Social', 'bwd-creative-buttons' ),
					'style78' => esc_html__( 'Style 78 Social', 'bwd-creative-buttons' ),
					'style79' => esc_html__( 'Style 79 Social', 'bwd-creative-buttons' ),
					'style80' => esc_html__( 'Style 80 Social', 'bwd-creative-buttons' ),
					'style81' => esc_html__( 'Style 81', 'bwd-creative-buttons' ),
					'style82' => esc_html__( 'Style 82', 'bwd-creative-buttons' ),
					'style83' => esc_html__( 'Style 83', 'bwd-creative-buttons' ),
					'style84' => esc_html__( 'Style 84', 'bwd-creative-buttons' ),
					'style85' => esc_html__( 'Style 85', 'bwd-creative-buttons' ),
					'style86' => esc_html__( 'Style 86', 'bwd-creative-buttons' ),
					'style87' => esc_html__( 'Style 87 Masking', 'bwd-creative-buttons' ),
					'style88' => esc_html__( 'Style 88 Masking', 'bwd-creative-buttons' ),
					'style89' => esc_html__( 'Style 89 Masking', 'bwd-creative-buttons' ),
					'style90' => esc_html__( 'Style 90 Masking', 'bwd-creative-buttons' ),
					'style91' => esc_html__( 'Style 91 Masking', 'bwd-creative-buttons' ),
					'style92' => esc_html__( 'Style 92 Masking', 'bwd-creative-buttons' ),
					'style93' => esc_html__( 'Style 93 Masking', 'bwd-creative-buttons' ),
					'style94' => esc_html__( 'Style 94 Masking', 'bwd-creative-buttons' ),
					'style95' => esc_html__( 'Style 95 Masking', 'bwd-creative-buttons' ),
					'style96' => esc_html__( 'Style 96 Masking', 'bwd-creative-buttons' ),
					'style97' => esc_html__( 'Style 97 Masking', 'bwd-creative-buttons' ),
					'style98' => esc_html__( 'Style 98 Masking', 'bwd-creative-buttons' ),
					'style99' => esc_html__( 'Style 99 Masking', 'bwd-creative-buttons' ),
					'style100' => esc_html__( 'Style 100 Masking', 'bwd-creative-buttons' ),
					'style101' => esc_html__( 'Style 101 Masking', 'bwd-creative-buttons' ),
					'style102' => esc_html__( 'Style 102 Masking', 'bwd-creative-buttons' ),
					'style103' => esc_html__( 'Style 103 Masking', 'bwd-creative-buttons' ),
					'style104' => esc_html__( 'Style 104 Masking', 'bwd-creative-buttons' ),
					'style105' => esc_html__( 'Style 105 Masking', 'bwd-creative-buttons' ),
					'style106' => esc_html__( 'Style 106 Masking', 'bwd-creative-buttons' ),
					'style107' => esc_html__( 'Style 107 Masking', 'bwd-creative-buttons' ),
					'style108' => esc_html__( 'Style 108 Masking', 'bwd-creative-buttons' ),
					'style109' => esc_html__( 'Style 109 Masking', 'bwd-creative-buttons' ),
					'style110' => esc_html__( 'Style 110 Masking', 'bwd-creative-buttons' ),
					'style111' => esc_html__( 'Style 111 Masking', 'bwd-creative-buttons' ),
				],
			]
		);
		$this->add_control(
			'cbtns_text_buttons', [
				'label' => esc_html__( 'Text', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Click Here' , 'bwd-creative-buttons' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'cbtns_link_buttons',
			[
				'label' => esc_html__( 'Link', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_attr__( 'https://www.your-link.com', 'bwd-creative-buttons' ),
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
			]
		);
		$this->add_control(
			'cbtns_alignment_buttons',
			[
				'label' => esc_html__( 'Alignment', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'cbtns-center',
				'options' => [
					'cbtns-left' => esc_html__( 'Left', 'bwd-creative-buttons' ),
					'cbtns-center' => esc_html__( 'Center', 'bwd-creative-buttons' ),
					'cbtns-right' => esc_html__( 'Right', 'bwd-creative-buttons' ),
				],
			]
		);

		$this->add_control(
			'cbtns_buttons_a',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'cbtns_buttons_icon_switcher',
			[
				'label' => esc_html__( 'Show Icon (If Has)', 'bwd-creative-buttons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'bwd-creative-buttons' ),
				'label_off' => esc_html__( 'Hide', 'bwd-creative-buttons' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
			'cbtns_content_icon_button',
			[
				'label' => esc_html__( 'Icon', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fab fa-facebook-f',
					'library' => 'solid',
				],
				'condition' => [
					'cbtns_buttons_icon_switcher' => 'yes',
				],
			]
		);
		$this->add_control(
			'cbtns_buttons_icon_positions',
			[
				'label' => esc_html__( 'Position', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'icon_position_right',
				'options' => [
					'icon_position_right' => esc_html__( 'Right', 'bwd-creative-buttons' ),
					'icon_position_left' => esc_html__( 'Left', 'bwd-creative-buttons' ),
				],
				'condition' => [
					'cbtns_buttons_icon_switcher' => 'yes',
				],
			]
		);
		// Hover
		$this->start_controls_tabs(
			'cbtns_title_style_tabsxs'
		);

		$this->start_controls_tab(
			'cbtns_title_style_normal_tabxx',
			[
				'label' => esc_html__( 'Normal', 'bwd-creative-buttons' ),
				'condition' => [
					'cbtns_buttons_icon_switcher' => 'yes',
				],
			]
		);
		
		$this->add_control(
			'cbtns_content_quote_right_color',
			[
				'label' => esc_html__( 'Color', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cbtns-icon i' => 'color: {{VALUE}}',
				],
				'condition' => [
					'cbtns_buttons_icon_switcher' => 'yes',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'cbtns_button_hoveraaaa_sssssbackground',
				'label' => esc_html__( 'Background Type', 'bwd-creative-buttons' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .cbtns-icon',
				'condition' => [
					'cbtns_buttons_icon_switcher' => 'yes',
				],
			]
		);
		$this->add_control(
			'cbtns_content_quote_right_hover_color',
			[
				'label' => esc_html__( 'Background Color', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cbtns-icon' => 'background: {{VALUE}}',
				],
				'condition' => [
					'cbtns_buttons_icon_switcher' => 'yes',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'cbtns_title_style_hover_tabaa',
			[
				'label' => esc_html__( 'Hover', 'bwd-creative-buttons' ),
				'condition' => [
					'cbtns_buttons_icon_switcher' => 'yes',
				],
			]
		);
		
		$this->add_control(
			'cbtns_content_quote_right_colorss',
			[
				'label' => esc_html__( 'Color', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} a:hover .cbtns-icon' => 'color: {{VALUE}}',
				],
				'condition' => [
					'cbtns_buttons_icon_switcher' => 'yes',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'cbtns_button_hoveraaaa_background',
				'label' => esc_html__( 'Background Type', 'bwd-creative-buttons' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} a:hover .cbtns-icon',
				'condition' => [
					'cbtns_buttons_icon_switcher' => 'yes',
				],
			]
		);
		$this->add_control(
			'cbtns_content_quote_right_hover_colordd',
			[
				'label' => esc_html__( 'Hover Background', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} a:hover .cbtns-icon' => 'background: {{VALUE}}',
				],
				'condition' => [
					'cbtns_buttons_icon_switcher' => 'yes',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// Hover end

		
		$this->add_responsive_control(
			'cbtns_buttons_the_box_right_icon_size',
			[
				'label' => esc_html__( 'Icon Size', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'laptop', 'tablet', 'tablet_extra', 'mobile', 'mobile_extra' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'laptop' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_extra' => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_extra' => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .cbtns-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'cbtns_buttons_icon_switcher' => 'yes',
				],
			]
		);


		$this->add_control(
			'cbtns_buttons_sk',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_responsive_control(
			'cbtns_buttons_social_border_height',
			[
				'label' => esc_html__( 'Height', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'laptop', 'tablet', 'tablet_extra', 'mobile', 'mobile_extra' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'laptop' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_extra' => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_extra' => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} a .cbtns-icon' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'cbtns_buttons_icon_switcher' => 'yes',
				],
			]
		);
		$this->add_responsive_control(
			'cbtns_buttons_social_border_width',
			[
				'label' => esc_html__( 'Width', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'laptop', 'tablet', 'tablet_extra', 'mobile', 'mobile_extra' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'laptop' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_extra' => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_extra' => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} a .cbtns-icon' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'cbtns_buttons_icon_switcher' => 'yes',
				],
			]
		);
		$this->add_responsive_control(
			'cbtns_buttons_social_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'laptop', 'tablet', 'tablet_extra', 'mobile', 'mobile_extra' ],
				'desktop_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'laptop' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'tablet_extra' => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => '',
					'unit' => 'px',
				],
				'mobile_extra' => [
					'size' => '',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} a .cbtns-icon' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'cbtns_buttons_icon_switcher' => 'yes',
				],
			]
		);

		$this->add_control(
			'cbtns_buttons_ska',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'cbtns_buttons_custom_class_id', [
				'label' => esc_html__( 'Class ID (Custom)', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'description' => sprintf(
					esc_html__( 'Please make sure the Class and ID is unique. This field allows %1$sA-z 0-9%2$s & underscore chars without spaces.', 'bwd-creative-buttons' ),
					'<code>',
					'</code>'
				),
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'cbtns_buttons_style_section',
			[
				'label' => esc_html__( 'Buttons Style', 'bwd-creative-buttons' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'cbtns_buttons_content_typography',
				'selector' => '{{WRAPPER}} .cbtns-title, a:before, a:after, .cbtns_creative_buttons a',
			]
		);
		$this->add_control(
			'cbtns_buttons_text_shadow', [
				'label' => esc_html__( 'Text Shadow', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::TEXT_SHADOW,
				'default' => [
					'color' => 'transparent'
				],
				'selectors' => [
					'{{SELECTOR}} {{WRAPPER}} .cbtns-title' => 'text-shadow: {{HORIZONTAL}}px {{VERTICAL}}px {{BLUR}}px {{COLOR}};',
				],
			]
		);
		// Hover
		$this->start_controls_tabs(
			'cbtns_title_style_tabs'
		);

		$this->start_controls_tab(
			'cbtns_title_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'bwd-creative-buttons' ),
			]
		);
		
		$this->add_control(
			'cbtns_title_content_text_normal_color',
			[
				'label' => esc_html__( 'Text Color', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cbtns_creative_buttons .cbtns-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'cbtns_button_normal_background',
				'label' => esc_html__( 'Background Type', 'bwd-creative-buttons' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .cbtns_creative_buttons .cbtns-title',
			]
		);
		$this->add_control(
			'cbtns_title_content_normal_color',
			[
				'label' => esc_html__( 'Background Color', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cbtns_creative_buttons .cbtns-title' => 'background: {{VALUE}}',
					
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'cbtns_title_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'bwd-creative-buttons' ),
			]
		);
		
		$this->add_control(
			'cbtns_title_content_text_hover_color',
			[
				'label' => esc_html__( 'Text Color', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cbtns_creative_buttons .cbtns-title:hover' => 'color: {{VALUE}}',
					
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'cbtns_button_hover_background',
				'label' => esc_html__( 'Background Type', 'bwd-creative-buttons' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .cbtns_creative_buttons .cbtns-title::before, .cbtns_creative_buttons .cbtns-title:hover',
			]
		);
		$this->add_control(
			'cbtns_title_content_hover_color',
			[
				'label' => esc_html__( 'Background Color', 'bwd-creative-buttons' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cbtns_creative_buttons .cbtns-title::before' => 'background: {{VALUE}}',
					'{{WRAPPER}} .cbtns_creative_buttons .cbtns-title::before' => 'border-color: {{VALUE}}', // Style no 56
					'{{WRAPPER}} .cbtns_creative_buttons .cbtns-title::after' => 'border-color: {{VALUE}}', // Style no 56
					'{{WRAPPER}} .cbtns_creative_buttons .cbtns-title:hover' => 'background: {{VALUE}}',
					'{{WRAPPER}} .cbtns_creative_buttons .cbtns-title:hover' => 'background: {{VALUE}}',
					
				],
			]
		);
		$this->add_control(
			'cbtns_buttons_entrance_animation',
			[
				'label' => esc_html__( 'Entrance Animation', 'bwd-creative-buttons' ),
				'type' => \Elementor\Controls_Manager::ANIMATION,
				'prefix_class' => '.cbtns_creative_buttons',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// Hover end
		
		$this->add_responsive_control(
            'cbtns_buttons_border_radius',
            [
                'label' => esc_html__('Border Radius', 'bwd-creative-buttons'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .cbtns_creative_buttons .cbtns-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'cbtns_buttons_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'bwd-creative-buttons' ),
				'selector' => '{{WRAPPER}} .cbtns_creative_buttons .cbtns-title',
			]
		);
		$this->add_responsive_control(
            'cbtns_buttons_padding',
            [
                'label' => esc_html__('Padding', 'bwd-creative-buttons'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .cbtns_creative_buttons .cbtns-title, .cbtns_creative_buttons .cbtns-title:after, .cbtns-btn-eleven .cbtns-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->end_controls_section();

	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		// Social Link
		if ( ! empty( $settings['cbtns_link_buttons']['url'] ) ) {
			$this->add_link_attributes( 'cbtns_link_buttons', $settings['cbtns_link_buttons'] );
		}
		?>
		<?php
		if('cbtns-left' === $settings['cbtns_alignment_buttons']){
			?>
			<div class="cbtns-all-button-left">
			<?php
			}
		if('cbtns-center' === $settings['cbtns_alignment_buttons']){
			?>
			<div class="cbtns-all-button-center">
			<?php
			}
		if('cbtns-right' === $settings['cbtns_alignment_buttons']){
			?>
			<div class="cbtns-all-button-right">
			<?php
			}
			// Single buttons
			if('style1' === $settings['cbtns_style_selection']){
			?>
			<div class="cbtns-btn-one cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
				<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
			</div>
			<?php
			} elseif('style2' === $settings['cbtns_style_selection']){
			?>
			<div class="cbtns-btn-two cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
				<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>">
				<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
					<span style="top: 59.7969px; left: 2.46875px;"></span>
				</a>
			</div>
			<?php
			} elseif('style3' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-three cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style4' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-four cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style5' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-five cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style6' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-six cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style7' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-seven cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style8' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-eight cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a class="cbtns-link8" href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"> <span class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></span></a>
				</div>
				<?php
			} elseif('style9' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-nine cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>" data-hover="<?php echo esc_html__($settings['cbtns_text_buttons']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style10' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-ten cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style11' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-eleven cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style12' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-twelve cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style13' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-thirteen cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style14' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fourteen cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style15' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fifteen cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style16' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-sixteen cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style17' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-seventeen cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style18' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-eighteen cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style19' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-nineteen cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style20' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-twenty cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style21' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-twenty-one cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style22' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-twenty-two cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style23' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-twenty-three cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style24' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-twenty-four cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a class="cbtns-link24" href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><span class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></span></a>
				</div>
				<?php
			} elseif('style25' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-twenty-five cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style26' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-twenty-six cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>" class="" data-hover="<?php echo esc_html__($settings['cbtns_text_buttons']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style27' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fifty-nine cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style28' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-eighty-seven cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style29' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-eighty-eight cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style30' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-eighty-nine cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style31' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-thirty-one cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style32' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-thirty-two cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style33' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-thirty-three cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style34' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-thirty-four cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style35' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-thirty-five cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style36' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-thirty-six cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style37' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-thirty-seven cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style38' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-thirty-eight cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style39' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-thirty-nine cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style40' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fourty cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a class="cbtns-link40 cbtns-title" href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><?php echo esc_html__($settings['cbtns_text_buttons']); ?><span></span></a>
				</div>
				<?php
			} elseif('style41' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fourty-one cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style42' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fourty-two cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style43' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fourty-three cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style44' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fourty-four cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>" ><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style45' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fourty-five cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style46' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fourty-six cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style47' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fourty-seven cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style48' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fourty-eight cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style49' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fourty-nine cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a> 
					<span></span>
				</div>
				<?php
			} elseif('style50' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fifty cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style51' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fifty-one cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style52' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-sixty cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style53' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fifty-three cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
						<span></span>
						<span></span>
						<span></span>
						<span></span>
						<span></span>
					</a>
				</div>
				<?php
			} elseif('style54' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-sixty-one cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style55' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fifty-five cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style56' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fifty-six cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style57' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fifty-seven cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style58' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fifty-eight cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style59' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-twenty-seven cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style60' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fifty-two cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style61' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-fifty-four cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style62' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-sixty-two cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style63' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-sixty-three cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style64' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-sixty-four cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style65' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-sixty-five cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style66' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-sixty-six cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style67' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-sixty-seven cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style68' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-sixty-eight cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style69' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-sixty-nine cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style70' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-seventy cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style71' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-seventy-one cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style72' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-seventy-two cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style73' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-seventy-three cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style74' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-seventy-four cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>">
					<?php 
					if('yes' === $settings['cbtns_buttons_icon_switcher']){
						if('icon_position_right' === $settings['cbtns_buttons_icon_positions']){
						?>
						<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
						<span class="cbtns-icon cbtns-icon-2"><i class="fa-solid <?php echo esc_attr($settings['cbtns_content_icon_button']['value']); ?>"></i></span>
						<?php
						} elseif('icon_position_left' === $settings['cbtns_buttons_icon_positions']){
						?>
						<span class="cbtns-icon cbtns-icon-1"><i class="fa-solid <?php echo esc_attr($settings['cbtns_content_icon_button']['value']); ?>"></i></span>
						<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
						<?php
						}
					} else{
						?>
						<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
						<?php
					}
					?>
					</a>
				</div>
				<?php
			} elseif('style75' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-seventy-five cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>">
					<?php 
					if('yes' === $settings['cbtns_buttons_icon_switcher']){
						if('icon_position_right' === $settings['cbtns_buttons_icon_positions']){
							?>
							<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
							<span class="cbtns-icon cbtns-icon-2"><i class="fa-solid <?php echo esc_attr($settings['cbtns_content_icon_button']['value']); ?>"></i></span>
							<?php
						} elseif('icon_position_left' === $settings['cbtns_buttons_icon_positions']){
							?>
							<span class="cbtns-icon cbtns-icon-1"><i class="fa-solid <?php echo esc_attr($settings['cbtns_content_icon_button']['value']); ?>"></i></span>
							<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
							<?php
						}
					} else{
						?>
						<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
						<?php
					}
					?>
					</a>
				</div>
				<?php
			} elseif('style76' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-seventy-six cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>">
					<?php 
					if('yes' === $settings['cbtns_buttons_icon_switcher']){
						if('icon_position_right' === $settings['cbtns_buttons_icon_positions']){
						?>
						<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
						<span class="cbtns-icon cbtns-icon-2"><i class="fa-brands <?php echo esc_attr($settings['cbtns_content_icon_button']['value']); ?>"></i></span>
						<?php
						} elseif('icon_position_left' === $settings['cbtns_buttons_icon_positions']){
							?>
							<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
							<span class="cbtns-icon"><i class="fa-brands <?php echo esc_attr($settings['cbtns_content_icon_button']['value']); ?>"></i></span>
							<?php
						}
					} else{
						?>
						<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
						<?php
					}
					?>
					</a>
				</div>
				<?php
			} elseif('style77' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-seventy-seven cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>">
					<?php 
					if('yes' === $settings['cbtns_buttons_icon_switcher']){
						if('icon_position_right' === $settings['cbtns_buttons_icon_positions']){
						?>
						<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
						<span class="cbtns-icon cbtns-icon-2"><i class="fa-brands <?php echo esc_attr($settings['cbtns_content_icon_button']['value']); ?>"></i></span>
						<?php
						} elseif('icon_position_left' === $settings['cbtns_buttons_icon_positions']){
							?>
							<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
							<span class="cbtns-icon"><i class="fa-brands <?php echo esc_attr($settings['cbtns_content_icon_button']['value']); ?>"></i></span>
							<?php
						}
					} else{
						?>
						<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
						<?php
					}
					?>
					</a>
				</div>
				<?php
			} elseif('style78' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-seventy-eight cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>">
					<?php 
					if('yes' === $settings['cbtns_buttons_icon_switcher']){
						if('icon_position_right' === $settings['cbtns_buttons_icon_positions']){
						?>
						<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
						<span class="cbtns-icon cbtns-icon-2"><i class="fa-brands <?php echo esc_attr($settings['cbtns_content_icon_button']['value']); ?>"></i></span>
						<?php
						} elseif('icon_position_left' === $settings['cbtns_buttons_icon_positions']){
							?>
							<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
							<span class="cbtns-icon"><i class="fa-brands <?php echo esc_attr($settings['cbtns_content_icon_button']['value']); ?>"></i></span>
							<?php
						}
					} else{
						?>
						<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
						<?php
					}
					?>
					</a>
				</div>
				<?php
			} elseif('style79' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-seventy-nine cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>">
					<?php 
					if('yes' === $settings['cbtns_buttons_icon_switcher']){
						if('icon_position_right' === $settings['cbtns_buttons_icon_positions']){
							?>
							<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
							<span class="cbtns-icon"><i class="fa-brands <?php echo esc_attr($settings['cbtns_content_icon_button']['value']); ?>"></i></span>
							<?php
						} elseif('icon_position_left' === $settings['cbtns_buttons_icon_positions']){
							?>
							<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
							<span class="cbtns-icon cbtns-icon-2"><i class="fa-brands <?php echo esc_attr($settings['cbtns_content_icon_button']['value']); ?>"></i></span>
							<?php
						}
					} else{
						?>
						<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
						<?php
					}
					?>
					</a>
				</div>
				<?php
			} elseif('style80' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-eighty cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>">
					<?php 
					if('yes' === $settings['cbtns_buttons_icon_switcher']){
						if('icon_position_right' === $settings['cbtns_buttons_icon_positions']){
							?>
							<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
							<span class="cbtns-icon"><i class="fa-brands <?php echo esc_attr($settings['cbtns_content_icon_button']['value']); ?>"></i></span>
							<?php
						} elseif('icon_position_left' === $settings['cbtns_buttons_icon_positions']){
							?>
							<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
							<span class="cbtns-icon cbtns-icon-2"><i class="fa-brands <?php echo esc_attr($settings['cbtns_content_icon_button']['value']); ?>"></i></span>
							<?php
						}
					} else{
						?>
						<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
						<?php
					}
					?>
					</a>
				</div>
				<?php
			} elseif('style81' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-eighty-one cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
 					<a class="cbtns-title-link" href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>">
						<span class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></span>
						<div class="liquid"></div>
					</a>
				</div>
				<?php
			} elseif('style82' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-ninety cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style83' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-eighty-three cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
						<span></span>
						<span></span>
					</a>
				</div>
				<?php
			} elseif('style84' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-eighty-four cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div><span></span></a>
				</div>
				<?php
			} elseif('style85' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-eighty-five cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div><span></span></a>
				</div>
				<?php
			} elseif('style86' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-eighty-six cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div><span></span></a>
				</div>
				<?php
			} elseif('style87' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-twenty-eight cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>" data-text="<?php echo esc_html__($settings['cbtns_text_buttons']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style88' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-twenty-nine cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>" data-text="<?php echo esc_html__($settings['cbtns_text_buttons']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style89' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-thirty cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>" data-text="<?php echo esc_html__($settings['cbtns_text_buttons']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style90' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-eighty-two cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>">
						<div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div>
					</a>
				</div>
				<?php
			} elseif('style91' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-ninety-one cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style92' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-ninety-two cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>" data-text="<?php echo esc_html__($settings['cbtns_text_buttons']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style93' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-ninety-three cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style94' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-ninety-four cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style95' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-ninety-five cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style96' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-ninety-six cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style97' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-ninety-seven cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style98' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-ninety-eight cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style99' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-ninety-nine cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style100' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-one-hundred cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style101' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-one-hundred-one cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style102' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-one-hundred-two cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style103' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-one-hundred-three cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style104' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-one-hundred-four cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style105' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-one-hundred-five cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style106' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-one-hundred-six cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style107' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-one-hundred-seven cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style108' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-one-hundred-eight cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style109' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-one-hundred-nine cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style110' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-one-hundred-ten cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			} elseif('style111' === $settings['cbtns_style_selection']){
				?>
				<div class="cbtns-btn-one-hundred-eleven cbtns_creative_buttons <?php echo esc_attr($settings['cbtns_buttons_custom_class_id']); ?>">
					<a href="<?php echo esc_url($settings['cbtns_link_buttons']['url']); ?>"><div class="cbtns-title"><?php echo esc_html__($settings['cbtns_text_buttons']); ?></div></a>
				</div>
				<?php
			}
			?>
		</div> <!-- Buttons Alignment -->
		<?php
	}

	protected function content_template() {
		?>
		<# if('cbtns-left' === settings['cbtns_alignment_buttons']){ #>
		<div class="cbtns-all-button-left">
			<# } 
		if('cbtns-center' === settings['cbtns_alignment_buttons']){ #>
		<div class="cbtns-all-button-center">
			<# } 
		if('cbtns-right' === settings['cbtns_alignment_buttons']){ #>
		<div class="cbtns-all-button-right">
			<# }
			<!-- Single buttons -->
			if('style1' === settings['cbtns_style_selection']){ #>
			<div class="cbtns-btn-one cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
				<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
			</div>
			<# } else if('style2' === settings['cbtns_style_selection']){ #>
			<div class="cbtns-btn-two cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
				<a href="{{{settings['cbtns_link_buttons']['url']}}}">
				<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
					<span style="top: 59.7969px; left: 2.46875px;"></span>
				</a>
			</div>
			<# } else if('style3' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-three cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style4' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-four cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style5' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-five cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style6' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-six cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style7' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-seven cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style8' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-eight cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a class="cbtns-link8" href="{{{settings['cbtns_link_buttons']['url']}}}"> <span class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</span></a>
				</div>
			<# } else if('style9' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-nine cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}" data-hover="{{{settings['cbtns_text_buttons']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style10' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-ten cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style11' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-eleven cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style12' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-twelve cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style13' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-thirteen cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style14' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fourteen cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style15' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fifteen cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style16' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-sixteen cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style17' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-seventeen cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style18' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-eighteen cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style19' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-nineteen cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style20' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-twenty cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style21' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-twenty-one cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style22' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-twenty-two cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style23' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-twenty-three cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style24' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-twenty-four cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a class="cbtns-link24" href="{{{settings['cbtns_link_buttons']['url']}}}"><span class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</span></a>
				</div>
			<# } else if('style25' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-twenty-five cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style26' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-twenty-six cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}" class="" data-hover="{{{settings['cbtns_text_buttons']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style27' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fifty-nine cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style28' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-eighty-seven cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style29' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-eighty-eight cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style30' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-eighty-nine cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style31' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-thirty-one cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style32' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-thirty-two cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style33' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-thirty-three cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style34' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-thirty-four cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style35' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-thirty-five cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style36' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-thirty-six cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style37' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-thirty-seven cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style38' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-thirty-eight cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style39' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-thirty-nine cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style40' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fourty cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a class="cbtns-link40 cbtns-title" href="{{{settings['cbtns_link_buttons']['url']}}}">{{{settings['cbtns_text_buttons']}}}<span></span></a>
				</div>
			<# } else if('style41' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fourty-one cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style42' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fourty-two cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style43' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fourty-three cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style44' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fourty-four cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}" ><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style45' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fourty-five cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style46' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fourty-six cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style47' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fourty-seven cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style48' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fourty-eight cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style49' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fourty-nine cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a> 
					<span></span>
				</div>
			<# } else if('style50' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fifty cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style51' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fifty-one cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style52' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-sixty cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style53' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fifty-three cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
						<span></span>
						<span></span>
						<span></span>
						<span></span>
						<span></span>
					</a>
				</div>
			<# } else if('style54' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-sixty-one cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style55' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fifty-five cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style56' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fifty-six cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style57' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fifty-seven cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style58' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fifty-eight cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style59' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-twenty-seven cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style60' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fifty-two cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style61' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-fifty-four cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
				<# } else if('style62' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-sixty-two cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style63' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-sixty-three cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style64' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-sixty-four cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style65' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-sixty-five cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style66' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-sixty-six cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style67' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-sixty-seven cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style68' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-sixty-eight cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style69' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-sixty-nine cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style70' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-seventy cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style71' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-seventy-one cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style72' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-seventy-two cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style73' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-seventy-three cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style74' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-seventy-four cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}">
					<#
					if('yes' === settings['cbtns_buttons_icon_switcher']){
						if('icon_position_right' === settings['cbtns_buttons_icon_positions']){
						#>
							<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
							<span class="cbtns-icon cbtns-icon-2"><i class="fa-solid {{{settings['cbtns_content_icon_button']['value']}}}"></i></span>
						<#
						} else if('icon_position_left' === settings['cbtns_buttons_icon_positions']){
							#>
							<span class="cbtns-icon cbtns-icon-1"><i class="fa-solid {{{settings['cbtns_content_icon_button']['value']}}}"></i></span>
							<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
							<#
						}
					} else{
						#>
						<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
						<#
					}
					#>
					</a>
				</div>
			<# } else if('style75' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-seventy-five cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}">
					<#
					if('yes' === settings['cbtns_buttons_icon_switcher']){
						if('icon_position_right' === settings['cbtns_buttons_icon_positions']){
						#>
						<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
						<span class="cbtns-icon cbtns-icon-2"><i class="fa-solid {{{settings['cbtns_content_icon_button']['value']}}}"></i></span>
						<#
						} else if('icon_position_left' === settings['cbtns_buttons_icon_positions']){
						#>
						<span class="cbtns-icon cbtns-icon-1"><i class="fa-solid {{{settings['cbtns_content_icon_button']['value']}}}"></i></span>
						<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
						<#
						}
					} else{
						#>
						<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
						<#
					}
					#>
					</a>
				</div>
			<# } else if('style76' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-seventy-six cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}">
					<#
					if('yes' === settings['cbtns_buttons_icon_switcher']){
						if('icon_position_right' === settings['cbtns_buttons_icon_positions']){
						#>
						<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
						<span class="cbtns-icon cbtns-icon-2"><i class="fa-brands {{{settings['cbtns_content_icon_button']['value']}}}"></i></span>
						<#
						} else if('icon_position_left' === settings['cbtns_buttons_icon_positions']){
							#>
							<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
							<span class="cbtns-icon"><i class="fa-brands {{{settings['cbtns_content_icon_button']['value']}}}"></i></span>
							<#
						}
					} else{
						#>
						<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
						<#
					}
					#>
					</a>
				</div>
			<# } else if('style77' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-seventy-seven cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}">
					<#
					if('yes' === settings['cbtns_buttons_icon_switcher']){
						if('icon_position_right' === settings['cbtns_buttons_icon_positions']){
						#>
						<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
						<span class="cbtns-icon cbtns-icon-2"><i class="fa-brands {{{settings['cbtns_content_icon_button']['value']}}}"></i></span>
						<#
						} else if('icon_position_left' === settings['cbtns_buttons_icon_positions']){
							#>
							<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
							<span class="cbtns-icon"><i class="fa-brands {{{settings['cbtns_content_icon_button']['value']}}}"></i></span>
							<#
						}
					} else{
						#>
						<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
						<#
					}
					#>
					</a>
				</div>
			<# } else if('style78' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-seventy-eight cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}">
					<#
					if('yes' === settings['cbtns_buttons_icon_switcher']){
						if('icon_position_right' === settings['cbtns_buttons_icon_positions']){
						#>
						<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
						<span class="cbtns-icon cbtns-icon-2"><i class="fa-brands {{{settings['cbtns_content_icon_button']['value']}}}"></i></span>
						<#
						} else if('icon_position_left' === settings['cbtns_buttons_icon_positions']){
							#>
							<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
							<span class="cbtns-icon"><i class="fa-brands {{{settings['cbtns_content_icon_button']['value']}}}"></i></span>
							<#
						}
					} else{
						#>
						<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
						<#
					}
					#>
					</a>
				</div>
			<# } else if('style79' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-seventy-nine cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}">
					<#
					if('yes' === settings['cbtns_buttons_icon_switcher']){
						if('icon_position_right' === settings['cbtns_buttons_icon_positions']){
						#>
							<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
							<span class="cbtns-icon"><i class="fa-brands {{{settings['cbtns_content_icon_button']['value']}}}"></i></span>
						<#
						} else if('icon_position_left' === settings['cbtns_buttons_icon_positions']){
							#>
							<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
							<span class="cbtns-icon cbtns-icon-2"><i class="fa-brands {{{settings['cbtns_content_icon_button']['value']}}}"></i></span>
							<#
						}
					} else{
						#>
						<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
						<#
					}
					#>
					</a>
				</div>
			<# } else if('style80' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-eighty cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}">
					<#
					if('yes' === settings['cbtns_buttons_icon_switcher']){
						if('icon_position_right' === settings['cbtns_buttons_icon_positions']){
						#>
							<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
							<span class="cbtns-icon"><i class="fa-brands {{{settings['cbtns_content_icon_button']['value']}}}"></i></span>
						<#
						} else if('icon_position_left' === settings['cbtns_buttons_icon_positions']){
							#>
							<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
							<span class="cbtns-icon cbtns-icon-2"><i class="fa-brands {{{settings['cbtns_content_icon_button']['value']}}}"></i></span>
							<#
						}
					} else{
						#>
						<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
						<#
					}
					#>
					</a>
				</div>
			<# } else if('style81' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-eighty-one cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a class="cbtns-title-link" href="{{{settings['cbtns_link_buttons']['url']}}}">
						<span class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</span>
						<div class="liquid"></div>
					</a>
				</div>
			<# } else if('style82' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-ninety cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style83' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-eighty-three cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
						<span></span>
						<span></span>
					</a>
				</div>
			<# } else if('style84' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-eighty-four cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div><span></span></a>
				</div>
			<# } else if('style85' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-eighty-five cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div><span></span></a>
				</div>
			<# } else if('style86' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-eighty-six cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div><span></span></a>
				</div>
			<# } else if('style87' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-twenty-eight cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}" data-text="{{{settings['cbtns_text_buttons']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style88' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-twenty-nine cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}" data-text="{{{settings['cbtns_text_buttons']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style89' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-thirty cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}" data-text="{{{settings['cbtns_text_buttons']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style90' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-eighty-two cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}">
						<div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div>
					</a>
				</div>
			<# } else if('style91' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-ninety-one cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style92' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-ninety-two cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}" data-text="{{{settings['cbtns_text_buttons']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style93' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-ninety-three cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style94' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-ninety-four cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style95' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-ninety-five cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style96' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-ninety-six cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style97' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-ninety-seven cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style98' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-ninety-eight cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style99' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-ninety-nine cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style100' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-one-hundred cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style101' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-one-hundred-one cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style102' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-one-hundred-two cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style103' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-one-hundred-three cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style104' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-one-hundred-four cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style105' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-one-hundred-five cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style106' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-one-hundred-six cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style107' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-one-hundred-seven cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style108' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-one-hundred-eight cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style109' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-one-hundred-nine cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style110' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-one-hundred-ten cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } else if('style111' === settings['cbtns_style_selection']){ #>
				<div class="cbtns-btn-one-hundred-eleven cbtns_creative_buttons {{{settings['cbtns_buttons_custom_class_id']}}}">
					<a href="{{{settings['cbtns_link_buttons']['url']}}}"><div class="cbtns-title">{{{settings['cbtns_text_buttons']}}}</div></a>
				</div>
			<# } #>
		</div> <!-- Buttons Alignment -->
		<?php
	}
}
