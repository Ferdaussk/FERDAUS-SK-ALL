<?php
namespace Creativeimagehover\PageSettings;

use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\PageBase;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Page_Settings {

	const PANEL_TAB = 'new-tab';

	public function __construct() {
		add_action( 'elementor/init', [ $this, 'bwdih_image_hover_add_panel_tab' ] );
		add_action( 'elementor/documents/register_controls', [ $this, 'bwdih_image_hover_register_document_controls' ] );
	}

	public function bwdih_image_hover_add_panel_tab() {
		Controls_Manager::add_tab( self::PANEL_TAB, esc_html__( 'Image Hover Effect', 'bwdih-image-hover-effect' ) );
	}

	public function bwdih_image_hover_register_document_controls( $document ) {
		if ( ! $document instanceof PageBase || ! $document::get_property( 'has_elements' ) ) {
			return;
		}

		$document->start_controls_section(
			'bwdih_image_hover_new_section',
			[
				'label' => esc_html__( 'Settings', 'bwdih-image-hover-effect' ),
				'tab' => self::PANEL_TAB,
			]
		);

		$document->add_control(
			'bwdih_image_hover_text',
			[
				'label' => esc_html__( 'Title', 'bwdih-image-hover-effect' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Title', 'bwdih-image-hover-effect' ),
			]
		);

		$document->end_controls_section();
	}
}
