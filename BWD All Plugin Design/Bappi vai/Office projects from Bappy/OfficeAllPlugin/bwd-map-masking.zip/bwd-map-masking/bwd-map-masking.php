<?php
/**
 * Plugin Name: BWD Map Masking
 * Description: BWD Map Masking plugin with all countries map masking effects with flag background for Elementor.
 * Plugin URI:  https://bwdplugins.com/plugins/elementor/bwd-map-masking
 * Version:     1.0
 * Author:      Best WP Developer
 * Author URI:  https://bestwpdeveloper.com/
 * Text Domain: bwd-mflag-masking
 * Elementor tested up to: 3.0.0
 * Elementor Pro tested up to: 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
require_once ( plugin_dir_path(__FILE__) ) . '/includes/class-tgm-plugin-activation.php';
final class FinalBWDMFMMasking{

	const VERSION = '1.0';

	const MINIMUM_ELEMENTOR_VERSION = '3.0.0';

	const MINIMUM_PHP_VERSION = '7.0';

	public function __construct() {
		// Load translation
		add_action( 'bwdmfm_init', array( $this, 'bwdmfm_loaded_textdomain' ) );
		// bwdmfm_init Plugin
		add_action( 'plugins_loaded', array( $this, 'bwdmfm_init' ) );
	}

	public function bwdmfm_loaded_textdomain() {
		load_plugin_textdomain( 'bwd-mflag-masking' );
	}

	public function bwdmfm_init() {
		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			// For tgm plugin activation
			add_action( 'tgmpa_register', [$this, 'bwdmfm_masking_register_required_plugins'] );
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', array( $this, 'bwdmfm_admin_notice_minimum_elementor_version' ) );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', array( $this, 'bwdmfm_admin_notice_minimum_php_version' ) );
			return;
		}

		// Once we get here, We have passed all validation checks so we can safely include our plugin
		require_once( 'bwdmfm_plugin_boots.php' );
	}

	function bwdmfm_masking_register_required_plugins() {
		$plugins = array(
			array(
				'name'        => esc_html__('Elementor', 'bwd-mflag-masking'),
				'slug'        => 'elementor',
				'is_callable' => 'wpseo_init',
			),
		);

		$config = array(
			'id'           => 'bwd-mflag-masking',
			'default_path' => '',
			'menu'         => 'tgmpa-install-plugins',
			'parent_slug'  => 'plugins.php',
			'capability'   => 'manage_options',
			'has_notices'  => true,
			'dismissable'  => true,
			'dismiss_msg'  => '',
			'is_automatic' => false,
			'message'      => '',
		);
	
		tgmpa( $plugins, $config );
	}

	public function bwdmfm_admin_notice_minimum_elementor_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bwd-mflag-masking' ),
			'<strong>' . esc_html__( 'BWD Map Masking', 'bwd-mflag-masking' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'bwd-mflag-masking' ) . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>' . esc_html__('%1$s', 'bwd-mflag-masking') . '</p></div>', $message );
	}

	public function bwdmfm_admin_notice_minimum_php_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bwd-mflag-masking' ),
			'<strong>' . esc_html__( 'BWD Map Masking', 'bwd-mflag-masking' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'bwd-mflag-masking' ) . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>' . esc_html__('%1$s', 'bwd-mflag-masking') . '</p></div>', $message );
	}
}

// Instantiate bwd-mflag-masking.
new FinalBWDMFMMasking();
remove_action( 'shutdown', 'wp_ob_end_flush_all', 1 );