<?php
namespace BWDMapMasking\PageSettings;

use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\PageBase;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Page_Settings {

	const PANEL_TAB = 'new-tab';

	public function __construct() {
		add_action( 'elementor/init', [ $this, 'bwdmfm_masking_add_panel_tab' ] );
		add_action( 'elementor/documents/register_controls', [ $this, 'bwdmfm_masking_register_document_controls' ] );
	}

	public function bwdmfm_masking_add_panel_tab() {
		Controls_Manager::add_tab( self::PANEL_TAB, esc_html__( 'New Masking', 'bwd-mflag-masking' ) );
	}

	public function bwdmfm_masking_register_document_controls( $document ) {
		if ( ! $document instanceof PageBase || ! $document::get_property( 'has_elements' ) ) {
			return;
		}

		$document->start_controls_section(
			'bwdmfm_masking_new_section',
			[
				'label' => esc_html__( 'Settings', 'bwd-mflag-masking' ),
				'tab' => self::PANEL_TAB,
			]
		);

		$document->add_control(
			'bwdmfm_masking_text',
			[
				'label' => esc_html__( 'Title', 'bwd-mflag-masking' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Title', 'bwd-mflag-masking' ),
			]
		);

		$document->end_controls_section();
	}
}
