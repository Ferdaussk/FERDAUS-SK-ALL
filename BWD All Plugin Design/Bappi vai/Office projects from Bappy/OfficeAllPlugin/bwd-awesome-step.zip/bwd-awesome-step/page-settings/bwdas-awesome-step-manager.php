<?php
namespace Creativeawesomestep\PageSettings;

use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\PageBase;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class Page_Settings {

	const PANEL_TAB = 'new-tab';

	public function __construct() {
		add_action( 'elementor/init', [ $this, 'bwdas_awesome_step_add_panel_tab' ] );
		add_action( 'elementor/documents/register_controls', [ $this, 'bwdas_awesome_step_register_document_controls' ] );
	}

	public function bwdas_awesome_step_add_panel_tab() {
		Controls_Manager::add_tab( self::PANEL_TAB, esc_html__( 'New Awesome Step', 'bwdas-awesome-step' ) );
	}

	public function bwdas_awesome_step_register_document_controls( $document ) {
		if ( ! $document instanceof PageBase || ! $document::get_property( 'has_elements' ) ) {
			return;
		}

		$document->start_controls_section(
			'bwdas_awesome_step_new_section',
			[
				'label' => esc_html__( 'Settings', 'bwdas-awesome-step' ),
				'tab' => self::PANEL_TAB,
			]
		);

		$document->add_control(
			'bwdas_awesome_step_text',
			[
				'label' => esc_html__( 'Title', 'bwdas-awesome-step' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Title', 'bwdas-awesome-step' ),
			]
		);

		$document->end_controls_section();
	}
}
