<?php
namespace Creativeawesomestep\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class BWDASAwesomeStep extends \Elementor\Widget_Base {


	public function get_name() {
		return 'bwbas-awesome-step';
	}

	public function get_title() {
		return esc_html__( 'BWD Awesome Step', 'bwdas_awesome_step' );
	}

	public function get_icon() {
		return 'eicon-nowrap bwdas-awesome-step-icon';
	}

	public function get_categories() {
		return [ 'bwdas-awesome-step-category' ];
	}

    public function get_keywords() {
		return [ 'step', 'arrow', 'awesome step' ];
	}

	public function get_script_depends() {
		return [ 'bwdas-awesome-step-category' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'bwdas_step_choose_style',
		    [
		        'label' => esc_html__('Choose Style','bwdas_awesome_step'),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
		   
		    ]
		);
		$this->add_control(
			'bwdas_awesome_step_style',
			[
				'label' => esc_html__( 'Choose Style', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'bwdas_awesome_step' ),
					'style2' => esc_html__( 'Style 2', 'bwdas_awesome_step' ),
					'style3' => esc_html__( 'Style 3', 'bwdas_awesome_step' ),
					'style4' => esc_html__( 'Style 4', 'bwdas_awesome_step' ),
					'style5' => esc_html__( 'Style 5', 'bwdas_awesome_step' ),
					'style6' => esc_html__( 'Style 6', 'bwdas_awesome_step' ),
					'style7' => esc_html__( 'Style 7', 'bwdas_awesome_step' ),
					'style8' => esc_html__( 'Style 8', 'bwdas_awesome_step' ),
					'style9' => esc_html__( 'Style 9', 'bwdas_awesome_step' ),
					'style10' => esc_html__( 'Style 10', 'bwdas_awesome_step' ),
					'style11' => esc_html__( 'Style 11', 'bwdas_awesome_step' ),
					'style12' => esc_html__( 'Style 12', 'bwdas_awesome_step' ),
					'style13' => esc_html__( 'Style 13', 'bwdas_awesome_step' ),
					'style14' => esc_html__( 'Style 14', 'bwdas_awesome_step' ),
					'style15' => esc_html__( 'Style 15', 'bwdas_awesome_step' ),
					'style16' => esc_html__( 'Style 16', 'bwdas_awesome_step' ),
					'style17' => esc_html__( 'Style 17', 'bwdas_awesome_step' ),
					'style18' => esc_html__( 'Style 18', 'bwdas_awesome_step' ),
					'style19' => esc_html__( 'Style 19', 'bwdas_awesome_step' ),
					'style20' => esc_html__( 'Style 20', 'bwdas_awesome_step' ),
					'style21' => esc_html__( 'Style 21', 'bwdas_awesome_step' ),
					'style22' => esc_html__( 'Style 22', 'bwdas_awesome_step' ),
					'style23' => esc_html__( 'Style 23', 'bwdas_awesome_step' ),
					'style24' => esc_html__( 'Style 24', 'bwdas_awesome_step' ),
					'style25' => esc_html__( 'Style 25', 'bwdas_awesome_step' ),
					'style26' => esc_html__( 'Style 26', 'bwdas_awesome_step' ),
					'style27' => esc_html__( 'Style 27', 'bwdas_awesome_step' ),
					'style28' => esc_html__( 'Style 28', 'bwdas_awesome_step' ),
					'style29' => esc_html__( 'Style 29', 'bwdas_awesome_step' ),
					'style30' => esc_html__( 'Style 30', 'bwdas_awesome_step' ),
					'style31' => esc_html__( 'Style 31', 'bwdas_awesome_step' ),
				],
			]
		);
		$this->add_control(
			'bwdas_awesome_step_column_option',
			[
				'label' => esc_html__( 'Column', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '4',
				'options' => [
					'12'  => esc_html__( '1', 'bwdas_awesome_step' ),
					'6' => esc_html__( '2', 'bwdas_awesome_step' ),
					'4' => esc_html__( '3', 'bwdas_awesome_step' ),
					'3' => esc_html__( '4', 'bwdas_awesome_step' ),
				],
			]
		);
		$this->end_controls_section();
        $this->start_controls_section(
			'bwdas_step_content_style',
		    [
		        'label' => esc_html__('Content','bwdas_awesome_step'),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
		   
		    ]
		);
        $repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'bwdas_step_content_number', [
				'label' => esc_html__( 'Step Number', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
			]
		);
        $repeater->add_control(
			'bwdas_step_content_number_color',
			[
				'label' => esc_html__( 'Color', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-num' => 'color: {{VALUE}}',
				],
			]
		);
        $repeater->add_control(
			'bwdas_step_content_number_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-wrapper:hover .bwd-step-num' => 'color: {{VALUE}}',
				],
			]
		);
    
		$repeater->add_control(
			'bwdas_step_content_title', [
				'label' => esc_html__( 'Step Title', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
			]
		);
        $repeater->add_control(
			'bwdas_step_content_title_color',
			[
				'label' => esc_html__( 'Color', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-main-title' => 'color: {{VALUE}}',
				],
			]
		);
        $repeater->add_control(
			'bwdas_step_content_title_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-wrapper:hover .bwd-step-main-title ' => 'color: {{VALUE}} ',
				],
			]
		);
		$repeater->add_control(
			'bwdas_step_content_description', [
				'label' => esc_html__( 'Description', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
                'dynamic' => [
                    'active' => true,
                ],
			]
		);
        $repeater->add_control(
			'bwdas_step_content_description_color',
			[
				'label' => esc_html__( 'Color', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-content .bwd-description' => 'color: {{VALUE}}',
				],
			]
		);
        $repeater->add_control(
			'bwdas_step_content_description_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-wrapper:hover .bwd-step-content .bwd-description' => 'color: {{VALUE}}',
				],
			]
		);
        $repeater->add_control(
			'bwdas_step_content_icon',
			[
				'label' => esc_html__( 'Icon', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-cogs',
					'library' => 'solid',
				],
			]
		);
        $repeater->add_control(
			'bwdas_step_content_icon_color',
			[
				'label' => esc_html__( 'Color', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-icon i' => 'color: {{VALUE}}',
				],
			]
		);
        $repeater->add_control(
			'bwdas_step_content_icon_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-wrapper:hover .bwd-step-icon i' => 'color: {{VALUE}}',
				],
			]
		);
        $repeater->add_control(
			'bwdas_step_icon_number_background',
			[
				'label' => esc_html__( 'Icon Bg Color', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-icon-num, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-icon-numb::before' => 'background-color: {{VALUE}}',
				],
			]
		);
        $repeater->add_control(
			'bwdas_step_content_shape_background_title',
			[
				'label' => esc_html__( 'Shape Bg Color', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);
        $repeater->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'bwdas_step_content_shape_background',
				'label' => esc_html__( 'Background', 'bwdas_awesome_step' ),
				'types' => [ 'classic', 'gradient' ],
                'exclude' => ['image'],
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-num-gbl, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-num-gbla::after, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-num-gblb::before',
			]
		);
        $repeater->add_control(
			'bwdas_step_content_box_background_title',
			[
				'label' => esc_html__( 'Box Bg', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::HEADING,
			]
		);
        $repeater->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'bwdas_step_content_box_background',
				'label' => esc_html__( 'Background', 'bwdas_awesome_step' ),
				'types' => [ 'classic', 'gradient' ],
                'exclude' => ['image'],
				'selector' => '{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-bg-box, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-bg-boxb::before, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-bg-boxa::after',
			]
		);
        $repeater->add_control(
			'bwdas_step_icon_number_border_color',
			[
				'label' => esc_html__( 'All Visible Border Color', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-icon-num, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-icon-numb::before, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-icon-numa::after' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-icon-bortrans::before' => 'border-top-color: {{VALUE}}; border-left-color: {{VALUE}}; border-right-color: transparent; border-bottom-color: transparent;',
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-icon-bortrans' => 'border-top-color: transparent; border-left-color: {{VALUE}}; border-right-color: transparent; border-bottom-color: {{VALUE}};',
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-icon-bortransparent' => 'border-top-color: {{VALUE}}; border-left-color: transparent; border-right-color: {{VALUE}}; border-bottom-color: {{VALUE}};',
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-icon-borritrans' => 'border-top-color: {{VALUE}}; border-left-color: {{VALUE}}; border-right-color: transparent; border-bottom-color: {{VALUE}};',
					'{{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-icon-numa::after, {{WRAPPER}} {{CURRENT_ITEM}} .bwd-step-icon-numback::before' => 'background-color: {{VALUE}}',
				],
			]
		);
        $repeater->add_control(
			'bwdas_step_arrow_show_hide',
			[
				'label' => esc_html__( 'Show Arrow', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
                'description' => 'If arrow has available',
				'label_on' => esc_html__( 'Show', 'bwdas_awesome_step' ),
				'label_off' => esc_html__( 'Hide', 'bwdas_awesome_step' ),
				'return_value' => 'yes',
                'default' => 'yes',
			]
		);
        $this->add_control(
			'bwdas_step_content_repeater_list',
			[
				'label' => esc_html__( 'Content', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					
					[
						'bwdas_step_content_number' => esc_html__( '1', 'bwdas_awesome_step' ),
						'bwdas_step_content_title' => esc_html__( 'Title #1', 'bwdas_awesome_step' ),
						'bwdas_step_content_description' => esc_html__( 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Et, pariatur. Dolorum dolor repudiandae quidem facilis corrupti odit!' ),
					],
					[
						'bwdas_step_content_number' => esc_html__( '2', 'bwdas_awesome_step' ),
						'bwdas_step_content_title' => esc_html__( 'Title #2', 'bwdas_awesome_step' ),
						'bwdas_step_content_description' => esc_html__( 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Et, pariatur. Dolorum dolor repudiandae quidem facilis corrupti odit!' ),
					],
					[
						'bwdas_step_content_number' => esc_html__( '3', 'bwdas_awesome_step' ),
						'bwdas_step_content_title' => esc_html__( 'Title #3', 'bwdas_awesome_step' ),
						'bwdas_step_content_description' => esc_html__( 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Et, pariatur. Dolorum dolor repudiandae quidem facilis corrupti odit!' ),
					],
				],
				'title_field' => '{{{ bwdas_step_content_title }}}',
			]
		);
        $this->end_controls_section();
        $this->start_controls_section(
			'bwdas_step_style',
		    [
		        'label' => esc_html__('Style','bwdas_awesome_step'),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		   
		    ]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwdas_step_content_number_typography',
                'label' => esc_html__('Number Typography','bwdas_awesome_step'),
				'selector' => '{{WRAPPER}} .bwd-step-num',
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwdas_step_content_title_typography',
                'label' => esc_html__('Title Typography','bwdas_awesome_step'),
				'selector' => '{{WRAPPER}} .bwd-step-main-title',
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bwdas_step_content_description_typography',
                'label' => esc_html__('Description Typography','bwdas_awesome_step'),
				'selector' => '{{WRAPPER}} .bwd-step-content .bwd-description',
			]
		);
        $this->add_responsive_control(
			'bwdas_step_content_icon_size',
			[
				'label' => esc_html__( 'Icon Size', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .bwd-step-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control(
			'bwdas_step_content_item_box_padding',
			[
				'label' => esc_html__( 'Box Padding', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .bwd-step-bg-box, {{WRAPPER}} .bwd-step-bg-boxb' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->start_controls_tabs(
			'bwdas_step_style_tabs'
		);
        $this->start_controls_tab(
			'bwdas_step_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'bwdas_awesome_step' ),
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'bwdas_step_style_background',
				'label' => esc_html__( 'Background', 'bwdas_awesome_step' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .bwd-step-style',
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'bwdas_step_border',
				'label' => esc_html__( 'Border', 'bwdas_awesome_step' ),
				'selector' => '{{WRAPPER}} .bwd-step-style',
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'bwdas_step_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'bwdas_awesome_step' ),
				'selector' => '{{WRAPPER}} .bwd-step-style',
			]
		);
        $this->add_responsive_control(
			'bwdas_step_margin',
			[
				'label' => esc_html__( 'Margin', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .bwd-step-style' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control(
			'bwdas_step_padding',
			[
				'label' => esc_html__( 'Padding', 'bwdas_awesome_step' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .bwd-step-style' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_tab();
        $this->start_controls_tab(
			'bwdas_step_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'bwdas_awesome_step' ),
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'bwdas_step_style_hover_background',
				'label' => esc_html__( 'Background', 'bwdas_awesome_step' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .bwd-step-style:hover',
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'bwdas_step_hover_border',
				'label' => esc_html__( 'Border', 'bwdas_awesome_step' ),
				'selector' => '{{WRAPPER}} .bwd-step-style:hover',
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'bwdas_step_hover_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'bwdas_awesome_step' ),
				'selector' => '{{WRAPPER}} .bwd-step-style:hover',
			]
		);
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        
    }

    protected function render() {

        $settings = $this->get_settings_for_display();


        if ('style1' === $settings['bwdas_awesome_step_style']) { 
        ?>
         <div class="bwd-step-style bwd-step-style-1">
            <div class="container-fluid">
                <div class="row">
                    <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
                        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>

                        <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                            <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                                <div class="bwd-step-wrapper">
                                    <div class="bwd-step-item bwd-step-bg-box">
                                        <div class="bwd-step-icon bwd-step-icon-bortransparent bwd-step-icon-numb"><i class="bwd-step-icon-num <?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                        <div class="bwd-step-content bwd-step-icon-bortrans bwd-step-icon-numa">
                                            <div class="bwd-step-number bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                            <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                            <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        } elseif ('style2' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-2">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item bwd-step-num-gblb bwd-step-num-gbla bwd-step-bg-box">
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-icon bwd-step-icon-num"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                    <div class="bwd-step-number bwd-step-num bwd-step-num-gbl"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php    
        } elseif ('style3' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-3">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item bwd-step-bg-box">
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                    <div class="bwd-step-number bwd-step-num-gbl">
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php    
        } elseif ('style4' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-4">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item">
                                    <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i> </div>
                                    <div class="bwd-step-number bwd-step-num-gbl">
                                         <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-content-four bwd-step-bg-box bwd-step-arrowb">
                                    <?php    
                                    if ('yes' === $item['bwdas_step_arrow_show_hide']) {?>
                                        <div class="show-arrow"></div>
                                    <?php } ?>    
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php    
        } elseif ('style5' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-5">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper bwd-step-arrowb">
                            <?php    
                            if ('yes' === $item['bwdas_step_arrow_show_hide']) {?>
                                    <div class="show-arrow"></div>
                                 <?php } ?>  
                                <div class="bwd-step-item bwd-step-bg-boxb bwd-step-num-gbla">
                                    <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                    <div class="bwd-step-number bwd-step-num-gblb">
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php    
        } elseif ('style6' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-6">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper bwd-step-bg-box bwd-step-num-gblb">
                                <div class="bwd-step-item">
                                    <div class="bwd-step-number bwd-step-num-gbla bwd-step-num-gblb">
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php    
        } elseif ('style7' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-7">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item bwd-step-num-gblb bwd-step-num-gbla">
                                    <div class="bwd-step-content bwd-step-bg-box">
                                        <div class="bwd-step-icon"> <i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                    <div class="bwd-step-number bwd-step-num-gbl">
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php    
        } elseif ('style8' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-8">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item bwd-step-icon-borritrans bwd-step-icon-numback bwd-step-bg-box">
                                    <div class="bwd-step-number-eight bwd-step-icon-num">
                                        <div class="bwd-step-title-eight bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php    
        } elseif ('style9' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-9">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item bwd-step-num-gblb bwd-step-bg-box">
                                    <div class="bwd-step-number">
                                        <div class="bwd-title bwd-step-num bwd-step-num-gbl bwd-step-num-gblb bwd-step-num-gbla"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php    
        } elseif ('style10' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-10">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                             <?php
                            if ('yes' === $item['bwdas_step_arrow_show_hide']) {?>
                                 <div class="show-arrow"></div>
                                 <?php } ?> 
                                <div class="bwd-step-item bwd-step-bg-box bwd-step-num-gblb">
                                    <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                    <div class="bwd-step-number bwd-step-num-gbla bwd-step-num-gblb">
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        } elseif ('style11' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-11">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item-eleven bwd-step-bg-boxb bwd-step-num-gbla">
                                    <div class="bwd-step-icon bwd-step-icon-num"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                    <div class="bwd-step-number-eleven">
                                        <div class="bwd-step-title-eleven bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                </div> 
                            </div> 
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php    
        } elseif ('style12' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-12">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper bwd-step-num-gbla bwd-step-num-gblb">
                                <div class="bwd-step-item bwd-step-bg-boxb bwd-step-bg-boxa">
                                    <div class="bwd-step-icon bwd-step-icon-num"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                    <div class="bwd-step-number">
                                        <div class="bwd-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        } elseif ('style13' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-13">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item-thirteen bwd-step-bg-boxb">
                                    <div class="bwd-step-number-thirteen bwd-step-num-gblb">
                                        <div class="bwd-step-title-thirteen bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                    <div class="bwd-step-icon bwd-step-icon-numb"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php    
        } elseif ('style14' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-14">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item bwd-step-bg-box bwd-step-bg-boxb">
                                    <div class="bwd-step-number bwd-step-number-fourteen bwd-step-num-gbl bwd-step-num-gbla bwd-step-num-gblb">
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                    <div class="bwd-step-icon bwd-step-icon-fourteen bwd-step-icon-num"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php    
        } elseif ('style15' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-15">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item-fifteen bwd-step-bg-boxb">
                                    <div class="bwd-step-number-fifteen">
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                    <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php    
        } elseif ('style16' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-16">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item bwd-step-bg-box">
                                    <div class="bwd-step-number bwd-step-num-gbl bwd-step-num-gblb">
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php    
        } elseif ('style17' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-17">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper bwd-step-num-gbla bwd-step-num-gblb">
                                <div class="bwd-step-item bwd-step-bg-box">
                                    <div class="bwd-step-number-seventeen">
                                        <div class="bwd-step-title-seventeen bwd-step-num bwd-step-num-gbl"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-icon bwd-step-icon-num"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        } elseif ('style18' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-18">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper bwd-step-num-gblb bwd-step-num-gbla">
                            <?php    
                            if ('yes' === $item['bwdas_step_arrow_show_hide']) {?>
                                 <div class="show-arrow"></div>
                                 <?php } ?> 
                                <div class="bwd-step-item bwd-step-bg-box">
                                    <div class="bwd-step-number-eighteen bwd-step-icon-num">
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                    <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php    
        } elseif ('style19' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-19">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item-nineteen">
                                    <div class="bwd-step-number bwd-step-num-gbl bwd-step-num-gblb bwd-step-num-gbla">
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-content bwd-step-bg-box">
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                        <div class="bwd-step-icon"> <i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php    
        } elseif ('style20' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-20">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item-twenty">
                                    <div class="bwd-step-number">
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-content bwd-step-bg-box bwd-step-num-gblb">
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                        <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        } elseif ('style21' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-21">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item bwd-step-bg-box">
                                    <div class="bwd-step-icon bwd-step-icon-num"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                    <div class="bwd-step-number bwd-step-num bwd-step-num-gbl"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        } elseif ('style22' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-22">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item bwd-step-bg-box">
                                    <div class="bwd-step-number bwd-step-icon-num">
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                    <div class="bwd-step-icon bwd-step-icon-ttwo bwd-step-num-gbl"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        } elseif ('style23' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-23">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item-tthree">
                                <?php    
                                if ('yes' === $item['bwdas_step_arrow_show_hide']) {?>
                                    <div class="show-arrow"></div>
                                    <?php } ?> 
                                    <div class="bwd-step-content bwd-step-bg-box">
                                        <div class="bwd-step-number bwd-step-num-gbl">
                                            <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                        </div>
                                        <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        } elseif ('style24' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-24">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item bwd-step-num-gblb bwd-step-num-gbla bwd-step-bg-box">
                                    <div class="bwd-step-shape bwd-step-num-gbla bwd-step-num-gblb"></div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-icon bwd-step-icon-numb"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                        <div class="bwd-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                    <div class="bwd-step-number bwd-step-num bwd-step-num-gbl bwd-step-num-gblb bwd-step-num-gbla"><?php echo esc_html($item['bwdas_step_content_number']); ?>
                                    <?php    
                                    if ('yes' === $item['bwdas_step_arrow_show_hide']) {?>
                                    <div class="show-arrow"></div>
                                    <?php } ?> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        } elseif ('style25' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-25">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item bwd-step-item-tfive bwd-step-bg-box bwd-step-num-gblb bwd-step-icon-borritrans bwd-step-icon-numback">
                                    <div class="bwd-step-number bwd-step-num-gblb bwd-step-num-gbla">
                                    <?php    
                                    if ('yes' === $item['bwdas_step_arrow_show_hide']) {?>
                                    <div class="show-arrow"></div>
                                    <?php } ?> 
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                    <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        } elseif ('style26' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-26">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item bwd-step-num-gblb bwd-step-num-gbla">
                                    <div class="bwd-step-content bwd-step-bg-box">
                                        <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                    <div class="bwd-step-number bwd-step-num-gbl">
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        } elseif ('style27' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-27">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-shaddow"></div>
                                <div class="bwd-step-item bwd-step-bg-box bwd-step-num-gblb bwd-step-num-gbla">
                                    <div class="bwd-step-number bwd-step-num-gbl bwd-step-num-gblb bwd-step-num-gbla">
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        } elseif ('style28' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-28">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item bwd-step-num-gblb">
                                    <div class="bwd-step-number bwd-step-num-gbl bwd-step-num-gbla">
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                    <div class="bwd-step-content bwd-step-content-teight bwd-step-bg-box">
                                        <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        } elseif ('style29' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-29">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item bwd-step-num-gblb bwd-step-bg-box">
                                    <div class="bwd-step-number bwd-step-num bwd-step-num-gbl"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                    <div class="bwd-step-content">
                                        <div class="bwd-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        } elseif ('style30' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-30">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper bwd-step-num-gbla">
                                <div class="bwd-step-shape bwd-step-icon-bortrans bwd-step-icon-numback"></div>
                                <div class="bwd-step-item bwd-step-bg-box">
                                    <div class="bwd-step-content">
                                        <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i></div>
                                        <div>
                                            <div class="bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                            <div class="bwd-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        </div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        } elseif ('style31' === $settings['bwdas_awesome_step_style']) {
        ?>
        <div class="bwd-step-style bwd-step-style-31">
            <div class="container-fluid">
                <div class="row">
                <?php   
                    if( $settings['bwdas_step_content_repeater_list'] ) {
				        foreach( $settings['bwdas_step_content_repeater_list'] as $item ) { ?>
                    <div class="col-xl-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-sm-<?php echo esc_attr($settings['bwdas_awesome_step_column_option']); ?> col-lg-4 col-sm-6">
                        <?php echo '<div class="elementor-repeater-item-' . esc_attr( $item['_id'] ) . '">'; ?>
                            <div class="bwd-step-wrapper">
                                <div class="bwd-step-item-tone">
                                    <div class="bwd-step-content bwd-step-bg-box">
                                        <div class="bwd-step-icon"><i class="<?php echo esc_attr($item['bwdas_step_content_icon']['value']); ?>"></i>
                                        </div>
                                        <div class="bwd-step-title bwd-step-main-title"><?php echo esc_html($item['bwdas_step_content_title']); ?></div>
                                        <div class="bwd-description"><?php echo esc_html($item['bwdas_step_content_description']); ?></div>
                                    </div>
                                    <div class="bwd-step-number bwd-step-num-gbl bwd-step-num-gblb bwd-step-num-gbla">
                                        <div class="bwd-step-title bwd-step-num"><?php echo esc_html($item['bwdas_step_content_number']); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
        }
        
    }
}